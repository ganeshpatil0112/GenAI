# AIccelerate

Build your own AI Chatbot with AIccelerate.

Note: We only support Python 3.11+ and recommend building using Podman. While Docker is an option, we cannot provide support for it.

## Pre-requisites

1. [Install Podman](https://podman.io/getting-started/installation) (Recommended) or [Install Docker](https://www.docker.com/).
2. [Podman-Compose](https://pypi.org/project/podman-compose/) (Recommended) or [Docker-Compose](https://docs.docker.com/compose/install/).

## Build & Run Using Podman

- Using Podman Build

  ```bash
  podman-compose up --build
  ```

## Build Using Python 3.11+

- Install [Python 3.11+](https://www.python.org/downloads/)

1. **On Windows**

    ```powershell
    winget install --id Python.Python
    ```

2. **On Linux**

    ```bash
    sudo apt-get install python3.12
    ```

- Create a virtual environment

  ```bash
  python -m virtualenv venv
  ```

- Install the requirements

  ```bash
  python -m pip install -r requirements.txt
  ```

- Run the application

  ```bash
  uvicorn main:app --reload
  ```

## Local Development Using Podman and Visual Studio Code

- Install the [Dev Containers](https://marketplace.visualstudio.com/items?itemName=ms-vscode-remote.remote-containers) extension in Visual Studio Code.

- Clone the repository

  ```bash
  git clone https://github.com/fin-payments/aiccelerate
  ```

- Open the project in Visual Studio Code

  ```bash
  code aiccelerate;
  ```

- From the Command Palette (Ctrl+Shift+P), select `Dev Containers: Reopen in Container`.

- Run the application

  ```bash
  python main.py
  ```

## Local Development on Windows/Linux

- Install Ollama

  - **On Windows using AppInstaller (winget)**

    ```powershell
    winget install --Id Ollama.Ollama
    ```

  - **On Linux (x86_64)**

    ```bash
    curl -L https://ollama.com/download/ollama-linux-amd64.tgz -o ollama-linux-amd64.tgz
    tar -xvf ollama-linux-amd64.tgz
    ```

  - Add Ollama as a startup service.

    ```bash
    sudo useradd -r -s /bin/false -U -m -d /usr/share/ollama ollama
    sudo usermod -a -G ollama $(whoami)
    ```

  - Create a service file at `/etc/systemd/system/ollama.service` (SYSTEMD):

    ```bash
    [Unit]
    Description=Ollama Service
    After=network-online.target

    [Service]
    ExecStart=/usr/bin/ollama serve
    User=ollama
    Group=ollama
    Restart=always
    RestartSec=3
    Environment="PATH=$PATH"

    [Install]
    WantedBy=default.target
    ```

  - Start the service

    ```bash
    sudo systemctl daemon-reload
    sudo systemctl enable ollama # Enable auto-start
    ```

- Development using Local Embedding and Inferencing Model:
  - **Recommended Embedding Model on GPU (1.5B) - (1024D) - `mxbai-embed-large`**
    - To add to Ollama:

      ```bash
      ollama pull mxbai-embed-large
      ```

  - **Recommended Inferencing Model on CPU (110M) - (348D) - `snowflake-arctic-embed:22m`**
    - To add to Ollama:

      ```bash
      ollama pull snowflake-arctic-embed:22m
      ```

  - **Recommended Inferencing Model on GPU (3.8B) - `Microsoft Phi3`**
    - To add to Ollama:

      ```bash
      ollama pull phi3
      ```

  - **Recommended Inferencing Model on CPU (1B) - `Meta llama3.2:1b`**
    - To add to Ollama:

      ```bash
      ollama pull llama3.2:1b
      ```

- Install Python 3.12+ (Recommended)

  - **On Windows**

    ```powershell
    winget install --id Python.Python
    ```

  - **On Linux**

    ```bash
    sudo apt-get install python3.12
    ```

- Install the Python requirements

  ```bash
  pip install -r requirements.txt
  ```

- Run Tests

  ```bash
  python -m discover -s tests
  ```

## Common Errors

### Image Not Found Error

- The Finastra VPN (Cisco AnyConnect Secure) may interfere with the image pull process. Disconnect from the VPN and try again.
- If you are using a proxy, make sure to configure it in the Podman settings.

  ```bash
  podman system connection add --name podman-machine-default-root --uri unix:///run/user/1000/podman/podman.sock
  podman system connection set --name podman-machine-default-root --http-proxy http://proxy.example.com:8080
  podman system connection set --name podman-machine-default-root --https-proxy http://proxy.example.com:8080
  ```

### ZScaler Certificate Error

- If you are using ZScaler, you may encounter certificate errors. Disable ZScaler or import the machine certificate (available only with Docker).

  ```powershell
  docker-machine regenerate-certs --client-certs
  ```

### Podman Compose Error on Windows

```log
...
Successfully tagged localhost/finchat_ai_finchat_ai:latest
289417c729f776b2a2598ccb1d7d93b132ffb46817cdec2c1fbd9896bea46afa
Error: failed to make pod: adding pod to state: name "pod_finchat_ai" is in use: pod already exists
Error: creating container storage: the container name "ollama" is already in use by a8053f144707cf103b321c942672f406fa8715e9451e52adb16971ebba9170f3. You have to remove that container to be able to reuse that name: that name is already in use
fa1f6da1da87530aad7688a4b0adf7fe6f3f648a479c7be82360b993a400394a
Traceback (most recent call last):
  File "<frozen runpy>", line 198, in _run_module_as_main
  File "<frozen runpy>", line 88, in _run_code
  File "C:\Users\u732130\Projects\finchat_ai\.venv\Scripts\podman-compose.exe\__main__.py", line 7, in <module>
  File "C:\Users\u732130\Projects\finchat_ai\.venv\Lib\site-packages\podman_compose.py", line 3504, in main
    asyncio.run(async_main())
  File "C:\Program Files\Python311\Lib\asyncio\runners.py", line 190, in run
    return runner.run(main)
           ^^^^^^^^^^^^^^^^
  File "C:\Program Files\Python311\Lib\asyncio\runners.py", line 118, in run
    return self._loop.run_until_complete(task)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "C:\Program Files\Python311\Lib\asyncio\base_events.py", line 653, in run_until_complete
    return future.result()
           ^^^^^^^^^^^^^^^
  File "C:\Users\u732130\Projects\finchat_ai\.venv\Lib\site-packages\podman_compose.py", line 3500, in async_main
    await podman_compose.run()
  File "C:\Users\u732130\Projects\finchat_ai\.venv\Lib\site-packages\podman_compose.py", line 1743, in run
    retcode = await cmd(self, args)
              ^^^^^^^^^^^^^^^^^^^^^
  File "C:\Users\u732130\Projects\finchat_ai\.venv\Lib\site-packages\podman_compose.py", line 2521, in compose_up
    loop.add_signal_handler(signal.SIGINT, lambda: [t.cancel("User exit") for t in tasks])
  File "C:\Program Files\Python311\Lib\asyncio\events.py", line 574, in add_signal_handler
    raise NotImplementedError
NotImplementedError
```

- **Solution:** Modify the `podman-compose.py` file in the virtual environment to remove the signal handler.
- **File Path for Virtual Environment:** `.venv\Lib\site-packages\podman_compose.py`

- **Original Code (around line 2520):**

  ```python
  loop = asyncio.get_event_loop()
  loop.add_signal_handler(signal.SIGINT, lambda: [t.cancel("User exit") for t in tasks])
  ```

- **Fixed Code:**

  ```python
  def raise_graceful_exit(tasks, *args):
      for task in tasks:
          task.cancel()

  loop = asyncio.get_event_loop()
  signal.signal(signal.SIGINT, raise_graceful_exit)
  ```

### Podman Exposed URL Inaccessible

- Ensure that the Podman system connection is set to default as root.

  Check the existing connection:

  ```powershell
  podman system connection default
  ```

  Set the default connection to root:

  ```powershell
  podman system connection default podman-machine-default-root
  ```

## Required Sqlite3 >= 3.35.0

```bash
  File "/home/FinAdmin/Projects/AIccelerate/venv/lib/python3.12/site-packages/langchain_chroma/vectorstores.py", line 25, in <module>
    import chromadb
  File "/home/FinAdmin/Projects/AIccelerate/venv/lib/python3.12/site-packages/chromadb/__init__.py", line 86, in <module>
    raise RuntimeError(
RuntimeError: Your system has an unsupported version of sqlite3. Chroma requires sqlite3 >= 3.35.0.
Please visit https://docs.trychroma.com/troubleshooting#sqlite to learn how to upgrade.
```

- **Solution:** Modify `__init__.py` to use pysqlite3 instead of sqlite3.

- **File to Edit:** `/home/FinAdmin/Projects/AIccelerate/venv/lib/python3.12/site-packages/chromadb/__init__.py`

Add the following code immediately after the import statements:

```python
__import__('pysqlite3')
import sys
sys.modules['sqlite3'] = sys.modules.pop('pysqlite3')
```
