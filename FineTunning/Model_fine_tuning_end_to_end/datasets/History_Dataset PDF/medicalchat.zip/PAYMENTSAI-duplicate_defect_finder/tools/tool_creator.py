"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-14
Description: OpenAITool Creator
"""

from typing import List, Dict, Any


class Property:
    def __init__(
        self,
        variable_name: str,
        variable_type: str,
        variable_description: str,
        enum_values: List[str] = [],
        required: bool = True,
    ):
        """Property class to define the properties of the function parameters
        ### Parameters
        - `variable_name`: str Name of the variable
        - `variable_type`: str Type of the variable
        - `variable_description`: str Description of the variable
        - `enum_values`: List[str] Enum values of the variable
        - `required`: bool Required property of the variable
        """

        self.variable_name = variable_name
        self.variable_type = variable_type
        self.variable_description = variable_description
        self.enum_values = enum_values if enum_values else []
        self.required = required

    def with_enum_values(self, enum_values: List[str]) -> "Property":
        """Method to add enum values to the property
        ### Parameters
        - `enum_values`: List[str] Enum values of the variable
        ### Returns
        - `Property`: Property object with enum values
        """

        self.enum_values = enum_values
        return self

    def with_required(self, required: bool) -> "Property":
        """Method to set the required property
        ### Parameters
        - `required`: bool Required property of the variable
        ### Returns
        - `Property`: Property object with required property
        """

        self.required = required
        return self

    def to_dict(self) -> Dict[str, Any]:
        """Method to convert the property to a dictionary
        ### Returns
        - `Dict[str, Any]`: Dictionary representation of the property
        """

        prop_dict: Dict[str, Any] = {
            "type": self.variable_type,
            "description": self.variable_description,
        }
        if self.enum_values:
            prop_dict["enum"] = self.enum_values
        return prop_dict


class Properties:
    """Properties class to define the properties of the function parameters"""

    def __init__(self, props: List[Property] = []):
        """Constructor to initialize the properties
        ### Parameters
        - `props`: List[Property] List of properties
        """

        self.props = props if props else []

    def add_property(self, prop: "Property") -> "Properties":
        """Method to add a property to the properties
        ### Parameters
        - `prop`: Property Property object to add
        ### Returns
        - `Properties`: Properties object with the added property
        """

        self.props.append(prop)
        return self

    def to_dict(self) -> Dict[str, Any]:
        return {prop.variable_name: prop.to_dict() for prop in self.props}


class Parameters:
    def __init__(
        self,
        properties: Properties = Properties(),
        param_type: str = "object",
        required: List[str] = [],
    ):
        """Parameters class to define the parameters of the function
        ### Parameters
        - `properties`: Properties Properties object
        - `param_type`: str Type of the parameter
        - `required`: List[str] List of required properties
        """

        self.param_type = param_type
        self.properties = properties if properties else Properties()
        self.required = required if required else []

    def with_param_type(self, param_type: str) -> "Parameters":
        """Method to set the parameter type
        ### Parameters
        - `param_type`: str Type of the parameter
        ### Returns
        - `Parameters`: Parameters object with the parameter type
        """

        self.param_type = param_type
        return self

    def with_properties(self, properties: "Properties") -> "Parameters":
        """Method to set the properties of the parameter
        ### Parameters
        - `properties`: Properties Properties object
        ### Returns
        - `Parameters`: Parameters object with the properties
        """

        self.properties = properties
        self.required = [
            prop.variable_name for prop in properties.props if prop.required
        ]
        return self

    def to_dict(self) -> Dict[str, Any]:
        """Method to convert the parameters to a dictionary
        ### Returns
        - `Dict[str, Any]`: Dictionary representation of the parameters
        """

        param_dict: Dict[str, Any] = {
            "type": self.param_type,
            "properties": self.properties.to_dict(),
        }

        if self.required:
            param_dict["required"] = self.required

        return param_dict


class Functions:
    """Functions class to define the functions of the OpenAITool"""

    def __init__(
        self,
        name: str = "",
        description: str = "",
        parameters: Parameters = Parameters(),
    ):
        """Constructor to initialize the function
        ### Parameters
        - `name`: str Name of the function
        - `description`: str Description of the function
        - `parameters`: Parameters Parameters object
        """

        self.name = name
        self.description = description
        self.parameters = parameters if parameters else Parameters()

    def with_name(self, name: str) -> "Functions":
        """Method to set the name of the function
        ### Parameters
        - `name`: str Name of the function
        ### Returns
        - `Functions`: Functions object with the name
        """

        self.name = name
        return self

    def with_description(self, description: str) -> "Functions":
        """Method to set the description of the function
        ### Parameters
        - `description`: str Description of the function
        ### Returns
        - `Functions`: Functions object with the description
        """

        self.description = description
        return self

    def with_parameters(self, parameters: "Parameters") -> "Functions":
        """Method to set the parameters of the function
        ### Parameters
        - `parameters`: Parameters Parameters object
        ### Returns
        - `Functions`: Functions object with the parameters
        """

        self.parameters = parameters
        return self

    def to_dict(self) -> Dict[str, Any]:
        """Method to convert the function to a dictionary
        ### Returns
        - `Dict[str, Any]`: Dictionary representation of the function
        """

        return {
            "name": self.name,
            "description": self.description,
            "parameters": self.parameters.to_dict(),
        }


class OpenAITools:
    """OpenAITools class to define the OpenAITool"""

    def __init__(self, tool_type: str = "function", function: Functions = Functions()):
        """Constructor to initialize the OpenAITool
        ### Parameters
        - `tool_type`: str Type of the tool
        - `function`: Functions Function object
        """

        self.tool_type = tool_type
        self.function = function if function else Functions()

    def with_type(self, tool_type: str) -> "OpenAITools":
        """Method to set the type of the tool
        ### Parameters
        - `tool_type`: str Type of the tool
        ### Returns
        - `OpenAITools`: OpenAITools object with the tool type
        """

        self.tool_type = tool_type
        return self

    def with_function(self, function: "Functions") -> "OpenAITools":
        """Method to set the function of the tool
        ### Parameters
        - `function`: Functions Function object
        ### Returns
        - `OpenAITools`: OpenAITools object with the function
        """

        self.function = function
        return self

    def build(self) -> Dict[str, Any]:
        """Method to build the OpenAITool
        ### Returns
        - `Dict[str, Any]`: Dictionary representation of the OpenAITool
        """

        return {"type": self.tool_type, "function": self.function.to_dict()}

    def build_chat_completion_tool(self) -> Dict[str, Any]:
        """Method to build the Chat Completion Tool
        ### Returns
        - `Dict[str, Any]`: Dictionary representation of the Chat Completion Tool
        """

        return {
            "function": {
                "name": self.function.name,
                "description": self.function.description,
                "parameters": self.function.parameters.to_dict(),
            }
        }
