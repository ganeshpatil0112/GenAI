"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2025-06-19
Description: OTP Storage and Verification
"""

import sqlite3
import os
from datetime import datetime, timedelta

DB_PATH = os.path.join(os.path.dirname(__file__), 'otp_store.sqlite3')

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def store_otp(email: str, otp: str, expires_at: datetime):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('REPLACE INTO otp_store (email, otp, expires_at) VALUES (?, ?, ?)', (email, otp, expires_at))
    conn.commit()
    conn.close()

def store_gauge(value: str):
    store_otp(
        email="total_request_count",
        otp=value,
        expires_at=datetime.now() + timedelta(weeks=54)  # Store for 1 year
    )
 
def get_gauge() -> str:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT otp FROM otp_store WHERE email = ?', ("total_request_count",))
    row = cursor.fetchone()
    conn.close()
    return row['otp'] if row else "0"


def verify_and_delete_otp(email: str, otp: str) -> bool:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT otp, expires_at FROM otp_store WHERE email = ?', (email,))
    row = cursor.fetchone()
    if row:
        db_otp = row['otp']
        expires_at = datetime.fromisoformat(row['expires_at'])
        if db_otp == otp and datetime.now() < expires_at:
            cursor.execute('DELETE FROM otp_store WHERE email = ?', (email,))
            conn.commit()
            conn.close()
            return True
    conn.close()
    return False
