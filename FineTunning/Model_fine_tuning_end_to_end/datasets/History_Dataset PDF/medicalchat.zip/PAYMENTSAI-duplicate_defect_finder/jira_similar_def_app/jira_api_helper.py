"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-12-17
Description: Jira API Helper
"""

from jira_similar_def_app.jira_app_constants import (
    JIRA_AI_SYSTEM_MESSAGE,
    JIRA_JQL_SEARCH_MAX_RESULT,
)
from jira_similar_def_app.jira_tools import (
    fetch_pull_request_code_changes,
    fetch_pull_request_details,
    fetch_pull_request_file_changes,
    find_pull_request_by_defect_id,
    fetch_specific_field_from_defect,
    fetch_defect_from_jira,
    fetch_similar_defects,
    jira_function_call_handler,
    fetch_jira_field_values,
)
from jira_similar_def_app.user_feedback import (
    insert_user_feedback,
)
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, SystemMessage
from jira_similar_def_app.api_model import JiraAPIBulkIssues, UserFeedBackModel
from jira_similar_def_app.models import JiraModel, UserFeedBack, ChatHistory
from jira_similar_def_app.jira_tool_helper import fetch_jira_bulk_data
from interfaces.chat_completion import ChatCompletionInterface
from abstraction.chaining import ChatCompletionLangGraph
from jira_similar_def_app.jira_db import JiraDatabase
from abstraction.inferencing import AppInferencing
from api.models import PostRequestUserQuery
from abstraction.chaining import LLMChain
from utils.app_config import AppConfig
from typing import List, Any, Optional
import logging
import json


async def handle_jira_chat_completion(
    streaming=True,
) -> Optional[ChatCompletionInterface]:
    """Handle Jira Chat Completion,
    It Streams the Chat Completion Response to WebSocket.
    ### Args:
    - user_query: str : User Query
    - session_id: str : Session ID
    """

    logging.log(
        logging.INFO,
        f"Handling Jira Chat Completion",
    )

    llm = AppInferencing().get_llm()

    llm_chain = (
        LLMChain()
        .with_system_message(JIRA_AI_SYSTEM_MESSAGE)
        .with_llm(llm)
        .with_tools(
            [
                fetch_similar_defects,
                fetch_defect_from_jira,
                fetch_specific_field_from_defect,
                find_pull_request_by_defect_id,
                fetch_pull_request_file_changes,
                fetch_pull_request_details,
                fetch_pull_request_code_changes,
                fetch_jira_field_values,
            ]
        )
        .with_stream_output(streaming)
        .with_function_call_handler(jira_function_call_handler)
        .build()
    )

    return llm_chain


async def upload_jira_bulk_issues(
    jira_bulk_issues: List[JiraModel], appconfig=AppConfig().load_config()
) -> List[str]:
    """Upload Jira Bulk Issues to Database
    ### Args:
    - jira_bulk_issues: List[JiraModel] : Jira Bulk Issues to Upload
    ### Returns:
    - bool : True if Success else False
    """

    logging.log(
        logging.INFO,
        "Uploading Jira Bulk Issues to Database",
    )

    logging.log(
        logging.DEBUG,
        f"Uploading Jira Bulk Issues to Database: {jira_bulk_issues}",
    )

    jira_db = JiraDatabase(appconfig)

    return await jira_db.add_jira_data_bulk(jira_bulk_issues)


async def upload_jira_bulk_data(
    jira_bulk_data: JiraAPIBulkIssues, appconfig=AppConfig().load_config()
) -> bool:
    """Upload Jira Bulk Data to Database
    ### Args:
    - jira_bulk_data: JiraAPIBulkIssues : Jira Bulk Data to Upload
    ### Returns:
    - bool : True if Success else False
    """

    logging.log(
        logging.INFO,
        "Uploading Jira Bulk Data to Database with Jira Bulk Data",
    )

    logging.log(
        logging.DEBUG,
        f"Uploading Jira Bulk Data to Database with Jira Bulk Data: {jira_bulk_data}",
    )

    jira_models = []

    for jira_json in jira_bulk_data.issues:
        jira_model = JiraModel.from_jira_json(jira_json)
        if jira_model:
            jira_models.append(jira_model)

    await upload_jira_bulk_issues(jira_models, appconfig)

    return True


async def upload_jira_jql_data(
    jira_jql_query: str,
    task_id: str,
    appconfig=AppConfig().load_config(),
    max_results: int = JIRA_JQL_SEARCH_MAX_RESULT,
) -> bool:
    """Upload Jira JQL Data to Database
    ### Args:
    - jira_jql_query: str : Jira JQL Query
    ### Returns:
    - bool : True if Success else False
    """

    logging.log(
        logging.INFO,
        f"Upload Jira Data using JQL: {jira_jql_query}, task_id: {task_id}",
    )

    # TODO, Implement the task_id logic to track the task status.

    try:
        async for fetched_chunk in fetch_jira_bulk_data(
            jira_jql=jira_jql_query, max_result=max_results
        ):
            await upload_jira_bulk_issues(fetched_chunk, appconfig)
    except Exception as e:
        logging.error(f"Error: {e}")
        return False

    return True


async def update_or_insert_jira_jql_data(
    jira_jql_query: str, task_id: str, appconfig=AppConfig().load_config()
) -> List[str]:
    """Update or Insert Jira JQL Data to Database
    ### Args:
    - jira_jql: str : Jira JQL Query
    """

    logging.log(
        logging.INFO,
        f"Update or Insert Jira Data using JQL: {jira_jql_query}",
    )

    # TODO, Implement the logic to update or insert Jira JQL Data to Database.

    jira_db = JiraDatabase(appconfig)

    ids = []

    async for fetched_defect_responses in fetch_jira_bulk_data(jira_jql_query):
        for defect in fetched_defect_responses:
            await jira_db.delete_jira_data_by_field_value("defect_id", defect.defect_id)

        ids.extend(await upload_jira_bulk_issues(fetched_defect_responses, appconfig))

    return ids


async def get_task_status(task_id: str, appconfig=AppConfig().load_config()) -> Any:
    """Get Task Status
    ### Args:
    - task_id: str : Task ID
    ### Returns:
    - str : Task Status
    """

    logging.log(
        logging.INFO,
        f"Get Task Status for Task ID: {task_id}",
    )

    # TODO, Implement Get Task status from db.

    return "Task Completed..."


async def add_user_feedback(user_feedback: UserFeedBackModel):
    """Post User Feedback
    ### Args:
    - user_feedback: UserFeedBackModel : User Feedback
    """

    logging.log(
        logging.INFO,
        f"Post User Feedback: {user_feedback}",
    )

    feedback_to_insert = UserFeedBack(
        id=0,
        email=user_feedback.email,
        response=user_feedback.response,
        feedback=user_feedback.feedback,
        impression=user_feedback.impression,
        chat_history=user_feedback.chat_history,
    )

    return await insert_user_feedback(feedback_to_insert)


async def handle_post_request_chat_completion(user_query: PostRequestUserQuery) -> str:
    """Handle Post Request Chat Completion
    ### Args:
    - user_query: PostRequestUserQuery : User Query
    """

    llm_chain = await handle_jira_chat_completion(False)

    logging.log(
        logging.INFO,
        f"Handling Post Request Chat Completion",
    )

    if not llm_chain:
        logging.error("Error: LLMChain is null")
        return "Error: Unable to process the request"

    if not isinstance(llm_chain, ChatCompletionLangGraph):
        logging.error("Error: LLMChain is not a ChatCompletionLangGraph")
        return "Error: Unable to process the request"

    messages: List[BaseMessage] = []  # [SystemMessage(content=JIRA_AI_SYSTEM_MESSAGE)]

    for message in user_query.messages:
        if message.type == "human":
            messages.append(HumanMessage(message.content))
        elif message.type == "ai":
            messages.append(AIMessage(message.content))
        elif message.type == "system":
            messages.append(SystemMessage(message.content))

    if not isinstance(messages[0], SystemMessage):
        messages.insert(0, SystemMessage(content=JIRA_AI_SYSTEM_MESSAGE))

    return (
        await llm_chain.aresponse_with_history(messages)
        or "Error: Unable to process the request"
    )
