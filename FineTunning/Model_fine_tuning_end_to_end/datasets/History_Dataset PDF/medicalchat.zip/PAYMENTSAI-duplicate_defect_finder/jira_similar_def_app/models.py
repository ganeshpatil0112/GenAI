"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-12-04
Description: Jira Similar Def App Models
"""

from jira_similar_def_app.jira_app_constants import GITHUB_REPO_OWNER, GITHUB_REPO_NAME
from typing import List, Optional, Any, Literal
from jira_similar_def_app.mixins import DeserializableMixin
from local.models import SimilarSearchResult
from langchain_core.documents import Document
from utils.text_cleaning import TextCleaner
from pydantic import BaseModel
from datetime import datetime
from copy import deepcopy
from enum import Enum
import json
import re


class LinkedIssue(BaseModel):
    inwards: List[str] = []
    outwards: List[str] = []

    def as_dict(self):
        return {"inwards": self.inwards, "outwards": self.outwards}

    def __str__(self):
        return f"Inwards: {[''.join(self.inwards)]}, Outwards: {''.join(self.outwards)}"

    def to_json_string(self) -> str:
        return json.dumps(self.model_dump())

    @staticmethod
    def from_json(json_str: str | None) -> "LinkedIssue | None":
        """Convert JSON String to Linked Issue"""

        self = LinkedIssue(inwards=[], outwards=[])

        if not json_str:
            return self

        json_obj = json.loads(json_str)

        self.inwards = json_obj["inwards"] or []
        self.outwards = json_obj["outwards"] or []

        return self


class UserComment(BaseModel):
    user_comment: str = ""
    author: str = ""

    def as_dict(self, *args, **kwargs):
        return super().model_dump(*args, **kwargs)

    def __str__(self):
        return f"{self.author}: {self.user_comment}"

    def to_json_string(self) -> str:
        return json.dumps(self.model_dump())

    @staticmethod
    def from_json(json_comments: Any | None) -> "List[UserComment]":
        """Convert JSON String to User Comment"""

        res = []

        if not json_comments:
            return []

        json_comments = json.loads(json_comments)

        if not json_comments:
            return []

        for json_comment in json_comments:

            res.append(
                UserComment(
                    user_comment=json_comment["user_comment"] or "",
                    author=json_comment["author"] or "",
                )
            )

        return res


class Status(DeserializableMixin, Enum):
    """Jira Status Enum"""

    WAITING_FOR_REVIEW = "WAITING_FOR_REVIEW"
    NEED_PRECISION = "NEED_PRECISION"
    SUSPECTED_NFR = "SUSPECTED_NFR"
    IN_PROGRESS = "IN_PROGRESS"
    CONFIRMED = "CONFIRMED"
    IN_REVIEW = "IN_REVIEW"
    REVIEWED = "REVIEWED"
    REOPENED = "REOPENED"
    VERIFIED = "VERIFIED"
    RESOLVED = "RESOLVED"
    BLOCKED = "BLOCKED"
    CLOSED = "CLOSED"
    BUILT = "BUILT"
    OPEN = "OPEN"
    DONE = "DONE"

    def __str__(self) -> str:
        return self.value

    def to_string(self) -> str:
        return self.value

    @staticmethod
    def from_str(value: str) -> "Status":
        match value:
            case "WAITING_FOR_REVIEW":
                return Status.WAITING_FOR_REVIEW
            case "NEED_PRECISION":
                return Status.NEED_PRECISION
            case "SUSPECTED_NFR":
                return Status.SUSPECTED_NFR
            case "IN_PROGRESS":
                return Status.IN_PROGRESS
            case "CONFIRMED":
                return Status.CONFIRMED
            case "IN_REVIEW":
                return Status.IN_REVIEW
            case "REVIEWED":
                return Status.REVIEWED
            case "REOPENED":
                return Status.REOPENED
            case "VERIFIED":
                return Status.VERIFIED
            case "RESOLVED":
                return Status.RESOLVED
            case "BLOCKED":
                return Status.BLOCKED
            case "CLOSED":
                return Status.CLOSED
            case "BUILT":
                return Status.BUILT
            case "OPEN":
                return Status.OPEN
            case "DONE":
                return Status.DONE
            case _:
                raise ValueError(f"Unknown Status: {value}")

    @staticmethod
    def from_json(value: str) -> "Status":
        match value:
            case "Waiting for review":
                return Status.WAITING_FOR_REVIEW
            case "Need Precision":
                return Status.NEED_PRECISION
            case "Suspected NFR":
                return Status.SUSPECTED_NFR
            case "In Progress":
                return Status.IN_PROGRESS
            case "Confirmed":
                return Status.CONFIRMED
            case "In Review":
                return Status.IN_REVIEW
            case "Reviewed":
                return Status.REVIEWED
            case "Reopened":
                return Status.REOPENED
            case "Verified":
                return Status.VERIFIED
            case "Resolved":
                return Status.RESOLVED
            case "Blocked":
                return Status.BLOCKED
            case "Closed":
                return Status.CLOSED
            case "Built":
                return Status.BUILT
            case "Open":
                return Status.OPEN
            case "Done":
                return Status.DONE
            case _:
                raise ValueError(f"Unknown Status: {value}")

    def __eq__(self, other: Any) -> bool:
        return self.value == other

    def __ne__(self, other: Any) -> bool:
        return self.value != other


class Components(Enum):
    AI = "AI"
    CHIPStoMX = "CHIPStoMX"
    CORE = "CORE"
    DATA_MIGRATION = "DATA_MIGRATION"
    DATA_SERVICES = "DATA_SERVICES"
    FASTER_PAYMENTS = "FASTER_PAYMENTS"
    FED_ISO_MANT = "FED_ISO_MANT"
    FEDtoMX_ISO20022 = "FEDtoMX_ISO20022"
    FUSION_MX_TRANSFORM = "FUSION_MX_TRANSFORM"
    FX = "FX"
    GLRM = "GLRM"
    HIGH_VALUE = "HIGH_VALUE"
    IMMEDIATE_PAYMENT = "IMMEDIATE_PAYMENT"
    INFRASTRUCTURE = "INFRASTRUCTURE"
    MANT_FED_ISO = "MANT_FED_ISO"
    MASS_PAYMENT = "MASS_PAYMENT"
    MASS_PAYMENT_LC = "MASS_PAYMENT_LC"
    MT2MX2GO = "MT2MX2GO"
    NFT = "NFT"
    OPEN_API = "OPEN_API"
    ORDER_MANAGEMENT = "ORDER_MANAGEMENT"
    TRANSFORMER = "TRANSFORMER"
    UI_UX = "UI_UX"

    def __str__(self):
        return self.value

    def to_string(self):
        return self.value

    @staticmethod
    def from_str(value: str) -> Optional["Components"]:
        match value:
            case Components.AI:
                return Components.AI
            case Components.CHIPStoMX:
                return Components.CHIPStoMX
            case Components.CORE:
                return Components.CORE
            case Components.DATA_MIGRATION:
                return Components.DATA_MIGRATION
            case Components.DATA_SERVICES:
                return Components.DATA_SERVICES
            case Components.FASTER_PAYMENTS:
                return Components.FASTER_PAYMENTS
            case Components.FED_ISO_MANT:
                return Components.FED_ISO_MANT
            case Components.FEDtoMX_ISO20022:
                return Components.FEDtoMX_ISO20022
            case Components.FUSION_MX_TRANSFORM:
                return Components.FUSION_MX_TRANSFORM
            case Components.FX:
                return Components.FX
            case Components.GLRM:
                return Components.GLRM
            case Components.HIGH_VALUE:
                return Components.HIGH_VALUE
            case Components.IMMEDIATE_PAYMENT:
                return Components.IMMEDIATE_PAYMENT
            case Components.INFRASTRUCTURE:
                return Components.INFRASTRUCTURE
            case Components.MANT_FED_ISO:
                return Components.MANT_FED_ISO
            case Components.MASS_PAYMENT:
                return Components.MASS_PAYMENT
            case Components.MASS_PAYMENT_LC:
                return Components.MASS_PAYMENT_LC
            case Components.MT2MX2GO:
                return Components.MT2MX2GO
            case Components.NFT:
                return Components.NFT
            case Components.OPEN_API:
                return Components.OPEN_API
            case Components.ORDER_MANAGEMENT:
                return Components.ORDER_MANAGEMENT
            case Components.TRANSFORMER:
                return Components.TRANSFORMER
            case Components.UI_UX:
                return Components.UI_UX
            case _:
                return None

    @staticmethod
    def from_json(value: str) -> "Components | str":
        match value:
            case "AI":
                return Components.AI
            case "CHIPStoMX":
                return Components.CHIPStoMX
            case "Core":
                return Components.CORE
            case "Data Migration":
                return Components.DATA_MIGRATION
            case "Data Services":
                return Components.DATA_SERVICES
            case "Faster Payments":
                return Components.FASTER_PAYMENTS
            case "FED_ISO_MANT":
                return Components.FED_ISO_MANT
            case "FEDtoMX-ISO20022":
                return Components.FEDtoMX_ISO20022
            case "Fusion MX Transform":
                return Components.FUSION_MX_TRANSFORM
            case "FX":
                return Components.FX
            case "GLRM":
                return Components.GLRM
            case "High Value":
                return Components.HIGH_VALUE
            case "Immediate payment":
                return Components.IMMEDIATE_PAYMENT
            case "Infrastructure":
                return Components.INFRASTRUCTURE
            case "MANT_FED_ISO":
                return Components.MANT_FED_ISO
            case "Mass Payment":
                return Components.MASS_PAYMENT
            case "Mass Payment-LC":
                return Components.MASS_PAYMENT_LC
            case "MT2MX2Go":
                return Components.MT2MX2GO
            case "NFT":
                return Components.NFT
            case "Open API":
                return Components.OPEN_API
            case "Order Management":
                return Components.ORDER_MANAGEMENT
            case "Transformer":
                return Components.TRANSFORMER
            case "UI/UX":
                return Components.UI_UX
            case _:
                return value


class DefectOrigin(Enum):
    EXTERNAL_CUSTOMER = "EXTERNAL_CUSTOMER"
    DEVELOPER = "DEVELOPER"
    PORTED = "PORTED"
    NONE = "NONE"

    def __str__(self):
        return self.value

    def to_string(self):
        return self.value

    def __eq__(self, value: object) -> bool:
        return super().__eq__(value)

    def __ne__(self, value: object) -> bool:
        return super().__ne__(value)

    @staticmethod
    def from_str(value: str) -> Optional["DefectOrigin"]:
        match value:
            case DefectOrigin.EXTERNAL_CUSTOMER:
                return DefectOrigin.EXTERNAL_CUSTOMER
            case DefectOrigin.DEVELOPER:
                return DefectOrigin.DEVELOPER
            case DefectOrigin.PORTED:
                return DefectOrigin.PORTED
            case DefectOrigin.NONE:
                return DefectOrigin.NONE
            case _:
                return None

    @staticmethod
    def from_json(value: str) -> Optional["DefectOrigin"]:
        match value:
            case "External Customer":
                return DefectOrigin.EXTERNAL_CUSTOMER
            case "Developer":
                return DefectOrigin.DEVELOPER
            case "Ported":
                return DefectOrigin.PORTED
            case "None":
                return DefectOrigin.NONE
            case _:
                return None


class DefectClassfication(DeserializableMixin, Enum):
    REGRESSION_PREVIOUS_PROJECT = "REGRESSION_PREVIOUS_PROJECT"
    MAIN_PROJECT_FRSD = "MAIN_PROJECT_FRSD"
    NEW_FEATURE = "NEW_FEATURE"
    NOT_APPLICABLE = "NOT_APPLICABLE"
    DOCUMENTATION = "DOCUMENTATION"
    REGRESSION = "REGRESSION"
    PRODUCT = "PRODUCT"
    LATENT = "LATENT"
    NONE = "NONE"


class Severity(DeserializableMixin, Enum):
    CRITICAL = "CRITICAL"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    NONE = "NONE"
    LOW = "LOW"


class RootCause(DeserializableMixin, Enum):
    BUILD = "BUILD"
    CANCELLED = "CANCELLED"
    CODE_CHECKIN = "CODE_CHECKIN"
    CODE_MERGE = "CODE_MERGE"
    CONFIGURATION = "CONFIGURATION"
    DATAFIX = "DATAFIX"
    DB_SCRIPT = "DB_SCRIPT"
    DBA_ISSUE = "DBA_ISSUE"
    DESIGN = "DESIGN"
    DOCUMENTATION = "DOCUMENTATION"
    ENHANCEMENT = "ENHANCEMENT"
    EXPECTED_DIFFERENCE = "EXPECTED_DIFFERENCE"
    FUNCTIONAL_GAP = "FUNCTIONAL_GAP"
    INTEGRATION = "INTEGRATION"
    KNOWLEDGE_GAP = "KNOWLEDGE_GAP"
    MEMORY_OR_PERFORMANCE = "MEMORY_OR_PERFORMANCE"
    MISSED_IMPACT_SCENARIO = "MISSED_IMPACT_SCENARIO"
    MISSED_RETROFIT = "MISSED_RETROFIT"
    NOT_CODED_TO_SPEC = "NOT_CODED_TO_SPEC"
    NOT_REPRODUCIBLE = "NOT_REPRODUCIBLE"
    OTHER_PRODUCT_DEPENDENCY = "OTHER_PRODUCT_DEPENDENCY"
    PRODUCT_STANDARDS = "PRODUCT_STANDARDS"
    PROGRAMMING_ERROR = "PROGRAMMING_ERROR"
    PROGRAMMING_ERROR_CUSTOMER_SPECIFIC_ISSUE_CONFIG = (
        "PROGRAMMING_ERROR_CUSTOMER_SPECIFIC_ISSUE_CONFIG"
    )
    PROGRAMMING_ERROR_OTHERS = "PROGRAMMING_ERROR_OTHERS"
    REBASE_UPGRADE = "REBASE_UPGRADE"
    SETUP_ENVIRONMENT = "SETUP_ENVIRONMENT"
    UNSATISFACTORY_REQS = "UNSATISFACTORY_REQS"
    UNSATISFACTORY_SPECS = "UNSATISFACTORY_SPECS"

    def __str__(self):
        return self.value

    def to_string(self):
        return self.value

    @staticmethod
    def from_str(value: str) -> Optional["RootCause"]:
        match value:
            case RootCause.BUILD:
                return RootCause.BUILD
            case RootCause.CANCELLED:
                return RootCause.CANCELLED
            case RootCause.CODE_CHECKIN:
                return RootCause.CODE_CHECKIN
            case RootCause.CODE_MERGE:
                return RootCause.CODE_MERGE
            case RootCause.CONFIGURATION:
                return RootCause.CONFIGURATION
            case RootCause.DATAFIX:
                return RootCause.DATAFIX
            case RootCause.DB_SCRIPT:
                return RootCause.DB_SCRIPT
            case RootCause.DBA_ISSUE:
                return RootCause.DBA_ISSUE
            case RootCause.DESIGN:
                return RootCause.DESIGN
            case RootCause.DOCUMENTATION:
                return RootCause.DOCUMENTATION
            case RootCause.ENHANCEMENT:
                return RootCause.ENHANCEMENT
            case RootCause.EXPECTED_DIFFERENCE:
                return RootCause.EXPECTED_DIFFERENCE
            case RootCause.FUNCTIONAL_GAP:
                return RootCause.FUNCTIONAL_GAP
            case RootCause.INTEGRATION:
                return RootCause.INTEGRATION
            case RootCause.KNOWLEDGE_GAP:
                return RootCause.KNOWLEDGE_GAP
            case RootCause.MEMORY_OR_PERFORMANCE:
                return RootCause.MEMORY_OR_PERFORMANCE
            case RootCause.MISSED_IMPACT_SCENARIO:
                return RootCause.MISSED_IMPACT_SCENARIO
            case RootCause.MISSED_RETROFIT:
                return RootCause.MISSED_RETROFIT
            case RootCause.NOT_CODED_TO_SPEC:
                return RootCause.NOT_CODED_TO_SPEC
            case RootCause.NOT_REPRODUCIBLE:
                return RootCause.NOT_REPRODUCIBLE
            case RootCause.OTHER_PRODUCT_DEPENDENCY:
                return RootCause.OTHER_PRODUCT_DEPENDENCY
            case RootCause.PRODUCT_STANDARDS:
                return RootCause.PRODUCT_STANDARDS
            case RootCause.PROGRAMMING_ERROR:
                return RootCause.PROGRAMMING_ERROR
            case RootCause.PROGRAMMING_ERROR_CUSTOMER_SPECIFIC_ISSUE_CONFIG:
                return RootCause.PROGRAMMING_ERROR_CUSTOMER_SPECIFIC_ISSUE_CONFIG
            case RootCause.PROGRAMMING_ERROR_OTHERS:
                return RootCause.PROGRAMMING_ERROR_OTHERS
            case RootCause.REBASE_UPGRADE:
                return RootCause.REBASE_UPGRADE
            case RootCause.SETUP_ENVIRONMENT:
                return RootCause.SETUP_ENVIRONMENT
            case RootCause.UNSATISFACTORY_REQS:
                return RootCause.UNSATISFACTORY_REQS
            case RootCause.UNSATISFACTORY_SPECS:
                return RootCause.UNSATISFACTORY_SPECS
            case _:
                return None

    @staticmethod
    def from_json(value: str) -> "RootCause | None":
        match value:
            case "Build":
                return RootCause.BUILD
            case "Cancelled":
                return RootCause.CANCELLED
            case "Code Checkin":
                return RootCause.CODE_CHECKIN
            case "Code Merge":
                return RootCause.CODE_MERGE
            case "Configuration":
                return RootCause.CONFIGURATION
            case "Datafix":
                return RootCause.DATAFIX
            case "DB Script":
                return RootCause.DB_SCRIPT
            case "DBA Issue":
                return RootCause.DBA_ISSUE
            case "Design":
                return RootCause.DESIGN
            case "Documentation":
                return RootCause.DOCUMENTATION
            case "Enhancement":
                return RootCause.ENHANCEMENT
            case "Expected Difference":
                return RootCause.EXPECTED_DIFFERENCE
            case "Functional Gap":
                return RootCause.FUNCTIONAL_GAP
            case "Integration":
                return RootCause.INTEGRATION
            case "Knowledge Gap":
                return RootCause.KNOWLEDGE_GAP
            case "Memory or Performance":
                return RootCause.MEMORY_OR_PERFORMANCE
            case "Missed Impact scenario":
                return RootCause.MISSED_IMPACT_SCENARIO
            case "Missed Retrofit":
                return RootCause.MISSED_RETROFIT
            case "Not Coded to Spec":
                return RootCause.NOT_CODED_TO_SPEC
            case "Not reproducible":
                return RootCause.NOT_REPRODUCIBLE
            case "Other Product Dependency":
                return RootCause.OTHER_PRODUCT_DEPENDENCY
            case "Product Standards":
                return RootCause.PRODUCT_STANDARDS
            case "Programming Error":
                return RootCause.PROGRAMMING_ERROR
            case "Programming Error - Customer specific issue / config":
                return RootCause.PROGRAMMING_ERROR_CUSTOMER_SPECIFIC_ISSUE_CONFIG
            case "Programming Error - Others":
                return RootCause.PROGRAMMING_ERROR_OTHERS
            case "Rebase/Upgrade":
                return RootCause.REBASE_UPGRADE
            case "Setup / Environment":
                return RootCause.SETUP_ENVIRONMENT
            case "Unsatisfactory Reqs":
                return RootCause.UNSATISFACTORY_REQS
            case "Unsatisfactory Specs":
                return RootCause.UNSATISFACTORY_SPECS
            case _:
                return None


class Teams(DeserializableMixin, Enum):
    CLASSIC_DEV = "CLASSIC_DEV"
    CLASSIC_QA = "CLASSIC_QA"
    CUSTOMERS = "CUSTOMERS"
    FRONTLINE = "FRONTLINE"
    SERVICES = "SERVICES"
    PROD_DEV = "PROD_DEV"
    T_WRITER = "T_WRITER"
    PROD_QA = "PROD_QA"
    PROD_PO = "PROD_PO"
    DEVOPS = "DEVOPS"
    QA = "QA"

    @staticmethod
    def from_json(json_str: str) -> Optional["Teams"]:
        match json_str:
            case "Classic DEV":
                return Teams.CLASSIC_DEV
            case "Classic QA":
                return Teams.CLASSIC_QA
            case "Customers":
                return Teams.CUSTOMERS
            case "Frontline":
                return Teams.FRONTLINE
            case "Services":
                return Teams.SERVICES
            case "Prod_DEV":
                return Teams.PROD_DEV
            case "T_writer":
                return Teams.T_WRITER
            case "Prod_QA":
                return Teams.PROD_QA
            case "Prod_PO":
                return Teams.PROD_PO
            case "Devops":
                return Teams.DEVOPS
            case "QA":
                return Teams.QA
            case _:
                return None


class SourceDetected(DeserializableMixin, Enum):

    BETA = "BETA"
    DEVELOPMENT = "DEVELOPMENT"
    DOCUMENTATION = "DOCUMENTATION"
    EARLY_ADOPTER = "EARLY_ADOPTER"
    IMPLEMENTATION_PS = "IMPLEMENTATION_PS"
    LIVE_IMPLEMENTATION = "LIVE_IMPLEMENTATION"
    PRODUCTION_GA = "PRODUCTION_GA"
    QA_CAMPAIGN = "QA_CAMPAIGN"

    @staticmethod
    def from_json(json_str: str) -> Optional["SourceDetected"]:
        match json_str:
            case "Beta":
                return SourceDetected.BETA
            case "Development":
                return SourceDetected.DEVELOPMENT
            case "Documentation":
                return SourceDetected.DOCUMENTATION
            case "Early Adopter":
                return SourceDetected.EARLY_ADOPTER
            case "Implementation - PS":
                return SourceDetected.IMPLEMENTATION_PS
            case "Live & Implementation":
                return SourceDetected.LIVE_IMPLEMENTATION
            case "Production / GA":
                return SourceDetected.PRODUCTION_GA
            case "QA campaign":
                return SourceDetected.QA_CAMPAIGN
            case _:
                return None


class Priority(DeserializableMixin, Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    LOW = "LOW"
    MEDIUM = "MEDIUM"


class JiraModel(BaseModel):
    defect_id: str = ""
    project_key: str = ""
    summary: Optional[str] = None
    status: Status = Status.OPEN  # Filterable
    priority: str = ""
    resolution: Optional[str] = None
    created_date: int = 0
    updated_date: Optional[int] = None  # Filterable
    resolved_date: Optional[int] = None
    affected_versions: List[str] = []
    fix_versions: str = ""  # Filterable
    components: str = ""  # Filterable
    due_date: Optional[int] = None
    linked_issues: Optional[LinkedIssue] = None
    environment: Optional[str] = None
    description: Optional[str] = None
    labels: str = ""  # Filterable
    found_in: str = ""  # Filterable
    source_detected: Optional[SourceDetected] = None
    reporter: str = ""  # Filterable
    developers: str = ""  # Filterable
    scrum_team: str = ""  # Filterable
    teams: str = ""  # Filterable
    customer: str = ""  # Filterable
    sprint: Optional[str] = None
    project_type: Optional[str] = None
    suspected_nfr_date: Optional[int] = None
    defect_origin: Optional[str] = None  # Filterable
    confirmed_date: Optional[int] = None
    reopen_date: Optional[int] = None
    defect_classification: Optional[DefectClassfication] = None  # Filterable
    scenario: Optional[str] = None
    root_cause: Optional[RootCause] = None  # Filterable
    resolution_details: Optional[str] = None
    acceptance: Optional[str] = None
    root_cause_analysis: Optional[str] = None
    root_cause_analysis_details: Optional[str] = None
    severity: Optional[Severity] = None  # Filterable
    closed_date: Optional[int] = None
    replication_steps: Optional[str] = None
    comments: List[UserComment] = []

    def as_document(self) -> Document:
        """
        Convert Jira Model to Document
        All Searchable Fields are added as content
        All Fields are added as metadata
        """

        return Document(
            page_content=self.summary or "",
            metadata={
                "defect_id": self.defect_id or "",
                "project_key": self.project_key or "",
                "summary": self.summary or "",
                "status": self.status.to_string() if self.status else "",
                "priority": self.priority or "",
                "resolution": self.resolution or "",
                "created_date": self.created_date or "",
                "updated_date": self.updated_date or "",
                "resolved_date": self.resolved_date or "",
                "affected_versions": json.dumps(self.affected_versions or []),
                "fix_versions": self.fix_versions,
                "components": self.components,
                "due_date": self.due_date or "",
                "linked_issues": json.dumps(
                    self.linked_issues.model_dump()
                    if self.linked_issues
                    else {"inwards": [], "outwards": []}
                ),
                "environment": self.environment or "",
                "description": self.description or "",
                "labels": self.labels,
                "sprint": self.sprint or "",
                "project_type": self.project_type or "",
                "suspected_nfr_date": self.suspected_nfr_date or "",
                "defect_origin": (self.defect_origin if self.defect_origin else ""),
                "confirmed_date": self.confirmed_date or "",
                "reopen_date": self.reopen_date or "",
                "defect_classification": (
                    self.defect_classification.to_string()
                    if self.defect_classification
                    else ""
                ),
                "scenario": self.scenario or "",
                "root_cause": self.root_cause.to_string() if self.root_cause else "",
                "resolution_details": self.resolution_details or "",
                "acceptance": self.acceptance or "",
                "root_cause_analysis": self.root_cause_analysis or "",
                "root_cause_analysis_details": self.root_cause_analysis_details or "",
                "severity": self.severity.to_string() if self.severity else "",
                "closed_date": self.closed_date or "",
                "replication_steps": self.replication_steps or "",
                "comments": json.dumps(
                    [comment.model_dump() for comment in self.comments]
                    if self.comments
                    else []
                ),
                "found_in": self.found_in or "",
                "source_detected": (
                    self.source_detected.to_string() if self.source_detected else ""
                ),
                "reporter": self.reporter or "",
                "developers": self.developers or "",
                "scrum_team": self.scrum_team or "",
                "teams": self.teams or "",
                "customer": self.customer or "",
            },
        )

    def as_reference(self) -> Any:
        """Return as Reference String"""

        return json.loads(
            json.dumps(
                {
                    "defect_summary": self.summary,
                    "status": self.status.value,
                    "components": self.components,
                    "fix_versions": self.fix_versions,
                    "source": {
                        "defect_id": self.defect_id,
                        "url": f"https://jira.finastra.com/browse/{self.defect_id}",
                    },
                }
            )
        )

    def to_json_string(self) -> str:
        return json.dumps(self.model_dump())

    @staticmethod
    def from_json(json_str: str | None) -> "JiraModel | None":
        """Convert JSON String to Jira Model"""
        if not json_str:
            return None

        json_obj = json.loads(json_str)
        return JiraModel(**json_obj)

    @staticmethod
    def from_jira_json(json_str: Any) -> "JiraModel | None":
        """Convert Jira JSON Response to Jira Model"""

        if "fields" not in json_str:
            return None

        self = JiraModel()

        fields = self._get_value_from_json(json_str, "fields")

        self.defect_id = self._get_value_from_json(json_str, "key") or ""
        self.project_key = (
            self._get_value_from_json(
                self._get_value_from_json(fields, "project"), "key"
            )
            or ""
        )
        self.summary = self._get_value_from_json(fields, "summary") or ""

        self.status = (
            Status.from_json(
                self._get_value_from_json(
                    self._get_value_from_json(fields, "status"), "name"
                )
                or ""
            )
            or Status.OPEN
        )

        self.priority = (
            self._get_value_from_json(
                self._get_value_from_json(fields, "priority"), "name"
            )
        ) or ""

        self.resolution = self._get_value_from_json(
            self._get_value_from_json(fields, "resolution"), "name"
        )

        self.created_date = JiraModel.get_date_from_datetime(
            self._get_value_from_json(fields, "created")
        )
        self.updated_date = JiraModel.get_date_from_datetime(
            self._get_value_from_json(fields, "updated")
        )
        self.resolved_date = JiraModel.get_date_from_datetime(
            self._get_value_from_json(fields, "customfield_12900")
        )

        affected_versions = self._get_value_from_json(fields, "versions")

        if affected_versions:
            self.affected_versions = [  # type: ignore
                (self._get_value_from_json(version, "name"))
                for version in affected_versions
            ]

        fix_versions = self._get_value_from_json(fields, "fixVersions")

        if fix_versions:
            self.fix_versions = [  # type: ignore
                (self._get_value_from_json(version, "name")) for version in fix_versions
            ]

        components = self._get_value_from_json(fields, "components")

        if components:
            self.components = ", ".join(
                [  # type: ignore
                    (
                        Components.from_json(
                            self._get_value_from_json(component, "name") or ""
                        ).to_string()  # type: ignore
                        if isinstance(
                            Components.from_json(
                                self._get_value_from_json(component, "name") or ""
                            ),
                            Components,
                        )
                        else Components.from_json(
                            self._get_value_from_json(component, "name") or ""
                        )
                    )
                    for component in components
                ]
            )

        self.due_date = JiraModel.get_date_from_datetime(
            self._get_value_from_json(fields, "duedate")
        )

        inwards = []
        outwards = []

        issuelinks = self._get_value_from_json(fields, "issuelinks")

        if issuelinks:
            for link in issuelinks:
                if "inwardIssue" in link:
                    inwards.append(
                        self._get_value_from_json(link["inwardIssue"], "key") or ""
                    )
                if "outwardIssue" in link:
                    outwards.append(
                        self._get_value_from_json(link["outwardIssue"], "key") or ""
                    )

        self.linked_issues = LinkedIssue(inwards=inwards, outwards=outwards)

        self.environment = self._get_value_from_json(fields, "environment")
        self.description = (
            TextCleaner(self._get_value_from_json(fields, "description") or "")
            .html2markdown()
            .remove_non_utf8_chars()
            .remove_html_code()
            .clean_markdown()
            .get_text()
        )
        self.labels = ", ".join(
            [
                str(label)
                for label in self._get_value_from_json(fields, "labels") or []
                if label is not None
            ]
        )
        self.project_type = self._get_value_from_json(
            self._get_value_from_json(fields, "customfield_16605"), "value"
        )
        self.suspected_nfr_date = JiraModel.get_date_from_datetime(
            self._get_value_from_json(fields, "customfield_20400")
        )

        self.defect_origin = self._get_value_from_json(
            self._get_value_from_json(fields, "customfield_13405"), "value"
        )

        self.confirmed_date = JiraModel.get_date_from_datetime(
            self._get_value_from_json(fields, "customfield_13081")
        )
        self.reopen_date = JiraModel.get_date_from_datetime(
            self._get_value_from_json(fields, "customfield_13400")
        )

        self.root_cause = RootCause.from_json(
            self._get_value_from_json(
                self._get_value_from_json(fields, "customfield_13078"), "value"
            )
            or ""
        )

        self.resolution_details = (
            TextCleaner(self._get_value_from_json(fields, "customfield_10120") or "")
            .html2markdown()
            .remove_non_utf8_chars()
            .remove_html_code()
            .clean_markdown()
            .get_text()
        )
        self.defect_classification = DefectClassfication.from_json(
            self._get_value_from_json(
                self._get_value_from_json(fields, "customfield_15900"), "value"
            )
            or ""
        )  # type: ignore

        root_cause_analysis = self._get_value_from_json(fields, "customfield_18600")

        if root_cause_analysis:
            if self._get_value_from_json(root_cause_analysis, "value"):
                self.root_cause_analysis = self._get_value_from_json(
                    root_cause_analysis, "value"
                )
            else:
                self.root_cause_analysis = (
                    # type: ignore
                    ""
                    + " - "
                    + self._get_value_from_json(
                        root_cause_analysis, "child"
                    )  # type: ignore
                    if self._get_value_from_json(root_cause_analysis, "child")
                    else ""
                )

        self.root_cause_analysis_details = (
            TextCleaner(self._get_value_from_json(fields, "customfield_14900") or "")
            .html2markdown()
            .remove_non_utf8_chars()
            .remove_html_code()
            .clean_markdown()
            .get_text()
        )

        severity = self._get_value_from_json(
            self._get_value_from_json(fields, "customfield_10200"), "value"
        )

        if severity:
            self.severity = Severity.from_json(
                self._get_value_from_json(
                    self._get_value_from_json(fields, "customfield_10200"), "value"
                )
                or ""
            )  # type: ignore

        self.closed_date = JiraModel.get_date_from_datetime(
            self._get_value_from_json(fields, "customfield_13000")
        )
        self.replication_steps = (
            TextCleaner(self._get_value_from_json(fields, "customfield_10302") or "")
            .html2markdown()
            .remove_non_utf8_chars()
            .remove_html_code()
            .clean_markdown()
            .get_text()
        )
        comments = self._get_value_from_json(
            self._get_value_from_json(fields, "comment"), "comments"
        )

        if comments:
            self.comments = [
                UserComment(
                    user_comment=(
                        TextCleaner(self._get_value_from_json(comment, "body") or "")
                        .html2markdown()
                        .remove_non_utf8_chars()
                        .remove_html_code()
                        .clean_markdown()
                        .get_text()
                    ),
                    author=(
                        self._get_value_from_json(
                            self._get_value_from_json(comment, "author"),
                            "displayName",
                        )
                        or ""
                    ),
                )
                for comment in comments
            ]

        self.found_in = (
            self._get_value_from_json(
                self._get_value_from_json(fields, "customfield_10111"), "name"
            )
            or ""
        )

        self.source_detected = SourceDetected.from_json(
            self._get_value_from_json(
                self._get_value_from_json(fields, "customfield_10110"), "value"
            )
            or ""
        )

        self.reporter = (
            self._get_value_from_json(
                self._get_value_from_json(fields, "reporter"), "emailAddress"
            )
            or ""
        )

        developers = self._get_value_from_json(fields, "customfield_13502")

        if developers:
            self.developers = (
                ", ".join(
                    [
                        str(email)
                        for email in (
                            self._get_value_from_json(developer, "emailAddress")
                            for developer in developers
                        )
                        if email is not None
                    ]
                )
                or ""
            )

        scrum_team = self._get_value_from_json(fields, "customfield_16100")

        if scrum_team:
            self.scrum_team = (
                ", ".join(
                    [
                        str(team)
                        for team in (
                            self._get_value_from_json(team, "value")
                            for team in scrum_team
                        )
                        if team is not None
                    ]
                )
                or ""
            )

        teams = self._get_value_from_json(fields, "customfield_18800")

        if teams:
            self.teams = (
                ", ".join(
                    [
                        str(team)
                        for team in (
                            self._get_value_from_json(team, "value") for team in teams
                        )
                        if team is not None
                    ]
                )
                or ""
            )

        customer = self._get_value_from_json(fields, "customfield_10802")

        if customer:
            self.customer = (
                ", ".join(
                    [
                        str(cust)
                        for cust in (
                            self._get_value_from_json(cust, "value")
                            for cust in customer
                        )
                        if cust is not None
                    ]
                )
                or ""
            )

        sprints = []
        for sprint in self._get_value_from_json(fields, "customfield_12800") or []:
            sprints.extend(
                [name.split("=")[1] for name in re.findall(r"name=\w+", sprint)]
            )
        self.scenario = (
            TextCleaner(self._get_value_from_json(fields, "customfield_10117") or "")
            .html2markdown()
            .remove_non_utf8_chars()
            .remove_html_code()
            .clean_markdown()
            .get_text()
        )

        return self

    @staticmethod
    def from_jira_json_bulk(json_bulk_data: Any) -> "List[JiraModel]":
        """Convert Jira JSON Response to Bulk Jira Model"""

        res = []

        for issue in json_bulk_data["issues"]:
            jira_model = JiraModel().from_jira_json(issue)
            if jira_model:
                res.append(jira_model)

        return res

    @staticmethod
    def from_jira_db_response(
        jira_db_response: SimilarSearchResult,
    ) -> "List[JiraModel]":
        """Convert Jira JSON Response to Jira Model"""

        metadatas = jira_db_response["metadatas"]

        if not metadatas:
            return []

        jira_models = []

        def json_string_to_list(json_str: str | None) -> List[str]:
            """Convert JSON String to List"""

            if not json_str:
                return []

            try:
                json_obj = json.loads(json_str)

                if type(json_obj) == list:
                    return json_obj
                else:
                    return [json_str]

            except Exception as e:
                return []

        def json_string_to_list_string(json_str: str | None) -> str:
            if not json_str:
                return ""

            try:
                json_obj = json.loads(json_str)

                if type(json_obj) == list:
                    return ", ".join(json_obj)
                else:
                    return json_obj
            except Exception as e:
                return ""

        for metadata in metadatas:

            jira_model = JiraModel()

            jira_model.defect_id = metadata.get("defect_id") or ""
            jira_model.project_key = metadata.get("project_key") or ""
            jira_model.summary = metadata.get("summary") or ""
            jira_model.status = Status.from_str(metadata.get("status") or "")
            jira_model.priority = metadata.get("priority") or ""
            jira_model.resolution = metadata.get("resolution") or ""
            jira_model.created_date = int(metadata.get("created_date") or "-1") or -1
            jira_model.updated_date = int(metadata.get("updated_date") or "-1") or -1
            jira_model.resolved_date = int(metadata.get("resolved_date") or "-1") or -1
            jira_model.affected_versions = json_string_to_list(
                metadata.get("affected_versions")
            )
            jira_model.fix_versions = metadata.get("fix_versions") or ""
            jira_model.components = metadata.get("components") or ""
            jira_model.due_date = int(metadata.get("due_date") or "-1") or -1
            jira_model.linked_issues = LinkedIssue.from_json(
                metadata.get("linked_issues")
            )
            jira_model.environment = metadata.get("environment") or ""
            jira_model.description = metadata.get("description") or ""
            jira_model.labels = metadata.get("labels") or ""
            jira_model.sprint = metadata.get("sprint") or ""
            jira_model.project_type = metadata.get("project_type") or ""
            jira_model.suspected_nfr_date = (
                int(metadata.get("suspected_nfr_date") or "-1") or -1
            )
            jira_model.defect_origin = metadata.get("defect_origin")
            jira_model.confirmed_date = (
                int(metadata.get("confirmed_date") or "-1") or -1
            )
            jira_model.reopen_date = int(metadata.get("reopen_date") or "-1") or -1
            jira_model.root_cause = RootCause.from_str(metadata.get("root_cause") or "")
            jira_model.defect_classification = DefectClassfication.from_str(
                metadata.get("defect_classification") or ""
            )  # type: ignore
            jira_model.resolution_details = metadata.get("resolution_details") or ""
            jira_model.scenario = metadata.get("scenario") or ""
            jira_model.acceptance = metadata.get("acceptance") or ""
            jira_model.root_cause_analysis = metadata.get("root_cause_analysis") or ""
            jira_model.root_cause_analysis_details = (
                metadata.get("root_cause_analysis_details") or ""
            )
            jira_model.severity = Severity.from_str(
                metadata.get("severity") or ""
            )  # type: ignore
            jira_model.closed_date = int(metadata.get("closed_date") or "-1") or -1
            jira_model.replication_steps = metadata.get("replication_steps") or ""
            jira_model.comments = UserComment.from_json(metadata.get("comments"))

            jira_model.found_in = metadata.get("found_in") or ""
            jira_model.source_detected = SourceDetected.from_str(
                metadata.get("source_detected") or ""
            )  # type: ignore
            jira_model.reporter = metadata.get("reporter") or ""
            jira_model.developers = metadata.get("developers") or ""
            jira_model.scrum_team = metadata.get("scrum_team") or ""
            jira_model.teams = metadata.get("teams") or ""
            jira_model.customer = metadata.get("customer") or ""

            jira_models.append(deepcopy(jira_model))

        return jira_models

    @staticmethod
    def _get_value_from_json(json_str: Any, key: str) -> Optional[Any]:
        """Get Value from JSON"""
        return (
            json_str[key]
            if json_str and key in json_str and json_str[key] is not None
            else None
        )

    @staticmethod
    def get_date_from_datetime(datetime_str: str | None) -> int:
        """Get Date from Datetime String
        Handles both datetime and date formats and converts to Unix epoch.
        """
        if datetime_str is None:
            return -1

        try:
            if "T" in datetime_str:
                # Handle datetime format
                dt = datetime_str.split(".")[0]
                notzdt = dt.split("T")
                dt = datetime.strptime(f"{notzdt[0]} {notzdt[1]}", "%Y-%m-%d %H:%M:%S")
            else:
                # Handle date format
                dt = datetime.strptime(datetime_str, "%Y-%m-%d")

            return int(dt.timestamp())
        except ValueError:
            return -1

    @staticmethod
    def get_datetime_from_epoch(datetime_int: int | None) -> Optional[datetime]:
        """Get Date from Datetime String
        Split the String at T and get the first Value
        """

        if datetime_int is None:
            return None

        dt = datetime.fromtimestamp(datetime_int)

        return dt


class JiraFields(Enum):
    """Jira Fields Names Enum"""

    PROJECT_KEY = ("project_key", "Project Type Key")
    SUMMARY = (
        "summary",
        "Defect Summary is usually one or two lines description of the defect found. ",
    )
    STATUS = (
        "status",
        "For defects we have different statuses like Open, In Progress,  SNFR or NFR referes to Suspected No Code fix required. Blocked status means that the defect is blocked on some other team like DevOps or Product team or Customer. Other statuses are REviewed, Verified, and Closed.  ",
    )
    PRIORITY = (
        "priority",
        "This is a priority of the defect. This is not directly used by development teams.",
    )
    RESOLUTION = (
        "resolution",
        "Defect Resolution is a type of resolution like fixed by code, system configuration, or business configuration etc.",
    )
    CREATED_DATE = (
        "created_date",
        "Defect Create Date, in YYYY-MM-DD format i.e 2024-02-14",
    )
    UPDATED_DATE = (
        "updated_date",
        "Defect Update Date, in YYYY-MM-DD format i.e 2024-02-14",
    )
    RESOLVED_DATE = (
        "resolved_date",
        "Defect Resolved Date, in YYYY-MM-DD format i.e 2024-02-14",
    )
    AFFECTED_VERSIONS = ("affected_version", "List Defect Affected Versions")
    FIX_VERSIONS = (
        "fix_versions",
        "List of Defect Fix Versions. This is an important field in Jira. This is a version of our GPP product or it could also be cusotmer branch where defect is directly checked in. This field can have multiple values. Since developer may fix defect on specific product version as well as on customer specific branch. We use PRE or FREEZE wrods in customer specific branch names. e.g. Morgan_Freeze. In this example Morgan is the name of the cusotmer and Freeze is the branch specific to Morgan customer",
    )
    COMPONENTS = (
        "components",
        "In Global Pay Plus also referred as GPP product, we have 3 main components also referred as rails. They are viz. 'High Value' or HV, 'Immidiate Payments' or IP, and 'Mass Pay' or MP. Apart from these we also have few common componants like Infra, DevOps, User Interface or UI etc.",
    )
    DUE_DATE = (
        "due_date",
        "Defect Due Date, in YYYY-MM-DD format i.e 2024-02-14. This is used sometimes by some teams to define due date for resolution of the defect",
    )
    LINKED_ISSUES = (
        "linked_issues",
        "Linked issues are child issues or parent issues linked with the realted defect",
    )
    ENVIRONMENT = ("environment", "Defect Environment, QA, PROD, DEV etc")
    DESCRIPTION = (
        "description",
        "This is detailed description of the defect. Normally a person that is raising a new defect adds defect recreation steps in this section. They are also expected to add MID which is a unique 'payment id' for which defect is found. This MID is used to analyze traces or logs of the system to find root cause faster.",
    )
    LABELS = (
        "labels",
        "List of Defect Labels a a free flow text. One of the important labels is 'Passed_Gatekeeping'. If the defect has this label then it means that product owner as well as development lead has looked at the defect and confirmed that the defect is indeed exists in the system and needs to be fixed.",
    )
    SPRINT = (
        "sprint",
        "Sprint field is used for specific sprint denoting a defect fixing period of one week.For development projects this field also used to show 3 week period of development",
    )
    PROJECT_TYPE = ("project_type", "Project Type field is not regularly used")
    SUSPECTED_NFR_DATE = (
        "suspected_nfr_date",
        "Suspected NFR Date (SNFR or NFR), in YYYY-MM-DD format i.e 2024-02-14",
    )
    DEFECT_ORIGIN = (
        "defect_origin",
        "Defect Origin means if the defect is Internal (Development) or External Customer. ",
    )
    CONFIRMED_DATE = (
        "confirmed_date",
        "Confirmed Date, in YYYY-MM-DD format i.e 2024-02-14",
    )
    REOPEN_DATE = ("reopen_date", "Reopen Date, in YYYY-MM-DD format i.e 2024-02-14")
    DEFECT_CLASSIFICATION = (
        "defect_classification",
        "Defect Classification has details like Latent, Regression etc.",
    )
    SCENARIO = ("scenario", "Defect Scenario")
    ROOT_CAUSE = ("root_cause", "Defect Root Cause")
    RESOLUTION_DETAILS = ("resolution_details", "Defect Resolution Details")
    ACCEPTANCE = ("acceptance", "Defect Acceptance")
    SEVERITY = ("severity", "Defect Severity")
    CLOSED_DATE = (
        "closed_date",
        "Defect Closed Date, in YYYY-MM-DD format i.e 2024-02-14",
    )
    REPLICATION_STEPS = ("replication_steps", "Defect Replication Steps")
    COMMENTS = ("comments", "List of Defect Comments")
    FOUND_IN = (
        "found_in",
        "Field contains two types of information. Viz. Customer implementation which is usually country or component like HV, IP, MP etc.and Product version. E.g MUFG_US_4.7 means defect is related to MUFG customer, US is implementation of MUFG customer and product version is 4.7.",
    )
    SOURCE_DETECTED = (
        "source_detected",
        "Source defected field in Jira mainly contains where defect is found. E.g QA campaign, Implementation - PS, Production / GA etc.",
    )
    REPORTER = (
        "reporter",
        "Reporter is the user id or name of the person who has raised the defect.",
    )
    DEVELOPER = (
        "developers",
        "This may have multiple entries. This has user id or name of the person who has resolved the defect. I.e. the person who has changed the status of the defect as Resolved.",
    )
    SCRUM_TEAM = (
        "scrum_team",
        "This field has name of the development team that works on resolution of the defect.",
    )
    TEAMS = (
        "teams",
        "This field is associated with Assignee’s team. Teams are Services, Customers, Prod_Dev etc.",
    )
    CUSTOMER = ("customer", "This field has names of customers.")

    def __init__(self, value, hint):
        self._value_ = value
        self.hint = hint

    def __str__(self) -> str:
        return self.value

    @staticmethod
    def from_str(value: str) -> "JiraFields":
        match value:
            case "project_key":
                return JiraFields.PROJECT_KEY
            case "summary":
                return JiraFields.SUMMARY
            case "status":
                return JiraFields.STATUS
            case "priority":
                return JiraFields.PRIORITY
            case "resolution":
                return JiraFields.RESOLUTION
            case "created_date":
                return JiraFields.CREATED_DATE
            case "updated_date":
                return JiraFields.UPDATED_DATE
            case "resolved_date":
                return JiraFields.RESOLVED_DATE
            case "affected_version":
                return JiraFields.AFFECTED_VERSIONS
            case "fix_version":
                return JiraFields.FIX_VERSIONS
            case "components":
                return JiraFields.COMPONENTS
            case "due_date":
                return JiraFields.DUE_DATE
            case "linked_issues":
                return JiraFields.LINKED_ISSUES
            case "environment":
                return JiraFields.ENVIRONMENT
            case "description":
                return JiraFields.DESCRIPTION
            case "labels":
                return JiraFields.LABELS
            case "sprint":
                return JiraFields.SPRINT
            case "project_type":
                return JiraFields.PROJECT_TYPE
            case "suspected_nfr_date":
                return JiraFields.SUSPECTED_NFR_DATE
            case "defect_origin":
                return JiraFields.DEFECT_ORIGIN
            case "confirmed_date":
                return JiraFields.CONFIRMED_DATE
            case "reopen_date":
                return JiraFields.REOPEN_DATE
            case "defect_classification":
                return JiraFields.DEFECT_CLASSIFICATION
            case "scenario":
                return JiraFields.SCENARIO
            case "root_cause":
                return JiraFields.ROOT_CAUSE
            case "resolution_details":
                return JiraFields.RESOLUTION_DETAILS
            case "acceptance":
                return JiraFields.ACCEPTANCE
            case "severity":
                return JiraFields.SEVERITY
            case "closed_date":
                return JiraFields.CLOSED_DATE
            case "replication_steps":
                return JiraFields.REPLICATION_STEPS
            case "comments":
                return JiraFields.COMMENTS
            case "found_in":
                return JiraFields.FOUND_IN
            case "source_detected":
                return JiraFields.SOURCE_DETECTED
            case "reporter":
                return JiraFields.REPORTER
            case "developer":
                return JiraFields.DEVELOPER
            case "scrum_team":
                return JiraFields.SCRUM_TEAM
            case "teams":
                return JiraFields.TEAMS
            case "customer":
                return JiraFields.CUSTOMER
            case _:
                raise ValueError(f"Unknown JiraField: {value}")


class ChatHistory(BaseModel):
    """Chat History Model"""

    type: Literal["system", "human", "ai"] = "system"
    content: str = ""

    def as_dict(self):
        return {"type": self.type, "content": self.content}

    @staticmethod
    def from_json(json_response) -> "List[ChatHistory]":

        if not json_response:
            return []

        chat_histories = []

        for jsresponse in json_response:
            chat_history = ChatHistory()

            chat_history.type = jsresponse.get("type") or "system"
            chat_history.content = jsresponse.get("content") or ""

            chat_histories.append(chat_history)

        return chat_histories


class UserFeedBack(BaseModel):
    """User Feedback Model"""

    # TODO: Switch to ORM

    id: int = 0
    email: str = ""
    response: str = ""
    feedback: str = ""
    impression: bool = True
    chat_history: List[ChatHistory] = []

    def as_dict(self):
        return {
            "id": self.id,
            "email": self.email,
            "response": self.response,
            "feedback": self.feedback,
            "impression": self.impression,
            "chat_history": self.chat_history,
        }

    def to_json_string(self) -> str:
        return json.dumps(self.model_dump())

    @staticmethod
    def from_json(json_response) -> "UserFeedBack":

        user_feedback = UserFeedBack()

        user_feedback.id = json_response.get("id") or 0
        user_feedback.email = json_response.get("email") or ""
        user_feedback.response = json_response.get("response") or ""
        user_feedback.feedback = json_response.get("feedback") or ""
        user_feedback.impression = json_response.get("impression") or False
        user_feedback.chat_history = ChatHistory.from_json(
            json_response.get("chat_history")
        )

        return user_feedback


class User(BaseModel):
    """User Model"""

    login: str = ""

    def as_dict(self):
        return {"login": self.login}

    def to_json_string(self) -> str:
        return json.dumps(self.model_dump())

    @staticmethod
    def from_json(json_response: Any) -> "User":
        """Convert JSON String to User"""

        user = User()

        user.login = json_response.get("login") if json_response else ""

        return user


class GitHubPullRequest(BaseModel):
    """GitHub Pull Request Model"""

    url: str = ""
    number: int = 0
    state: str = ""
    title: str = ""
    created_at: str = ""
    closed_at: Optional[str] = None
    created_by: User = User()
    merged_by: Optional[User] = None

    def as_dict(self):
        return {
            "url": f"https://github.com/{GITHUB_REPO_OWNER}/{GITHUB_REPO_NAME}/pull/{self.number}",
            "number": self.number,
            "state": self.state,
            "title": self.title,
            "created_at": self.created_at,
            "closed_at": self.closed_at,
            "created_by": self.created_by.login if self.created_by else None,
            "merged_by": self.merged_by.login if self.merged_by else None,
        }

    def to_json_string(self) -> str:
        return json.dumps(self.model_dump())

    def as_context(self) -> str:
        return json.dumps(
            {
                "title": self.title,
                "created_at": self.created_at,
                "created_by": self.created_by.login,
                "state": self.state,
                "closed_at": self.closed_at,
                "merged_by": self.merged_by.login if self.merged_by else "",
                "url": f"https://github.com/{GITHUB_REPO_OWNER}/{GITHUB_REPO_NAME}/pull/{self.number}",
            }
        )

    @staticmethod
    def from_json(json_response: Any) -> "GitHubPullRequest":
        """Convert JSON String to GitHub Pull Request"""

        pull_request = GitHubPullRequest()

        pull_request.url = json_response.get("url") or ""
        pull_request.number = json_response.get("number") or 0
        pull_request.state = json_response.get("state") or ""
        pull_request.title = json_response.get("title") or ""
        pull_request.created_at = json_response.get("created_at") or ""
        pull_request.closed_at = json_response.get("closed_at")
        pull_request.created_by = User.from_json(json_response.get("user"))
        pull_request.merged_by = User.from_json(json_response.get("merged_by") or "")

        return pull_request


class GitHubPullRequestFileChanges(BaseModel):
    """File Changes Model"""

    filename: str = ""
    additions: int = 0
    deletions: int = 0
    changes: int = 0
    status: str = ""
    raw_url: str = ""
    patch: str = ""

    def as_context(self) -> str:
        return json.dumps(
            {
                "filename": self.filename,
                "additions": self.additions,
                "deletions": self.deletions,
                "changes": self.changes,
                "status": self.status,
                "raw_url": self.raw_url,
                "patch": self.patch,
            }
        )

    def as_dict(self):
        return {
            "filename": self.filename,
            "additions": self.additions,
            "deletions": self.deletions,
            "changes": self.changes,
            "status": self.status,
            "raw_url": self.raw_url,
            "patch": self.patch,
        }

    def to_json_string(self) -> str:
        return json.dumps(self.model_dump())

    def as_file_changes_ref(self) -> str:
        return json.dumps(
            {
                "filename": self.filename,
                "additions": self.additions,
                "deletions": self.deletions,
                "changes": self.changes,
                "status": self.status,
                "raw_url": self.raw_url,
            }
        )

    @staticmethod
    def from_json(json_responses: Any) -> "List[GitHubPullRequestFileChanges]":
        """Convert JSON String to GitHub Pull Request File Changes"""

        pull_requests = []

        for jsresponse in json_responses:
            pull_request_file_change = GitHubPullRequestFileChanges()

            pull_request_file_change.filename = jsresponse.get("filename") or ""
            pull_request_file_change.additions = jsresponse.get("additions") or 0
            pull_request_file_change.deletions = jsresponse.get("deletions") or 0
            pull_request_file_change.changes = jsresponse.get("changes") or 0
            pull_request_file_change.status = jsresponse.get("status") or ""
            pull_request_file_change.raw_url = jsresponse.get("raw_url") or ""
            pull_request_file_change.patch = jsresponse.get("patch") or ""

            pull_requests.append(pull_request_file_change)

        return pull_requests


class GitHubPullRequestSearchResponse(BaseModel):
    """Pull Request Search Response Model"""

    total_count: int = 0
    items: List[GitHubPullRequest] = []

    def as_dict(self):
        return {"total_count": self.total_count, "items": self.items}

    def as_context(self) -> str:
        return json.dumps([item.as_context() for item in self.items])

    @staticmethod
    def from_json(json_response: Any) -> "GitHubPullRequestSearchResponse":
        """Convert JSON String to Pull Request Search Response"""

        pull_request_search = GitHubPullRequestSearchResponse(
            total_count=json_response.get("total_count", 0),
            items=[
                GitHubPullRequest.from_json(item)
                for item in json_response.get("items", [])
            ],
        )

        return pull_request_search


class FilterableList(Enum):
    STATUS = (
        "status",
        "For defects we have different statuses like Open, In Progress,  SNFR or NFR referes to Suspected No Code fix required. Blocked status means that the defect is blocked on some other team like DevOps or Product team or Customer. Other statuses are REviewed, Verified, and Closed.  ",
    )
    UPDATED_DATE = (
        "updated_date",
        "Defect Update Date, in YYYY-MM-DD format i.e 2024-02-14",
    )
    FIX_VERSIONS = (
        "fix_versions",
        "List of Defect Fix Versions. This is an important field in Jira. This is a version of our GPP product or it could also be cusotmer branch where defect is directly checked in. This field can have multiple values. Since developer may fix defect on specific product version as well as on customer specific branch. We use PRE or FREEZE wrods in customer specific branch names. e.g. Morgan_Freeze. In this example Morgan is the name of the cusotmer and Freeze is the branch specific to Morgan customer",
    )
    COMPONENTS = (
        "components",
        "In Global Pay Plus also referred as GPP product, we have 3 main components also referred as rails. They are viz. 'High Value' or HV, 'Immidiate Payments' or IP, and 'Mass Pay' or MP. Apart from these we also have few common componants like Infra, DevOps, User Interface or UI etc.",
    )
    LABELS = (
        "labels",
        "List of Defect Labels a a free flow text. One of the important labels is 'Passed_Gatekeeping'. If the defect has this label then it means that product owner as well as development lead has looked at the defect and confirmed that the defect is indeed exists in the system and needs to be fixed.",
    )
    FOUND_IN = (
        "found_in",
        "Field contains two types of information. Viz. Customer implementation which is usually country or component like HV, IP, MP etc.and Product version. E.g MUFG_US_4.7 means defect is related to MUFG customer, US is implementation of MUFG customer and product version is 4.7.",
    )
    REPORTER = (
        "reporter",
        "Reporter is the user id or name of the person who has raised the defect.",
    )
    DEVELOPER = (
        "developers",
        "This may have multiple entries. This has user id or name of the person who has resolved the defect. I.e. the person who has changed the status of the defect as Resolved.",
    )
    SCRUM_TEAM = (
        "scrum_team",
        "This field has name of the development team that works on resolution of the defect.",
    )
    TEAMS = (
        "teams",
        "This field is associated with Assignee’s team. Teams are Services, Customers, Prod_Dev etc.",
    )
    CUSTOMER = ("customer", "This field has names of customers.")

    DEFECT_ORIGIN = (
        "defect_origin",
        "Defect Origin means if the defect is Internal (Development) or External Customer. ",
    )
    DEFECT_CLASSIFICATION = (
        "defect_classification",
        "Defect Classification has details like Latent, Regression etc.",
    )
    ROOT_CAUSE = (
        "root_cause",
        "Defect Root Cause",
    )
    SEVERITY = (
        "severity",
        "Defect Severity",
    )

    def __init__(self, value, hint):
        self._value_ = value
        self.hint = hint

    def __str__(self) -> str:
        return self.value

    def to_string(self) -> str:
        return self.value

    @staticmethod
    def from_str(value: str) -> "FilterableList":
        match value:
            case "status":
                return FilterableList.STATUS
            case "updated_date":
                return FilterableList.UPDATED_DATE
            case "fix_versions":
                return FilterableList.FIX_VERSIONS
            case "components":
                return FilterableList.COMPONENTS
            case "labels":
                return FilterableList.LABELS
            case "found_in":
                return FilterableList.FOUND_IN
            case "reporter":
                return FilterableList.REPORTER
            case "developers":
                return FilterableList.DEVELOPER
            case "scrum_team":
                return FilterableList.SCRUM_TEAM
            case "teams":
                return FilterableList.TEAMS
            case "customer":
                return FilterableList.CUSTOMER
            case "defect_origin":
                return FilterableList.DEFECT_ORIGIN
            case "defect_classification":
                return FilterableList.DEFECT_CLASSIFICATION
            case "root_cause":
                return FilterableList.ROOT_CAUSE
            case "severity":
                return FilterableList.SEVERITY
            case _:
                raise ValueError(f"Unknown FilterableList: {value}")


class JiraAIReference(JiraModel):
    score: float = 0.0

    def as_reference(self) -> Any:
        return json.loads(
            json.dumps(
                {
                    "defect_summary": self.summary,
                    "status": self.status.value,
                    "components": self.components,
                    "fix_versions": self.fix_versions,
                    "source": {
                        "defect_id": self.defect_id,
                        "url": f"https://jira.finastra.com/browse/{self.defect_id}",
                        "similarity_score": self.score,
                    },
                }
            )
        )

    @staticmethod
    def from_jira_model(jira_model: JiraModel, score: float) -> "JiraAIReference":
        self = JiraAIReference()

        self.summary = jira_model.summary
        self.status = jira_model.status
        self.components = jira_model.components
        self.fix_versions = jira_model.fix_versions
        self.defect_id = jira_model.defect_id
        self.score = round(1 - score, 4) * 100

        return self
