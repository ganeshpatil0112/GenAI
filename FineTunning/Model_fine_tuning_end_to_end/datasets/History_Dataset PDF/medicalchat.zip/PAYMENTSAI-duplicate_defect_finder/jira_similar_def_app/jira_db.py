"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-12-03
Description: Jira Similarity Search Database
"""

import logging
import sqlite3
from utils.app_config import AppConfig
from abstraction.database import AppDatabase
from langchain_core.documents import Document
from typing import List, Tuple, Optional, Dict
from local.models import SimilarSearchResult
from jira_similar_def_app.models import JiraModel
from langchain_text_splitters import RecursiveCharacterTextSplitter
from jira_similar_def_app.jira_app_constants import (
    DEFAULT_JIRA_RETRIEVER_LIMIT,
    JIRA_COLLECTION_NAME,
)


class JiraDatabase:
    """Jira Similarity Search Database"""

    def __init__(self, appconfig=AppConfig().load_config()):
        """Initialize Jira Database"""

        self.logger = logging.getLogger(self.__class__.__name__)

        self.appconfig = appconfig

        self.db_config = self.appconfig.get_database_config()

        self.db_config.set_chroma_collection_name(JIRA_COLLECTION_NAME)

        self.logger.log(
            logging.INFO,
            f"Initalizing Jira Database with Collection Name: {JIRA_COLLECTION_NAME}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Initalizing Jira Database with Database Config: {self.db_config}",
        )

        self.db = AppDatabase(self.appconfig)

    async def get_ticket_by_id(self, jira_id: str) -> Document | None:
        """Get Jira from Database
        ### Args:
        - jira_id: str : Jira ID to get the Jira Ticket
        ### Returns:
        - Document | None : Jira Ticket if found else None
        """

        self.logger.log(
            logging.INFO,
            f"Getting Jira Ticket from Database with Jira ID: {jira_id}",
        )

        jira_tickets = await self.db.aget_document_by_id(jira_id)

        self.logger.log(
            logging.DEBUG,
            f"Jira Ticket with ID: {jira_id} found in the database: {jira_tickets}",
        )

        if not jira_tickets:
            self.logger.log(
                logging.ERROR,
                f"Jira Ticket with ID: {jira_id} not found in the database",
            )
            return None

        self.logger.log(
            logging.INFO,
            f"Jira Ticket with ID: {jira_id} found in the database",
        )

        return jira_tickets[0]

    async def get_defect_by_field_value(
        self, jira_field_name: str, jira_field_value: str
    ) -> SimilarSearchResult:
        """Get Jira from Database
        ### Args:
        - jira_field_name: str : Jira Field Name to get the Jira Ticket
        - jira_field_value: str : Jira Field Value to get the Jira Ticket
        ### Returns:
        - List[Document] : Jira Ticket list if found else empty list
        """

        self.logger.log(
            logging.INFO,
            f"Getting Jira Ticket from Database with Jira Field Name: {jira_field_name} and Jira Field Value: {jira_field_value}",
        )

        jira_tickets = await self.db.aget_document_by_field(
            jira_field_name, jira_field_value
        )

        self.logger.log(
            logging.DEBUG,
            f"Jira Ticket with Field Name: {jira_field_name} and Field Value: {jira_field_value} found in the database: {jira_tickets}",
        )

        if not jira_tickets:
            self.logger.log(
                logging.ERROR,
                f"Jira Ticket with Field Name: {jira_field_name} and Field Value: {jira_field_value} not found in the database",
            )
            return SimilarSearchResult(
                ids=[], embeddings=[], metadatas=[], documents=[], scores=[0.0]
            )

        self.logger.log(
            logging.INFO,
            f"Jira Ticket with Field Name: {jira_field_name} and Field Value: {jira_field_value} found in the database",
        )

        return jira_tickets

    async def add_jira_data(self, jira_data: List[Document]) -> List[str]:
        """Add Jira Data to Database
        ### Args:
        - jira_data: List[Document] : Jira Data to be added to the Database
        """

        self.logger.log(
            logging.INFO,
            f"Adding Jira Data to Database with Jira Data Size: {len(jira_data)}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Adding Jira Data to Database with Jira Data: {jira_data}",
        )

        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=150,
            length_function=len,
        )

        content_ids = await self.db.aadd_documents(
            text_splitter.split_documents(jira_data)
        )

        self.logger.log(
            logging.INFO,
            "Jira Data added to Database",
        )

        self.logger.log(
            logging.DEBUG,
            f"Jira Data added to Database with Content IDs: {content_ids}",
        )

        return content_ids

    async def add_jira_data_bulk(self, bulk_data: List[JiraModel]) -> List[str]:
        """Add Jira Bulk Data to Database
        ### Args:
        - bulk_data: List[JiraModel] : Jira Bulk Data to be added to the Database
        ### Returns:
        - bool : True if Success else False
        """

        self.logger.log(
            logging.INFO,
            f"Adding Jira Bulk Data to Database with Jira Bulk Data Size: {len(bulk_data)}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Adding Jira Bulk Data to Database with Jira Bulk Data: {bulk_data}",
        )

        jira_data = [jira_model.as_document() for jira_model in bulk_data]

        return await self.add_jira_data(jira_data)

    async def update_jira_data_by_ids(
        self, ids: List[str], jira_data: List[Document]
    ) -> None:
        """Update Jira Data in Database
        ### Args:
        - jira_data: List[Document] : Jira Data to be updated in the Database
        """

        self.logger.log(
            logging.INFO,
            f"Updating Jira Data in Database with Jira Data Size: {len(jira_data)}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Updating Jira Data in Database with Jira Data: {jira_data}",
        )

        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=150,
            length_function=len,
        )

        await self.db.aupdate_documents(ids, text_splitter.split_documents(jira_data))

        self.logger.log(
            logging.INFO,
            "Jira Data updated in Database",
        )

    async def update_jira_data(self, jira_data: List[JiraModel]) -> None:
        """Update Jira Data in Database
        ### Args:
        - jira_data: List[JiraModel] : Jira Data to be updated in the Database
        """

        self.logger.log(
            logging.INFO,
            f"Updating Jira Data in Database with Jira Data Size: {len(jira_data)}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Updating Jira Data in Database with Jira Data: {jira_data}",
        )

        to_delete_ids = []

        jira_documents = [jira_model.as_document() for jira_model in jira_data]

        self.logger.log(
            logging.INFO,
            "Jira Data updated in Database",
        )

    async def delete_jira_data_by_ids(self, content_ids: List[str]) -> Optional[bool]:
        """Delete Jira Data by IDs from Database
        ### Args:
        - content_ids: List[str] : Jira Data IDs to be deleted from the Database
        """

        self.logger.log(
            logging.INFO,
            f"Deleting Jira Data by IDs from Database with Jira Data IDs Size: {len(content_ids)}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Deleting Jira Data by IDs from Database with Jira Data IDs: {content_ids}",
        )

        return await self.db.adelete_document_by_id(content_ids)

    async def delete_jira_data_by_field_value(
        self, field_name: str, field_value: str
    ) -> Optional[bool]:
        """Delete Jira Data by Field Value from Database
        ### Args:
        - field_name: str : Jira Field Name to be deleted from the Database
        - field_value: str : Jira Field Value to be deleted from the Database
        """

        self.logger.log(
            logging.INFO,
            f"Deleting Jira Data using Field Name: {field_name}, Field Value: {field_value}",
        )

        return await self.db.adelete_document_by_field(field_name, field_value)

    async def afind_similar_defect(
        self, query: str, limit: int, filters: Optional[Dict[str, str]]
    ) -> List[Tuple[Document, float]]:
        """Find Similar Defect in Jira Database
        ### Args:
        - query: str : Query to find similar defect in Jira Database
        ### Returns:
        - List[Tuple[Document, float]]: List of similar defects in Jira Database
        """

        self.logger.log(
            logging.INFO,
            f"Finding Similar Defect in Jira Database with Query: {query}",
        )

        return await self.db.asimilarity_search_documents(query, limit, filters)

    async def afetch_metadata_values(self, field_name: str) -> List[str]:
        """Fetch Metadata Values from Jira Database
        ### Args:
        - field_name: str : Field Name to fetch metadata values
        ### Returns:
        - List[str]: List of metadata values
        """

        return await self.db.db_client.aget_field_values(field_name)  # type: ignore

    def as_retriever(self):
        """Get Retriever for Jira Database"""

        return self.db.as_retriever(DEFAULT_JIRA_RETRIEVER_LIMIT)
