"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-12-05
Description: Jira Tool Helper functions
"""

import json
import logging
import aiohttp
from uuid import uuid4
from urllib.parse import urljoin
from haystack.dataclasses import Document
from local.models import SimilarSearchResult
from langchain_core.messages import ToolMessage
from jira_similar_def_app.jira_db import JiraDatabase
from haystack.core.pipeline import AsyncPipeline as spp
from typing import Any, Dict, List, Optional, AsyncGenerator
from jira_similar_def_app.models import JiraAIReference, JiraModel, JiraFields
from utils.vars import get_jira_username, get_jira_api_key
from haystack.document_stores.in_memory import InMemoryDocumentStore as retriever
from haystack.components.retrievers import InMemoryBM25Retriever as storage
from haystack.components.rankers import TransformersSimilarityRanker as retr
from jira_similar_def_app.jira_app_constants import (
    JIRA_ISSUE_API_URL_PREFIX,
    JIRA_SEARCH_API_URL_PREFIX,
    GITHUB_REPO_OWNER,
    GITHUB_REPO_NAME,
)
from jira_similar_def_app.github_helper import (
    search_for_pull_request_by_defect_id,
    fetch_pull_request_code_changes,
)
from abstraction.chat_completion import ToolCallHandlerArgs


async def _get_issue_from_jira(defect_id: str) -> Any | None:
    """Get Jira Issue from Jira API
    ### Args:
        - `defect_id`: str Jira Issue ID (e.g. 'GPD-165670')
    ### Returns:
        - JSON string response from Jira API
    """

    logging.log(
        logging.INFO,
        f"Getting Jira Issue from Jira API for defect_id: {defect_id}",
    )

    defect_url = urljoin(JIRA_ISSUE_API_URL_PREFIX, defect_id)

    # basic_auth = aiohttp.BasicAuth(get_jira_username(), get_jira_api_key())
    header = {
        "Authorization": f"Bearer {get_jira_api_key()}"
    }
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(defect_url, headers=header) as response:

                json_issue = await response.json()

                logging.log(
                    logging.INFO,
                    f"""Fetched Jira Issue from Jira API for defect_id: \
                    {defect_id}, str response length: {len(json_issue)}""",
                )

                logging.log(
                    logging.DEBUG,
                    f"Jira Issue from Jira API for defect_id: {defect_id}: {json_issue}",
                )

                return json_issue
    except Exception as e:
        logging.log(
            logging.ERROR,
            f"Error getting Jira Issue from Jira API for defect_id: {defect_id}: {e}",
        )

        return None


async def fetch_jira_bulk_data(
    jira_jql: str, fetch_all: bool = True, max_result: int = 100
) -> AsyncGenerator[List[JiraModel], None]:
    """Fetch Jira Bulk Data from Jira API
    ### Args:
        - `jira_jql`: str Jira JQL Query
        - `fetch_all`: bool Fetch All Data or only First `JIRA_JQL_SEARCH_MAX_RESULT`
    ### Returns:
    - List[JiraModel] : List of `JiraModel` objects
    """

    logging.log(
        logging.INFO,
        f"Fetching Jira Bulk Data from Jira API with Jira JQL: {jira_jql}",
    )

    # basic_auth = aiohttp.BasicAuth(get_jira_username(), get_jira_api_key())
    header = {
        "Authorization": f"Bearer {get_jira_api_key()}"
    }
    query_params = {"jql": jira_jql, "maxResults": max_result}

    start_at = 0

    try:
        async with aiohttp.ClientSession() as session:
            while True:

                query_params["startAt"] = start_at

                async with session.get(
                    JIRA_SEARCH_API_URL_PREFIX,
                    headers=header,
                    params=query_params,
                ) as response:

                    if response.status == 200:
                        try:
                            content = await response.read()
                            json_bulk_data = json.loads(content.decode("utf-8"))
                        except Exception as exc:
                            logging.log(
                                logging.ERROR, f"Error reading JSON payload: {exc}"
                            )
                            break

                        logging.log(
                            logging.INFO,
                            f"""Fetched Jira Bulk Data from Jira API with Jira JQL: \
                            {jira_jql}, str response length: {len(json_bulk_data)}""",
                        )

                        logging.log(
                            logging.DEBUG,
                            f"Jira Bulk Data from Jira API with Jira JQL: {jira_jql}: {json_bulk_data}",
                        )

                        if "issues" in json_bulk_data:
                            yield JiraModel.from_jira_json_bulk(json_bulk_data)

                        else:
                            logging.log(
                                logging.ERROR,
                                f"Issues not found in response: {json_bulk_data}",
                            )

                        issues = json_bulk_data.get("issues", [])
                        if issues:
                            if start_at + len(issues) < json_bulk_data["total"]:
                                start_at += len(issues)
                            else:
                                logging.log(
                                    logging.INFO,
                                    "Fetched all Jira Bulk Data from Jira API",
                                )
                                break
                        else:
                            logging.log(
                                logging.INFO,
                                "No issues found in the response",
                            )
                            break

                        if not fetch_all:
                            break
                    else:
                        logging.log(
                            logging.ERROR,
                            f"""Error fetching Jira Bulk Data from Jira API with Jira JQL: {jira_jql} \
                            Query Params: {query_params} \
                            Response Status: {response.status} \
                            Response Content: {response.content}
                            Response: {response}
                            """,
                        )
    except Exception as e:
        logging.log(
            logging.ERROR,
            f"Error fetching Jira Bulk Data from Jira API with Jira JQL: {jira_jql}: {e}",
        )

    return


async def get_issue_from_jira(defect_id: str) -> JiraModel | None:
    """Get Jira Issue from Jira API
    ### Args:
        - `defect_id`: str Jira Issue ID (e.g. 'GPD-165670')
    ### Returns:
        - `JiraModel` object
    """

    logging.log(
        logging.INFO,
        f"Getting Jira Issue from Jira API for defect_id: {defect_id}",
    )

    json_issue_response = await _get_issue_from_jira(defect_id)

    if not json_issue_response:
        logging.log(
            logging.ERROR,
            f"Error getting Jira Issue from Jira API for defect_id: {defect_id}",
        )

        return None

    jira_model = JiraModel().from_jira_json(json_issue_response)

    logging.log(
        logging.DEBUG,
        f"Jira Issue from Jira API for defect_id: {defect_id}: {jira_model}",
    )

    return jira_model


async def get_jira_field_value(defect_id: str, field_name: str) -> str:
    """Fetch Specific Field from Defect

    ### Args:
        - `defect_id`: str Defect ID
        - `field`: str Field to Fetch from Defect
    ### Returns:
        - `str` Field Value
    """

    fetched_defect = await get_issue_from_jira(defect_id)

    if fetched_defect:

        try:
            match JiraFields.from_str(field_name):
                case JiraFields.PROJECT_KEY:
                    return fetched_defect.project_key or "Project Key not Found"
                case JiraFields.SUMMARY:
                    return fetched_defect.summary or "Summary not Found"
                case JiraFields.STATUS:
                    return fetched_defect.status.to_string() or "Status not Found"
                case JiraFields.PRIORITY:
                    return fetched_defect.priority or "Priority not Found"
                case JiraFields.RESOLUTION:
                    return fetched_defect.resolution or "Resolution not Found"
                case JiraFields.CREATED_DATE:
                    return str(fetched_defect.created_date) or "Created Date not Found"
                case JiraFields.UPDATED_DATE:
                    return str(fetched_defect.updated_date) or "Updated Date not Found"
                case JiraFields.RESOLVED_DATE:
                    return (
                        str(fetched_defect.resolved_date) or "Resolved Date not Found"
                    )
                case JiraFields.AFFECTED_VERSIONS:
                    return (
                        json.dumps(fetched_defect.affected_versions)
                        or "Affected Versions not Found"
                    )
                case JiraFields.FIX_VERSIONS:
                    return (
                        json.dumps(fetched_defect.fix_versions)
                        or "Fix Versions not Found"
                    )
                case JiraFields.COMPONENTS:
                    return (
                        json.dumps(fetched_defect.components) or "Components not Found"
                    )
                case JiraFields.DUE_DATE:
                    return str(fetched_defect.due_date) or "Due Date not Found"
                case JiraFields.LINKED_ISSUES:
                    return (
                        json.dumps(fetched_defect.linked_issues)
                        or "Linked Issues not Found"
                    )
                case JiraFields.ENVIRONMENT:
                    return fetched_defect.environment or "Environment not Found"
                case JiraFields.DESCRIPTION:
                    return fetched_defect.description or "Description not Found"
                case JiraFields.LABELS:
                    return json.dumps(fetched_defect.labels) or "Labels not Found"
                case JiraFields.SPRINT:
                    return fetched_defect.sprint or "Sprint not Found"
                case JiraFields.PROJECT_TYPE:
                    return fetched_defect.project_type or "Project Type not Found"
                case JiraFields.SUSPECTED_NFR_DATE:
                    return (
                        str(fetched_defect.suspected_nfr_date)
                        or "Suspected NFR Date not Found"
                    )
                case JiraFields.DEFECT_ORIGIN:
                    return (
                        fetched_defect.defect_origin
                        if fetched_defect.defect_origin
                        else "Defect Origin not Found"
                    )
                case JiraFields.CONFIRMED_DATE:
                    return (
                        str(fetched_defect.confirmed_date) or "Confirmed Date not Found"
                    )
                case JiraFields.REOPEN_DATE:
                    return str(fetched_defect.reopen_date) or "Reopen Date not Found"
                case JiraFields.DEFECT_CLASSIFICATION:
                    return (
                        fetched_defect.defect_classification.to_string()
                        if fetched_defect.defect_classification
                        else "Defect Classification not Found"
                    )
                case JiraFields.SCENARIO:
                    return fetched_defect.scenario or "Scenario not Found"
                case JiraFields.ROOT_CAUSE:
                    return json.dumps(
                        {
                            "root_cause": fetched_defect.root_cause,
                            "root_cause_analysis": fetched_defect.root_cause_analysis,
                            "root_cause_analysis_details": fetched_defect.root_cause_analysis_details,
                        }
                    )
                case JiraFields.RESOLUTION_DETAILS:
                    return (
                        fetched_defect.resolution_details
                        or "Resolution Details not Found"
                    )
                case JiraFields.ACCEPTANCE:
                    return fetched_defect.acceptance or "Acceptance not Found"
                case JiraFields.SEVERITY:
                    return (
                        fetched_defect.severity.to_string()
                        if fetched_defect.severity
                        else "Severity not Found"
                    )
                case JiraFields.CLOSED_DATE:
                    return str(fetched_defect.closed_date) or "Closed Date not Found"
                case JiraFields.REPLICATION_STEPS:
                    return (
                        fetched_defect.replication_steps
                        or "Replication Steps not Found"
                    )
                case JiraFields.COMMENTS:
                    return (
                        json.dumps(
                            [
                                comment.to_json_string()
                                for comment in fetched_defect.comments
                            ]
                        )
                        or "Comments not Found"
                    )
                case JiraFields.FOUND_IN:
                    return fetched_defect.found_in or "Found In not Found"
                case JiraFields.SOURCE_DETECTED:
                    return (
                        fetched_defect.source_detected.to_string()
                        if fetched_defect.source_detected
                        else "Source Detected not Found"
                    )
                case JiraFields.REPORTER:
                    return fetched_defect.reporter or "Reporter not Found"
                case JiraFields.DEVELOPER:
                    return fetched_defect.developers or "Developer not Found"
                case JiraFields.SCRUM_TEAM:
                    return fetched_defect.scrum_team or "Scrum Team not Found"
                case JiraFields.TEAMS:
                    return fetched_defect.teams or "Teams not Found"
                case JiraFields.CUSTOMER:
                    return fetched_defect.customer or "Customer not Found"

        except ValueError:
            logging.log(
                logging.ERROR,
                f"Error getting Jira Field Value for defect_id: {defect_id}, field_name: {field_name}",
            )
            return "Invalid Field Name"

    return "Unable to get fields for the defect id"


async def _find_similar_defects(
    query: str, limit: int = 5, filters: Optional[Dict[str, str]] = None
) -> List[JiraAIReference]:
    """Find Similar Defect from Jira API
    ### Args:
        - `query`: str Jira Issue ID (e.g. 'GPD-165670')
    ### Returns:
        - Json String response from Jira DB
    """

    logging.log(
        logging.INFO,
        f"Finding Similar Defect from Jira API for query: {query}",
    )

    jira_db = JiraDatabase()

    similar_defects = await jira_db.afind_similar_defect(query, limit, filters)

    jira_models: List[JiraAIReference] = []

    for similar_defect in similar_defects:
        jira_model = JiraModel().from_jira_db_response(
            SimilarSearchResult(
                ids=[],
                embeddings=[],
                documents=[],
                metadatas=[similar_defect[0].metadata],
                scores=[similar_defect[1]],
            )
        )

        if jira_model:
            jira_models.extend(
                [
                    JiraAIReference.from_jira_model(res, score=similar_defect[1])
                    for res in jira_model
                ]
            )

    logging.log(
        logging.DEBUG,
        f"Similar Defects from Jira API for query: {query}: {jira_models}",
    )

    return jira_models


async def find_similar_defects(
    query: str, limit: int = 5, filters: Optional[Dict[str, str]] = None
) -> List[Any]:
    """Find Similar Defect from Jira API
    ### Args:
        - `query`: str Jira Issue ID (e.g. 'GPD-165670')
    ### Returns:
        - Json String response from Jira DB
    """

    jira_models = await _find_similar_defects(query, limit, filters)

    return jira_models


async def find_similar_defects_as_ref(
    query: str, limit: int = 5, filters: Optional[Dict[str, str]] = None
) -> List[Any] | None:
    """Find Similar Defect from Jira API
    ### Args:
        - `query`: str Jira Issue ID (e.g. 'GPD-165670')
    ### Returns:
        - Json String response from Jira DB
    """

    jira_models = await _find_similar_defects(query, limit, filters)

    return [
        (jira_model.as_reference())
        for jira_model in list(
            {model.defect_id: model for model in jira_models}.values()
        )
    ]


async def fetch_metadata_values(field_name: str) -> List[str]:
    """Fetch Metadata Values for a Field
    ### Args:
        - `field_name`: str Field Name
    ### Returns:
        - List[str] Metadata Values
    """

    jira_db = JiraDatabase()

    metadata_values = await jira_db.afetch_metadata_values(field_name)

    return metadata_values


async def jira_function_call_handler(
    tool_call_args: ToolCallHandlerArgs,
) -> ToolMessage:

    logging.log(
        logging.INFO,
        f"Handling Jira Function Call: {tool_call_args}",
    )

    match tool_call_args["tool_name"]:
        case "fetch_defect_from_jira":

            json_args = json.loads(tool_call_args["tool_args"])

            logging.log(
                logging.INFO,
                f"Tool Call defect_id: {json_args['defect_id']}",
            )

            defect_id = json_args["defect_id"]

            logging.log(
                logging.INFO,
                f"Tool Call defect_id: {defect_id}",
            )

            fetched_jira_content = await get_issue_from_jira(defect_id)

            logging.log(
                logging.DEBUG,
                f"Fetched Jira Content: {fetched_jira_content}",
            )

            if fetched_jira_content:
                return ToolMessage(
                    content=fetched_jira_content.as_reference(),
                    tool_call_id=tool_call_args["tool_id"],
                    status="success",
                )
            return ToolMessage(
                content="", tool_call_id=tool_call_args["tool_id"], status="error"
            )
        case "fetch_specific_field_from_defect":

            json_args = json.loads(tool_call_args["tool_args"])

            logging.log(
                logging.INFO,
                f"Tool Call defect_id: {json_args['defect_id']}, Field: {json_args['field_name']}",
            )

            defect_id = json_args["defect_id"]
            field_name = json_args["field_name"]

            logging.log(
                logging.INFO,
                f"Tool Call defect_id: {defect_id}, Field: {field_name}",
            )

            fetched_field_content = await get_jira_field_value(defect_id, field_name)

            logging.log(
                logging.DEBUG,
                f"Fetched Field Content: {fetched_field_content}",
            )

            if fetched_field_content:
                return ToolMessage(
                    content=fetched_field_content,
                    tool_call_id=tool_call_args["tool_id"],
                    status="success",
                )
            return ToolMessage(
                content="", tool_call_id=tool_call_args["tool_id"], status="error"
            )

        case "fetch_similar_defects":

            json_args = json.loads(tool_call_args["tool_args"])

            logging.log(
                logging.INFO,
                f"Tool Call query: {json_args['query']}",
            )

            query = json_args["query"]

            fetched_field_content = await find_similar_defects_as_ref(query)

            if fetched_field_content:
                return ToolMessage(
                    content=json.dumps(fetched_field_content),
                    tool_call_id=tool_call_args["tool_id"],
                    status="success",
                )
            return ToolMessage(
                content="", tool_call_id=tool_call_args["tool_id"], status="error"
            )
        case "find_pull_request_by_defect_id":

            json_args = json.loads(tool_call_args["tool_args"])

            logging.log(
                logging.INFO,
                f"Tool Call defect_id: {json_args['defect_id']}",
            )

            defect_id = json_args["defect_id"]

            logging.log(
                logging.INFO,
                f"Tool Call defect_id: {defect_id}",
            )

            pull_request_detail = await search_for_pull_request_by_defect_id(
                GITHUB_REPO_OWNER, GITHUB_REPO_NAME, defect_id
            )

            if pull_request_detail:
                return ToolMessage(
                    content=json.dumps(pull_request_detail.as_context()),
                    tool_call_id=tool_call_args["tool_id"],
                    status="success",
                )

            return ToolMessage(
                content="", tool_call_id=tool_call_args["tool_id"], status="error"
            )

        case "fetch_pull_request_file_changes":

            json_args = json.loads(tool_call_args["tool_args"])

            logging.log(
                logging.INFO,
                f"Tool Call pull_request_id: {json_args['pull_request_id']}",
            )

            pull_request_id = json_args["pull_request_id"]

            logging.log(
                logging.INFO,
                f"Tool Call pull_request_id: {pull_request_id}",
            )

            pull_request_file_changes = await fetch_pull_request_code_changes(
                GITHUB_REPO_OWNER, GITHUB_REPO_NAME, pull_request_id
            )

            if pull_request_file_changes:
                return ToolMessage(
                    content=json.dumps(
                        [pr.as_file_changes_ref() for pr in pull_request_file_changes]
                    ),
                    tool_call_id=tool_call_args["tool_id"],
                    status="success",
                )

            return ToolMessage(
                content="", tool_call_id=tool_call_args["tool_id"], status="error"
            )

        case "fetch_pull_request_code_changes":

            json_args = json.loads(tool_call_args["tool_args"])

            logging.log(
                logging.INFO,
                f"Tool Call pull_request_id: {json_args['pull_request_id']}",
            )

            pull_request_id = json_args["pull_request_id"]

            logging.log(
                logging.INFO,
                f"Tool Call pull_request_id: {pull_request_id}",
            )

            pull_request_code_changes = await fetch_pull_request_code_changes(
                GITHUB_REPO_OWNER, GITHUB_REPO_NAME, pull_request_id
            )

            if pull_request_code_changes:
                return ToolMessage(
                    content=[pr.as_context() for pr in pull_request_code_changes],
                    tool_call_id=tool_call_args["tool_id"],
                    status="success",
                )

            return ToolMessage(
                content="", tool_call_id=tool_call_args["tool_id"], status="error"
            )
        case "fetch_pull_request_details":

            json_args = json.loads(tool_call_args["tool_args"])

            logging.log(
                logging.INFO,
                f"Tool Call pull_request_id: {json_args['pull_request_id']}",
            )

            pull_request_id = json_args["pull_request_id"]

            logging.log(
                logging.INFO,
                f"Tool Call pull_request_id: {pull_request_id}",
            )

            pull_request_details = await search_for_pull_request_by_defect_id(
                GITHUB_REPO_OWNER, GITHUB_REPO_NAME, pull_request_id
            )

            if pull_request_details:
                return ToolMessage(
                    content=pull_request_details.as_context(),
                    tool_call_id=tool_call_args["tool_id"],
                    status="success",
                )

            return ToolMessage(
                content="", tool_call_id=tool_call_args["tool_id"], status="error"
            )

    return ToolMessage(content="Error: Function Not Found")


async def setup_retr(defects: list):
    retr = retriever()
    documents = [
        Document(
            id=str(index),
            content=defect["defect_summary"],
            meta={
                "status": defect["status"],
                "components": defect["components"],
                "fix_versions": defect["fix_versions"],
                "source": defect["source"],
            },
        )
        for (index, defect) in enumerate(defects)
    ]
    retr.write_documents(documents)
    logging.info("Documents indexed successfully.")
    return retr


async def cpl(document_store):
    # Create new instances for each pipeline
    rcc = storage(document_store=document_store)
    bm25_c = retr(model="cross-encoder/ms-marco-MiniLM-L12-v2")
    bm25_c.warm_up()

    aspp = spp()
    aspp.add_component(instance=rcc, name="retriever")
    aspp.add_component(instance=bm25_c, name="ranker")
    aspp.connect("retriever.documents", "ranker.documents")

    return aspp


async def clean_defects(query: str, filters: dict, defects: list) -> list[Document]:
    retr = await setup_retr(defects)
    ppl = await cpl(retr)
    results = await ppl.run_async(
        {
            "retriever": {"query": query, "top_k": 5},
            "ranker": {"query": query, "top_k": 5},
        }
    )

    rdd = [doc for doc in results["ranker"]["documents"]]
    return rdd
