"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-12-03
Description: Jira Tools Implementation
"""

from jira_similar_def_app.jira_app_constants import GITHUB_REPO_NAME, GITHUB_REPO_OWNER
from jira_similar_def_app.jira_tool_helper import (
    get_issue_from_jira,
    find_similar_defects_as_ref,
    get_jira_field_value,
    jira_function_call_handler,
    fetch_metadata_values as jira_fetch_metadata_values,
    clean_defects,
)
from jira_similar_def_app.github_helper import (
    search_for_pull_request_by_defect_id,
    fetch_pull_request_code_changes as github_pull_request_code_changes,
    fetch_pull_request_details as github_pull_request_details,
)
from jira_similar_def_app.models import FilterableList, JiraFields
from langchain.tools import tool
from typing import Any
import logging
import json


@tool
async def fetch_defect_from_jira(defect_id: str) -> str:
    """Fetch Defect from Jira

    ### Args:
        - defect_id: Jira Defect ID e.g GPD-151967
    ### Returns:
        - jira_model: Jira Data Json Object and if not found then empty string
    """

    logging.log(
        logging.INFO,
        f"Fetching Defect from Jira with ID: {defect_id}",
    )

    fetched_defect = await get_issue_from_jira(defect_id)

    if fetched_defect:
        return fetched_defect.as_reference()

    return ""


@tool
async def fetch_specific_field_from_defect(
    defect_id: str, field_name: JiraFields
) -> str:
    """Fetch Specific Field from Defect

    ### Args:
        - `defect_id`: str Defect ID
        - `field`: str Field to Fetch from Defect
    ### Returns:
        - `str` Field Value
    """

    logging.log(
        logging.INFO,
        f"Tool Call defect_id: {defect_id}, Field: {field_name}",
    )

    return await get_jira_field_value(defect_id, str(field_name))


@tool
async def fetch_similar_defects(query: str, filters: dict[str, Any]) -> str:
    """Fetch Similar Defects
    ### Args:
        - `query`: str Query to Search for Similar Defects
        - `filters`: dict Filters to Apply on Search
    ### Returns:
        - `JiraModel`: List of Jira Json Objects
    """

    logging.log(
        logging.INFO,
        f"Fetching Similar Defects for Query: {query}",
    )

    similar_defects = await find_similar_defects_as_ref(
        query, filters=filters, limit=100
    )

    if not similar_defects:
        return "No Similar Defect Found"

    reranked_defects = await clean_defects(query, filters={}, defects=similar_defects)

    final_results = [similar_defects[int(defect.id)] for defect in reranked_defects]

    return json.dumps(final_results)


@tool
async def find_pull_request_by_defect_id(defect_id: str) -> str:
    """Find Pull Request by Defect ID

    ### Args:
        - `defect_id`: str Defect ID
    ### Returns:
        - `str` Pull Request URL
    """

    logging.log(
        logging.INFO,
        f"Finding Pull Request for Defect ID: {defect_id}",
    )

    res = await search_for_pull_request_by_defect_id(
        GITHUB_REPO_OWNER, GITHUB_REPO_NAME, defect_id
    )

    if not res:
        return "No Pull Request Found or Invalid Defect ID"

    return json.dumps(res.as_context())


@tool
async def fetch_pull_request_file_changes(pull_request_id: str) -> str:
    """Fetch Pull Request File Changes

    ### Args:
        - `pull_request_id`: str Pull Request ID
    ### Returns:
        - `str` Pull Request File Changes
    """

    logging.log(
        logging.INFO,
        f"Fetching Pull Request File Changes for PR ID: {pull_request_id}",
    )

    res = await github_pull_request_code_changes(
        GITHUB_REPO_OWNER, GITHUB_REPO_NAME, pull_request_id
    )

    if not res:
        return "No Pull Request File Changes Found"

    return json.dumps([file.as_file_changes_ref() for file in res])


@tool
async def fetch_pull_request_code_changes(pull_request_id: str) -> str:
    """Fetch Pull Request Code Changes

    ### Args:
        - `pull_request_id`: str Pull Request ID
    ### Returns:
        - `str` Pull Request Code Changes
    """

    logging.log(
        logging.INFO,
        f"Fetching Pull Request Code Changes for PR ID: {pull_request_id}",
    )

    res = await github_pull_request_code_changes(
        GITHUB_REPO_OWNER, GITHUB_REPO_NAME, pull_request_id
    )

    if not res:
        return "No Pull Request Code Changes Found"

    return json.dumps([file.as_context() for file in res])


@tool
async def fetch_pull_request_details(pull_request_id: str) -> str:
    """Fetch Pull Request Details

    ### Args:
        - `pull_request_id`: str Pull Request ID
    ### Returns:
        - `str` Pull Request Details
    """

    logging.log(
        logging.INFO,
        f"Fetching Pull Request Details for PR ID: {pull_request_id}",
    )

    res = await github_pull_request_details(
        GITHUB_REPO_OWNER, GITHUB_REPO_NAME, pull_request_id
    )

    if not res:
        return "No Pull Request Details Found"

    return res.as_context()


@tool
async def fetch_jira_field_values(field_name: FilterableList) -> list[str]:
    """Fetch Possible Jira Fields Values
    ### Args
        - `field_name`: FilterableList Jira Field Name
    ### Returns
        - `List[str]`:  Field Values
    """

    logging.log(
        logging.INFO,
        f"Fetching Metadata Values for Field: {field_name}",
    )

    return await jira_fetch_metadata_values(field_name.to_string())
