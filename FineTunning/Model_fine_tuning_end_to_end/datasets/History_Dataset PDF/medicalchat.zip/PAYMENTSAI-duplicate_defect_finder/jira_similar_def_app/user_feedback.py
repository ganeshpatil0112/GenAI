"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-01-16
Description: Jira User Feedback - Postgres Connection

# Rewrite with PogresSQL Connection with Data pool
"""

from jira_similar_def_app.models import ChatHistory, UserFeedBack
from utils.vars import get_user_feedback_pg_url
from typing import Optional, List
from psycopg import AsyncConnection
import psycopg
import json


DB_INIT = None
DB_CONN = None


async def postgres_connect() -> AsyncConnection:

    global DB_INIT
    global DB_CONN

    if DB_CONN is None:
        DB_CONN = await psycopg.AsyncConnection.connect(
            conninfo=get_user_feedback_pg_url()
        )

    if DB_INIT is None:
        await initialize_db(DB_CONN)
        DB_INIT = True

    return DB_CONN


async def initialize_db(connection: AsyncConnection) -> None:

    cursor = connection.cursor()

    query = """
    CREATE TABLE IF NOT EXISTS user_feedback (
        id SERIAL PRIMARY KEY,
        user_email VARCHAR(255) NOT NULL,
        response TEXT NOT NULL,
        user_feedback TEXT NOT NULL,
        date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
        user_impression BOOLEAN NOT NULL,
        chat_history JSON NOT NULL
    );"""

    await cursor.execute(query.strip())
    await connection.commit()


async def insert_user_feedback(feedback: UserFeedBack) -> bool:
    conn = await postgres_connect()
    cursor = conn.cursor()

    query = """
    INSERT INTO user_feedback (user_email, response, user_feedback, user_impression, chat_history) 
    VALUES (%s, %s, %s, %s, %s);"""

    try:
        await cursor.execute(
            query.strip(),
            (
                feedback.email,
                feedback.response,
                feedback.feedback,
                feedback.impression,
                json.dumps([chat.as_dict() for chat in feedback.chat_history]),
            ),
        )
    except psycopg.Error as e:
        print(e)
        return False
    finally:
        await conn.commit()

    return True


async def update_user_feedback(feedback: UserFeedBack) -> bool:
    conn = await postgres_connect()
    cursor = conn.cursor()

    query = """
    UPDATE user_feedback
    SET user_feedback = %s, response=%s, user_impression = %s, chat_history = %s
    WHERE user_email = %s;"""

    try:
        await cursor.execute(
            query.strip(),
            (
                feedback.feedback,
                feedback.response,
                feedback.impression,
                json.dumps([chat.as_dict() for chat in feedback.chat_history]),
                feedback.email,
            ),
        )
    except psycopg.Error as e:
        print(e)
        return False
    finally:
        await conn.commit()

    return True


async def get_all_feedback() -> Optional[List[UserFeedBack]]:
    conn = await postgres_connect()
    cursor = conn.cursor()

    query = """
    SELECT id, user_email, response, user_feedback, user_impression, chat_history
    FROM user_feedback;"""

    await cursor.execute(query.strip())
    result = await cursor.fetchall()

    if result is None:
        return None

    feedback = []

    for row in result:
        feedback.append(
            UserFeedBack(
                id=row[0],
                email=row[1],
                response=row[2],
                feedback=row[3],
                impression=row[4],
                chat_history=ChatHistory.from_json(row[5]),
            )
        )

    return feedback


async def get_feedback_by_id(id: int) -> Optional[UserFeedBack]:
    conn = await postgres_connect()
    cursor = conn.cursor()

    query = """
    SELECT id, user_email, response, user_feedback, user_impression, chat_history
    FROM user_feedback
    WHERE id = %s;"""

    await cursor.execute(query.strip(), (id,))
    result = await cursor.fetchone()

    if result is None:
        return None

    return UserFeedBack(
        id=result[0],
        email=result[1],
        response=result[2],
        feedback=result[3],
        impression=result[4],
        chat_history=ChatHistory.from_json(
            json.loads(str(result[5]).replace("'", '"'))
        ),
    )


async def get_feedback_by_field(
    field_name: str, field_value: str | int
) -> Optional[List[UserFeedBack]]:

    conn = await postgres_connect()
    cursor = conn.cursor()

    query = """
    SELECT user_email, response, user_feedback, user_impression, chat_history
    FROM user_feedback
    WHERE %s = %s;"""

    await cursor.execute(
        query.strip(),
        (
            field_name,
            field_value,
        ),
    )
    result = await cursor.fetchall()

    if result is None:
        return None

    feedback = []

    for row in result:
        feedback.append(
            UserFeedBack(
                id=row[0],
                email=row[1],
                response=row[2],
                feedback=row[3],
                impression=row[4],
                chat_history=ChatHistory.from_json(
                    json.loads(str(result[5]).replace("'", '"'))
                ),
            )
        )

    return feedback
