"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-01-15
Description: Jira API Helper
"""

from jira_similar_def_app.models import ChatHistory
from typing import Optional, Dict, List, Any
from pydantic import BaseModel


class SimilarDefectRequest(BaseModel):
    query: str = ""
    limit: int = 10
    filters: Optional[Dict] = None


class JiraAPIBulkIssues(BaseModel):
    expand: str = ""
    startAt: int = 0
    maxResults: int = 0
    total: int = 0
    issues: List = []


class UserFeedBackModel(BaseModel):
    email: str = ""
    response: str = ""
    feedback: str = ""
    impression: bool = False
    chat_history: List[ChatHistory]
