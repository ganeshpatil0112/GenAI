"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-01-30
Description: GitHub Helper Functions
"""

from jira_similar_def_app.models import (
    GitHubPullRequest,
    GitHubPullRequestFileChanges,
    GitHubPullRequestSearchResponse,
)
from jira_similar_def_app.jira_app_constants import GITHUB_USER_AGENT
from utils.vars import get_github_api_key
from typing import Optional, List
import aiohttp
import logging


def get_github_header():
    return {
        "User-Agent": GITHUB_USER_AGENT,
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "Authorization": f"Bearer {get_github_api_key()}",
    }


async def search_for_pull_request_by_defect_id(
    owner: str, repo: str, defect_id: str
) -> Optional[GitHubPullRequestSearchResponse]:
    """Search for Pull Request by Defect ID

    ### Args:
        - `defect_id`: str Defect ID
    ### Returns:
        - `str` Pull Request URL
    """

    logging.log(
        logging.INFO,
        f"Searching for Pull Request for Defect ID: {defect_id}",
    )

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                "https://api.github.com/search/issues?q=repo:{}/{}+type:pr+in:title+{}".format(
                    owner, repo, defect_id
                ),
                headers=get_github_header(),
            ) as response:

                if response.status == 200:
                    pull_request_json = await response.json()

                    logging.log(
                        logging.DEBUG,
                        f"Searched Pull Request for Defect ID: {defect_id}",
                    )

                    logging.log(
                        logging.DEBUG,
                        f"Pull Request JSON: {pull_request_json}",
                    )

                    return GitHubPullRequestSearchResponse.from_json(pull_request_json)

                if response.status == 404:
                    logging.log(
                        logging.DEBUG,
                        f"No Pull Request Found for Defect ID: {defect_id}",
                    )
                if response.status == 403:
                    logging.log(
                        logging.ERROR,
                        f"Rate Limit Exceeded for Defect ID: {defect_id}",
                    )

    except Exception as e:
        logging.log(
            logging.ERROR,
            f"Error Fetching Pull Request for Defect ID: {defect_id}, Error: {e}",
        )

    return None


async def fetch_pull_request_code_changes(
    owner: str, repo: str, pull_request_id: str
) -> Optional[List[GitHubPullRequestFileChanges]]:
    """Fetch Pull Request File Changes

    ### Args:
        - `pull_request_id`: str Pull Request ID
    ### Returns:
        - `str` Pull Request File Changes
    """

    logging.log(
        logging.INFO,
        f"Fetching Pull Request File Changes for PR ID: {pull_request_id}",
    )

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"https://api.github.com/repos/{owner}/{repo}/pulls/{pull_request_id}/files",
                headers=get_github_header(),
            ) as response:

                if response.status == 200:
                    pull_request_json = await response.json()

                    logging.log(
                        logging.DEBUG,
                        f"Fetched Pull Request File Changes for PR ID: {pull_request_id}",
                    )

                    return GitHubPullRequestFileChanges.from_json(pull_request_json)

                if response.status == 404:
                    logging.log(
                        logging.DEBUG,
                        f"No Pull Request Found for Defect ID: {pull_request_id}",
                    )
                if response.status == 403:
                    logging.log(
                        logging.ERROR,
                        f"Rate Limit Exceeded for Defect ID: {pull_request_id}",
                    )
    except Exception as e:
        logging.log(
            logging.ERROR,
            f"Error Fetching Pull Request File Changes for PR ID: {pull_request_id}, Error: {e}",
        )

    return None


async def fetch_pull_request_details(
    owner: str, repo: str, pull_request: str
) -> Optional[GitHubPullRequest]:
    """Fetch GitHub Pull Request Details

    ### Args:
        - `owner`: str Owner
        - `repo`: str Repository
        - `pull_request`: str Pull Request ID
    ### Returns:
        - `GitHubPullRequest` GitHub Pull Request Details
    """

    logging.log(
        logging.INFO,
        f"Fetching GitHub Pull Request Details for PR ID: {pull_request}",
    )

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"https://api.github.com/repos/{owner}/{repo}/pulls/{pull_request}",
                headers=get_github_header(),
            ) as response:

                if response.status == 200:
                    pull_request_json = await response.json()

                    logging.log(
                        logging.DEBUG,
                        f"Fetched GitHub Pull Request Details for PR ID: {pull_request}",
                    )

                    return GitHubPullRequest.from_json(pull_request_json)

                if response.status == 404:
                    logging.log(
                        logging.DEBUG,
                        f"No GitHub Pull Request Found for PR ID: {pull_request}",
                    )
                if response.status == 403:
                    logging.log(
                        logging.ERROR,
                        f"Rate Limit Exceeded for PR ID: {pull_request}",
                    )
    except Exception as e:
        logging.log(
            logging.ERROR,
            f"Error Fetching GitHub Pull Request Details for PR ID: {pull_request}, Error: {e}",
        )

    return None
