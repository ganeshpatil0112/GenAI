"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-12-04
Description: Jira Similar Defect App
"""

from http.client import HTTPException
from rsa import verify
from jira_similar_def_app.jira_api_helper import (
    handle_post_request_chat_completion,
    update_or_insert_jira_jql_data,
    handle_jira_chat_completion,
    upload_jira_bulk_data,
    upload_jira_jql_data,
    add_user_feedback,
)
from jira_similar_def_app.api_model import (
    JiraAPIBulkIssues,
    SimilarDefectRequest,
    UserFeedBackModel,
)
from jira_similar_def_app.user_feedback import (
    get_all_feedback as get_all_jira_userfeedback,
)
from jira_similar_def_app.authentication import (
    generate_jwt,
    verify_jwt_token,
    get_user_from_jwt,
)
from jira_similar_def_app.jira_tool_helper import find_similar_defects
from fastapi import APIRouter, Request, Response, WebSocket, WebSocketDisconnect
from interfaces.chat_completion import ChatCompletionInterface
from jira_similar_def_app.models import JiraModel, UserFeedBack
from api.models import PostRequestUserQuery, UserQuery
from fastapi.security import OAuth2PasswordBearer
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
from typing import List, Dict, Annotated
from fastapi import Depends, FastAPI
from prometheus_client import Gauge
from datetime import datetime
from uuid import uuid4
import logging
import asyncio
import json
import os

APP_DIR = os.path.dirname(os.path.abspath(__file__))

jsdf_router = APIRouter()
jsdf_router.mount(
    "/jsdf/static/",
    StaticFiles(directory=os.path.join(APP_DIR, "static"), html=True),
    name="static",
)
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")


@jsdf_router.get("/help", tags=["Jira Similar Defect"])
async def get_jsdf_help():
    """Get the help page for Jira Similar Defect."""

    return RedirectResponse(url="static/jsdf_help_page.html")


class WebSocketManager:

    def __init__(self):
        """Intialize Websocket Manager"""
        self.active_connections: List[WebSocket] = []
        self.logger = logging.getLogger(self.__class__.__name__)

    async def connect(self, websocket: WebSocket):
        """Handle websocket connection"""

        logging.log(
            logging.INFO,
            "WebSocket connection accepted",
        )

        await websocket.accept()
        self.active_connections.append(websocket)

        await websocket.send_text("Connection established")

    async def disconnect(self, websocket: WebSocket):
        """Handle websocket disconnection"""

        logging.log(
            logging.INFO,
            "WebSocket connection closed",
        )

        self.active_connections.remove(websocket)


websocket_manager = WebSocketManager()


@jsdf_router.websocket("/chat")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket Endpoint for Chat Completion"""
    await websocket.accept()
    logging.info("WebSocket connection accepted")

    llm_chains: Dict[str, ChatCompletionInterface | None] = {}

    try:
        while True:
            str_data = await websocket.receive_text()
            json_data = json.loads(str_data)
            user_query = UserQuery(**json_data)

            logging.log(
                logging.INFO,
                f"Received user query: {user_query.query} with session id: {user_query.session_id}",
            )

            if user_query.session_id not in llm_chains:
                llm_chains[user_query.session_id] = await handle_jira_chat_completion()

            llm_chain = llm_chains[user_query.session_id]

            if not llm_chain:
                logging.error("Error: LLMChain is null")
                await websocket.send_text("Error: Unable to process the request")
                await websocket.close()
            else:
                await llm_chain.astream_response(
                    websocket,
                    user_query.query,
                )
    except WebSocketDisconnect:
        logging.info("WebSocket connection closed")

        llm_chains.clear()

jsdf_response_token = Gauge(
        "jsdf_response_token",
        "Length of the result returned by /chat endpoint",
        ["client_ip", "username", "token_used"],
)

total_chat_requests = Gauge(
    "total_chat_requests",
    "Chat requests (restorable)"
)

from .otp import get_gauge, store_gauge

@jsdf_router.post("/chat", tags=["Jira Similar Defect"])
async def chat_completion(
    request: Request,
    user_query: PostRequestUserQuery,
    token: Annotated[str, Depends(oauth2_scheme)],
):
    """Chat Completion API for Jira Similar Defect"""

    if verify_jwt_token(token) is None:
        logging.error("Invalid or expired JWT token")
        return Response(
            content="Invalid or expired JWT token",
            status_code=401,
        )

    logging.log(
        logging.INFO,
        f"Received user query: {user_query.messages[-1]}",
    )

    if not user_query.messages:
        return "Error: Empty query"

    result = await handle_post_request_chat_completion(user_query)


    try:
        user_email = get_user_from_jwt(token)
        token_used = len(result) if result else 0
        client_ip = request.client.host if request.client else "unknown"
        username = user_email if user_email else "unknown"
        chat_request_count = float(get_gauge())
        total_chat_requests.set(chat_request_count)
        total_chat_requests.inc()
        store_gauge(str(chat_request_count + 1))

        jsdf_response_token.labels(
            client_ip=client_ip, username=username, token_used=token_used
        ).set(len(result) if result is not None else 0)
    except Exception as e:
        logging.error(f"Failed to set Prometheus metric: {e}")

    logging.log(
        logging.INFO,
        f"{request.client.host if request.client else ''} | {datetime.now()} | {user_query.messages[-1].content} | {200 if result else 404} | {result}",
    )

    return result


@jsdf_router.post(
    "/find_similar_defect",
    tags=["Jira Similar Defect"],
    response_model=List[JiraModel],
    response_model_exclude_unset=True,
)
async def get_similar_defects(similar_defect_request: SimilarDefectRequest):
    """Get similar defects based on the query provided.
    ### Args:
    -   similar_defect_request (SimilarDefectRequest): The request to Jira Similar Defects.
    """

    return await find_similar_defects(
        similar_defect_request.query,
        similar_defect_request.limit,
        similar_defect_request.filters,
    )


@jsdf_router.post(
    "/upload_jira_defects", tags=["Jira Similar Defect"], response_model=str
)
async def upload_jira_defects(jira_bulk_issues: JiraAPIBulkIssues):
    """Upload Jira defects to the database.
    ### Args:
    - jira_bulk_issues: `JiraAPIBulkIssues`, the bulk response from Jira API.
    """

    await upload_jira_bulk_data(jira_bulk_issues)


@jsdf_router.post(
    "/upload_jira_data_jql", tags=["Jira Similar Defect"], response_model=str
)
async def upload_jira_data_jql(jql_query: str):
    """Upload Jira defects to the database using JQL query.
    ### Args:
    - jql_query: str, the JQL query to fetch Jira defects.
    """

    task_id = uuid4().hex

    asyncio.create_task(upload_jira_jql_data(jql_query, task_id))

    return f"Task {task_id} created to upload Jira Data using JQL: {jql_query}"


@jsdf_router.post(
    "/update_or_insert_jira_data_jql", tags=["Jira Similar Defect"], response_model=str
)
async def update_or_insert_jira_data_jql(jql_query: str):
    """Update or Insert Jira defects to the database using JQL query.
    ### Args:
    - jql_query: str, the JQL query to fetch Jira defects.
    """

    task_id = uuid4().hex

    asyncio.create_task(update_or_insert_jira_jql_data(jql_query, task_id))

    return (
        f"Task {task_id} created to update or insert Jira Data using JQL: {jql_query}"
    )


@jsdf_router.get("/get_task_status", tags=["Jira Similar Defect"], response_model=str)
async def get_task_status(task_id: str):
    """Get the status of the task.
    ### Args:
    - task_id: str, the ID of the task.
    """

    # TODO: Implement the logic to get the status of the task

    return f"Task {task_id} is "


@jsdf_router.post(
    "/add_user_feedback", tags=["Jira Similar Defect"], response_model=str
)
async def post_user_feedback(user_feedback: UserFeedBackModel):
    """Add user feedback to the database.
    ### Args:
    - user_feedback: UserFeedBackModel, the user feedback.
    """

    await add_user_feedback(user_feedback)

    return "User Feedback added successfully."


@jsdf_router.post(
    "/get_all_feedback",
    tags=["Jira Similar Defect"],
    response_model=List[UserFeedBack],
)
async def get_all_feedback():
    """Get all user feedback from the database."""

    return await get_all_jira_userfeedback()


from pydantic import BaseModel, EmailStr
from .authentication import EmailSchema, send_email, generate_jwt, timedelta
from .otp import store_otp, verify_and_delete_otp
import random


class OTPRequest(BaseModel):
    email: EmailStr


class OTPVerifyRequest(BaseModel):
    email: EmailStr
    otp: str


@jsdf_router.post("/send_otp", tags=["user authentication"])
async def send_otp(request: OTPRequest):
    """Send OTP to user's email and store in DB with 15 min expiry."""
    otp = str(random.randint(100000, 999999))
    expires_at = datetime.now() + timedelta(minutes=15)
    store_otp(request.email, otp, expires_at)
    email_obj = EmailSchema(
        receiver=request.email,
        subject="Your OTP Code",
        body=f"Your OTP is: {otp}. It will expire in 15 minutes.",
    )
    await send_email(email_obj)
    return {"message": "OTP sent to email."}


@jsdf_router.post("/verify_otp", tags=["user authentication"])
async def verify_otp(request: OTPVerifyRequest):
    """Verify OTP and return JWT token if valid, then delete OTP from DB."""
    if verify_and_delete_otp(request.email, request.otp):
        token = generate_jwt(request.email)
        return {"access_token": token, "token_type": "bearer"}
    else:
        raise HTTPException(status_code=400, detail="Invalid or expired OTP.")
