from enum import Enum
from typing import Optional


class SerializableMixin:
    def to_json_string(self) -> str:
        if isinstance(self, Enum):
            return " ".join(list(map(str.capitalize, self.value.split("_"))))  # type: ignore
        return "Unknown Variable"


class DeserializableMixin:

    @classmethod
    def from_str(cls, string_value: str) -> Optional["DeserializableMixin"]:
        for members in cls:  # type: ignore
            if members.value == string_value.upper():
                return members

        return None

    @classmethod
    def from_json(cls, string_value: str) -> Optional["DeserializableMixin"]:

        acceptable_value = "_".join(
            list(
                filter(
                    lambda x: x,
                    [
                        "".join(filter(lambda ch: ch.isalpha(), word))
                        for word in string_value.upper().split(" ")
                    ],
                )
            )
        )

        for member in cls:  # type: ignore
            if member.value == acceptable_value:
                return member
        return None

    def __str__(self):
        return self.value  # type: ignore

    def to_string(self):
        return self.value  # type: ignore

    def __eq__(self, value: object) -> bool:
        return super().__eq__(value)

    def __ne__(self, value: object) -> bool:
        return super().__ne__(value)
