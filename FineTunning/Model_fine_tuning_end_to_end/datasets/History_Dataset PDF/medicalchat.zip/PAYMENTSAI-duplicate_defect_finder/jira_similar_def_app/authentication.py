"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2025-06-19
Description: Email Authentication and JWT Token Generation
"""

from fastapi.responses import JSONResponse
from fastapi_mail import FastMail, MessageSchema, ConnectionConfig, MessageType
from ldap3 import Server, Connection, ALL, NTLM, SIMPLE, SUBTREE
from pydantic import EmailStr, BaseModel, SecretStr
from datetime import datetime, timedelta, timezone
from simplejwt.jwt import encode, decode
import dotenv
import os
import httpx

dotenv.load_dotenv()


def generate_jwt(username: str) -> str | None:
    payload = {
        "sub": username,
        "iat": int(datetime.now(timezone.utc).timestamp()),
        "exp": int((datetime.now(timezone.utc) + timedelta(days=7)).timestamp()),
    }
    secret_key = os.getenv("JWT_SECRET_KEY", "default_secret_key")
    token = encode(secret_key, payload)
    return token


def verify_jwt_token(token: str) -> str | None:
    try:
        secret_key = os.getenv("JWT_SECRET_KEY", "default_secret_key")
        payload = decode(secret_key, token)
        payload_data = payload[1]
        sub, iat, exp = (
            payload_data.get("sub"),
            payload_data.get("iat"),
            payload_data.get("exp"),
        )
        if sub and iat and exp:
            if datetime.now(timezone.utc).timestamp() < exp:
                return sub
            else:
                print("Token has expired.")
                return None
        else:
            print("Invalid token payload.")
            return None
    except Exception as e:
        print(f"Error verifying token: {e}")
        return None


class EmailSchema(BaseModel):
    receiver: EmailStr
    subject: str
    body: str


async def send_email(email: EmailSchema) -> JSONResponse:
    url = os.getenv("MAIL_API_URL", "")
    payload = {
        "sender": "noreply@ddf.finastra.com",
        "receiver": email.receiver,
        "subject": email.subject,
        "body": email.body,
        "auth": os.getenv("MAIL_AUTH", ""),
    }
    headers = {"Content-Type": "application/json"}
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(url, json=payload, headers=headers)
            if response.status_code == 200:
                return JSONResponse(
                    status_code=200, content={"message": "Email sent successfully"}
                )
            else:
                print(f"Failed to send email: {response.text}")
                return JSONResponse(
                    status_code=500, content={"message": "Failed to send email"}
                )
        except Exception as e:
            print(f"Error sending email: {e}")
            return JSONResponse(
                status_code=500, content={"message": "Failed to send email"}
            )


def get_user_from_jwt(token: str) -> str | None:
    try:
        secret_key = os.getenv("JWT_SECRET_KEY", "default_secret_key")
        payload = decode(secret_key, token)
        payload_data = payload[1]
        sub = payload_data.get("sub")
        if sub:
            return sub
        else:
            print("Invalid token payload.")
            return None
    except Exception as e:
        print(f"Error verifying token: {e}")
        return None
