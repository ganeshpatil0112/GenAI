"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-14
Description: Azure Inferencing implementation.
"""

from langchain_core.language_models.chat_models import BaseChatModel
from utils.app_config import AppConfig, InfModelType
from utils.vars import get_azure_openai_api_key
from langchain_openai import AzureChatOpenAI
from pydantic.types import SecretStr
import logging


class AzureInferencing:
    """AzureInferencing class to get the inferencing client based on the database provider"""

    def __init__(self, appconfig=AppConfig().load_config()):
        """Initialize the AzureInferencing class with the appconfig and database provider
        ### Args:
        - `appconfig`: (AppConfig, optional): AppConfig object. Defaults to AppConfig().load_config().
        """

        self.logger = logging.getLogger(self.__class__.__name__)

        self.appconfig = appconfig

        self.azure_inferencing_config = self.appconfig.get_azure_ai_config()
        self.azure_llm_config = (
            self.azure_inferencing_config.get_azure_ai_config_llm_inf()
        )
        self.azure_slm_config = (
            self.azure_inferencing_config.get_azure_ai_config_slm_inf()
        )

        self.logger.log(
            logging.INFO,
            f"Initializing Azure Inferencing with model type: {self.azure_inferencing_config.azure_ai_inf_model_type}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Azure Inferencing Config: {self.azure_inferencing_config.__dict__}",
        )

        match self.azure_inferencing_config.azure_ai_inf_model_type:
            case InfModelType.LLM:
                self.logger.log(
                    logging.DEBUG,
                    f"Azure Inferencing with LLM Model: {self.azure_llm_config}",
                )
                self.inferencing_function = AzureChatOpenAI(
                    azure_deployment=self.azure_llm_config.deployment_id,
                    api_version=self.azure_llm_config.api_version,
                    azure_endpoint=self._get_endpoint(),
                    api_key=SecretStr(get_azure_openai_api_key()),
                    model=self.azure_llm_config.inference_model,
                    temperature=self.azure_llm_config.temperature,
                    max_tokens=self.azure_llm_config.max_tokens,
                    seed=self.azure_llm_config.seed,
                    streaming=True,
                )
            case InfModelType.SLM:
                self.logger.log(
                    logging.DEBUG,
                    f"Azure Inferencing with SLM Model: {self.azure_slm_config}",
                )
                pass

    def get_llm(self) -> BaseChatModel:
        """Get the Language Model for the Azure Inferencing
        ### Returns:
        - `BaseChatModel`: Azure Language Model for Inferencing
        """

        self.logger.log(
            logging.INFO,
            f"Getting Azure Language Model for Inferencing",
        )

        return self.inferencing_function

    def _get_endpoint(self) -> str:
        """Get the Azure Inferencing Endpoint
        ### Returns:
        - `str`: Azure Inferencing Endpoint
        """

        self.logger.log(
            logging.INFO,
            f"Getting Azure Inferencing Endpoint",
        )

        return f"https://{self.azure_llm_config.resource_name}.openai.azure.com/"
