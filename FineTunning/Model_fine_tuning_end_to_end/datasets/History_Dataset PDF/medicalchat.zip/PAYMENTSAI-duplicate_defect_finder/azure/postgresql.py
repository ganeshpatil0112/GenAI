"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-14
Description: Azure PostgreSQL implementation.
"""

from typing import List, Tuple
from langchain_postgres import PGVector
from langchain_core.documents import Document
from langchain_core.vectorstores import VectorStoreRetriever
from abstraction.embedding import AppEmbedding
from interfaces.database_inter import VectorDatabase
from utils.app_config import AppConfig
import logging


class PostgreSQL(VectorDatabase):
    """PostgreSQL class to get the inferencing client based on the database provider"""

    def __init__(self, appconfig=AppConfig.load_config()) -> None:
        """Initialize the PostgreSQL class with the appconfig and database provider
        ### Args:
        - `appconfig`: (AppConfig, optional): AppConfig object. Defaults to AppConfig().load_config().
        """

        self.logger = logging.getLogger(self.__class__.__name__)

        self.appconfig = appconfig

        self.pg_config = self.appconfig.get_database_config().postgresdb_config

        self.embedding_function = AppEmbedding(appconfig)
        self.appconfig = appconfig
        self.collection_name = (
            appconfig.get_database_config().postgresdb_config.collection_name
        )

        self.logger.log(
            logging.INFO,
            f"Initializing PostgreSQL with collection name: {self.collection_name}",
        )

        self.logger.log(
            logging.DEBUG,
            f"PostgreSQL Config: {self.pg_config.__dict__}, async_mode: True, use_jsonb: True",
        )

        super().__init__(
            db_client=PGVector(
                embeddings=self.embedding_function,
                collection_name=self.collection_name,
                connection=self._get_connection_string(),
                async_mode=True,
                use_jsonb=True,
            )
        )

    async def aadd_documents(self, documents: List[Document]) -> None:
        """Add documents to the database
        ### Args:
        - `documents`: List[Document]: List of documents to add to the database
        """

        self.logger.log(
            logging.INFO,
            f"Adding documents: {len(documents)} to the collection: {self.collection_name}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Adding Documents: {documents} to the collection: {self.collection_name}",
        )

        await super().aadd_documents(documents)

    async def adelete_by_field_value(self, field_name: str, field_value: str) -> None:
        """Delete documents from the database by field value

        ### Args:
        - `field_name`: str: Field name to search for
        - `field_value`: str: Field value to search for
        """

        self.logger.log(
            logging.INFO,
            f"Deleting documents with field name: {field_name}, field value: {field_value}",
        )

        ids_to_delete = await self.aget_document_ids(field_name, field_value)

        self.logger.log(
            logging.DEBUG,
            f"Deleting documents with field name: {field_name}, field value: {field_value}, len(ids): {len(ids_to_delete)}",
        )

        await self.adelete_by_id(ids_to_delete)

    async def adelete_by_id(self, ids: List[str]) -> bool | None:
        """Delete documents from the database by their ids
        ### Args:
        - `ids`: List[str]: List of ids of the documents to delete
        ### Returns:
        - `bool | None`: True if deleted else None

        ### Note:
        - The ids passed are not the document ids but the ids of the documents in the database
        """

        return await super().adelete_by_id(ids)

    async def search_document(
        self, query, limit, filters
    ) -> List[Tuple[Document, float]]:
        """Search for documents in the database
        ### Args:
        - `query`: str: Query to search for
        - `limit`: int: Limit the number of documents to return
        - `filters`: dict: Filters to apply while searching
        ### Returns:
        - `List[Tuple[Document, float]]`: List of documents and their scores
        """

        self.logger.log(
            logging.INFO,
            f"Searching for documents with query len: {len(query)}, limit: {limit}, filters: {len(filters)}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Searching for documents with query: {query}, limit: {limit}, filters: {filters}",
        )

        return await super().asimilarity_search_with_score(query, limit, filters)

    def get_retriever(self, limit: int) -> VectorStoreRetriever:
        """Get the retriever for the database
        ### Args:
        - `limit`: int: Limit the number of documents to return
        ### Returns:
        - `VectorStoreRetriever`: Vector Store Retriever object
        """

        self.logger.log(
            logging.INFO,
            f"Getting Vector Store Retriever with limit: {limit}",
        )

        return super().get_retriever(limit)

    def _get_connection_string(self) -> str:
        """Get the connection string for the PostgreSQL database"""

        postgresql_config = self.appconfig.get_database_config().postgresdb_config

        conn_string = f"postgresql+psycopg://{postgresql_config.database_user}:{postgresql_config.database_password}@{postgresql_config.database_host}:{postgresql_config.database_port}/{postgresql_config.database_name}".strip()

        self.logger.log(
            logging.INFO,
            f"Getting Connection String for PostgreSQL",
        )

        self.logger.log(
            logging.DEBUG,
            f"PostgreSQL Config: {postgresql_config}, Connection String: {conn_string}",
        )

        return conn_string
