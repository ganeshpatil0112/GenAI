"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-14
Description: Azure embedding implementation.
"""

from langchain_core.embeddings import Embeddings
from langchain_openai.embeddings import AzureOpenAIEmbeddings
from utils.vars import get_embedding_api_key
from pydantic.types import SecretStr
from typing import List, Optional
from utils.app_config import AppConfig
import logging


class AzureEmbeddings:
    """AzureEmbeddings class to get the embedding client based on the database provider"""

    def __init__(self, appconfig=AppConfig().load_config()):
        """Initialize the AzureEmbeddings class with the appconfig and database provider
        ### Args:
        - `appconfig`: (AppConfig, optional): AppConfig object. Defaults to AppConfig().load_config().
        """

        self.logger = logging.getLogger(self.__class__.__name__)

        self.appconfig = appconfig

        self.azure_embedding_config = (
            self.appconfig.get_azure_ai_config().get_azure_ai_config_embedding()
        )

        self.logger.log(
            logging.INFO,
            f"Initializing Azure Embeddings with dimension: {self.azure_embedding_config.dimension}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Azure Embeddings Config: {self.azure_embedding_config.__dict__}",
        )

        if self.azure_embedding_config.dimension:
            self.logger.log(
                logging.DEBUG,
                f"Azure Embeddings with Dimension: {self.azure_embedding_config.dimension}",
            )
            self.embedding_functions = AzureOpenAIEmbeddings(
                model=self.azure_embedding_config.embedding_model,
                dimensions=self.azure_embedding_config.dimension,
                api_key=SecretStr(get_embedding_api_key()),
                openai_api_type="azure",
                api_version=self.azure_embedding_config.api_version,
                azure_endpoint=self._get_endpoint(),
            )
        else:
            self.logger.log(
                logging.DEBUG,
                f"Azure Embeddings no Dimension Specified: {self.azure_embedding_config.dimension}",
            )
            self.embedding_functions = AzureOpenAIEmbeddings(
                model=self.azure_embedding_config.embedding_model,
                api_key=SecretStr(get_embedding_api_key()),
                openai_api_type="azure",
                api_version=self.azure_embedding_config.api_version,
                azure_endpoint=self._get_endpoint(),
            )

    def embed_documents(self, texts: List[str]) -> Optional[List[List[float]]]:
        """Embed documents using Azure Embeddings
        ### Args:
        - `texts`: (List[str]): List of documents to be embedded
        ### Returns:
        - `Optional[List[List[float]]]`: List of embedded documents
        """

        self.logger.log(
            logging.INFO,
            f"Embedding documents using Azure Embeddings",
        )

        self.logger.log(
            logging.DEBUG,
            f"Embedding documents: {texts}",
        )

        return self.embedding_functions.embed_documents(texts)

    def embed_query(self, text: str) -> List[float]:
        """Embed query using Azure Embeddings
        ### Args:
        - `text`: (str): Query to be embedded
        ### Returns:
        - `List[float]`: Embedded query
        """

        self.logger.log(
            logging.INFO,
            f"Embedding query using Azure Embeddings",
        )

        self.logger.log(
            logging.DEBUG,
            f"Embedding query: {text}",
        )

        return self.embedding_functions.embed_query(text)

    async def aembed_documents(self, texts: List[str]) -> Optional[List[List[float]]]:
        """Embed documents using Azure Embeddings asynchronously
        ### Args:
        - `texts`: (List[str]): List of documents to be embedded
        ### Returns:
        - `Optional[List[List[float]]]`: List of embedded documents
        """

        self.logger.log(
            logging.INFO,
            f"Embedding documents using Azure Embeddings asynchronously",
        )

        self.logger.log(
            logging.DEBUG,
            f"Embedding documents: {texts}",
        )

        return await self.embedding_functions.aembed_documents(texts)

    async def aembed_query(self, text: str) -> Optional[List[float]]:
        """Embed query using Azure Embeddings asynchronously
        ### Args:
        - `text`: (str): Query to be embedded
        ### Returns:
        - `List[float]`: Embedded query
        """

        self.logger.log(
            logging.INFO,
            f"Embedding query using Azure Embeddings asynchronously",
        )

        self.logger.log(
            logging.DEBUG,
            f"Embedding query: {text}",
        )

        return await self.embedding_functions.aembed_query(text)

    def _get_endpoint(self) -> str:
        """Get the Azure Embedding Endpoint
        ### Returns:
        - `str`: Azure Embedding Endpoint
        """

        self.logger.log(
            logging.INFO,
            f"Getting Azure Embedding Endpoint",
        )

        return f"https://{self.azure_embedding_config.resource_name}.openai.azure.com/"
