"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-14
Description: Azure database implementation abstraction.
"""

from azure.chroma_db import ChromaDB
from interfaces.database_inter import VectorDatabase
from azure.postgresql import PostgreSQL
from utils.app_config import AppConfig, DatabaseProvider
import logging


class AzureDatabase:
    """AzureDatabase class to get the database client based on the database provider"""

    def __init__(self, appconfig=AppConfig.load_config()):
        """Initialize the AzureDatabase class with the appconfig and database provider
        ### Args:
        - `appconfig`: (AppConfig, optional): AppConfig object. Defaults to AppConfig.load_config().
        """

        self.logger = logging.getLogger(self.__class__.__name__)

        self.appconfig = appconfig
        self.database_provider = self.appconfig.get_database_config().database_provider

        self.logger.log(
            logging.INFO,
            f"Initializing Azure Database with provider: {self.database_provider}",
        )

        match self.database_provider:

            case DatabaseProvider.CHROMA:
                self.logger.log(
                    logging.DEBUG,
                    f"Azure Database Provider: {DatabaseProvider.CHROMA}",
                )
                self.db_client = ChromaDB(appconfig)

            case DatabaseProvider.POSTGRESQL:
                self.logger.log(
                    logging.DEBUG,
                    f"Azure Database Provider: {DatabaseProvider.POSTGRESQL}",
                )
                self.db_client = PostgreSQL(appconfig)

    def get_db_client(self) -> VectorDatabase:
        """Get the database client based on the database provider
        ### Returns:
        - `VectorDatabase`: Database client based on the database provider
        """

        self.logger.log(
            logging.INFO,
            f"Getting Azure Database Client",
        )

        return self.db_client
