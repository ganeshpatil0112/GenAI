"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-14
Description: Azure ChromaDB implementation.
"""

from langchain_core.documents import Document
from abstraction.embedding import AppEmbedding
from interfaces.database_inter import VectorDatabase
from langchain_core.vectorstores import VectorStoreRetriever
from utils.app_config import AppConfig
from langchain_chroma import Chroma
from chromadb import HttpClient as ChromaClient
from typing import List, Tuple
import logging


class ChromaDB(VectorDatabase):

    def __init__(self, appconfig=AppConfig().load_config()):
        """Initialize Azure ChromaDB
        ### Args:
        - `appconfig`: (AppConfig, optional): AppConfig instance. Defaults to AppConfig().load_config().
        """
        self.logger = logging.getLogger(self.__class__.__name__)

        self.embedding_function = AppEmbedding(appconfig)
        self.appconfig = appconfig

        self.chroma_config = self.appconfig.get_database_config().chroma_config

        self.logger.log(
            logging.INFO,
            f"Initializing Azure ChromaDB",
        )

        self.logger.log(
            logging.DEBUG,
            f"ChromaDB Config: {self.chroma_config.__dict__}",
        )

        self.chroma_client = ChromaClient(
            host=self.chroma_config.host_url, port=self.chroma_config.host_port
        )

        super().__init__(
            Chroma(
                collection_name=self.chroma_config.collection_name,
                embedding_function=self.embedding_function,
                client=self.chroma_client,
            )
        )

    async def aadd_documents(self, documents: List[Document]) -> None:
        """Add documents to Azure ChromaDB
        ### Args:
        - `documents`: (List[Document]): List of Documents to be added to Azure ChromaDB
        """

        self.logger.log(
            logging.INFO,
            f"Adding documents to Azure ChromaDB",
        )

        self.logger.log(
            logging.DEBUG,
            f"Adding documents: {documents}",
        )

        await super().aadd_documents(documents)

    async def asimilarity_search_with_score(
        self, query, limit, filters
    ) -> List[Tuple[Document, float]]:
        """Search documents in Azure ChromaDB
        ### Args:
        - `query`: (str): Query to search in Azure ChromaDB
        - `limit`: (int): Number of documents to return
        - `filters`: (dict): Filters to apply while searching
        ### Returns:
        - `List[Tuple[Document, float]]`: List of Documents and their respective scores
        """

        self.logger.log(
            logging.INFO,
            f"Searching documents in Azure ChromaDB",
        )

        self.logger.log(
            logging.DEBUG,
            f"Query: {query}, Limit: {limit}, Filters: {filters}",
        )

        return await super().asimilarity_search_with_score(query, limit, filters)

    def get_retriever(self, limit) -> VectorStoreRetriever:
        """Get retriever from Azure ChromaDB
        ### Args:
        - `limit`: (int): Number of documents to return
        ### Returns:
        - `VectorStoreRetriever`: VectorStoreRetriever instance
        """

        self.logger.log(
            logging.INFO,
            f"Getting retriever from Azure ChromaDB, Limit: {limit}",
        )

        return super().get_retriever(limit)
