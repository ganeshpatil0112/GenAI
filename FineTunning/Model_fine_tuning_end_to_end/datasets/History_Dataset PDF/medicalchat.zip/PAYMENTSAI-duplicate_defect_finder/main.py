"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-01
Description: Main Application Entry Point
"""

import logging
from fastapi import FastAPI
from utils.app_config import AppConfig
from contextlib import asynccontextmanager
from prometheus_client import make_asgi_app
from api.router import main_router as AppRouter
from fastapi.middleware.cors import CORSMiddleware

FORMAT = "[%(asctime)s %(filename)s->%(name)s.%(funcName)s():%(lineno)s] %(levelname)s: %(message)s"


@asynccontextmanager
async def lifespan_event(app: FastAPI):
    appconfig = AppConfig()
    log_file_path = appconfig.get_app_settings().get_log_file_path() or "main.log"
    log_level = appconfig.get_app_settings().get_log_level()

    logging.basicConfig(
        filename=log_file_path,
        filemode="a",
        level=log_level,
        format=FORMAT,
    )

    # Configure uvicorn.access logger
    uvicorn_logger = logging.getLogger("uvicorn.access")
    file_handler = logging.FileHandler(log_file_path)
    file_handler.setFormatter(logging.Formatter(FORMAT))
    uvicorn_logger.addHandler(file_handler)

    yield


app = FastAPI(title="Aiccelerate", lifespan=lifespan_event)
app.include_router(AppRouter)
metric_app = make_asgi_app()
app.mount("/metrics", metric_app)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
