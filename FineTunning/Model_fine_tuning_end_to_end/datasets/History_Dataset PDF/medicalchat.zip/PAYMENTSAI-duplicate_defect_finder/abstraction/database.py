"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-07
Description: App Level database implementation abstraction.
"""

from langchain_core.vectorstores import VectorStoreRetriever
from interfaces.database_inter import VectorDatabase
from utils.app_config import AppConfig, Hosted
from typing import List, Tuple, Optional, Dict
from langchain_core.documents import Document
from local.models import DBGetResultType
from local.database import LocalDatabase
from azure.database import AzureDatabase
import logging


class AppDatabase:
    """AppDatabase class to interact with the database with appconfig"""

    def __init__(self, appconfig=AppConfig().load_config()) -> None:
        """Initializes the AppDatabase class with appconfig
        ### Args:
        - `appconfig`: (AppConfig, optional): AppConfig instance. Defaults to AppConfig().load_config().
        """

        self.logger = logging.getLogger(self.__class__.__name__)
        self.appconfig = appconfig

        self.logger.log(
            logging.DEBUG,
            f"Database config: {appconfig.get_database_config()}",
        )
        self.logger.log(
            logging.INFO,
            f"Database Hosted: {appconfig.get_database_config().database_hosted}",
        )
        match appconfig.get_database_config().database_hosted:
            case Hosted.LOCAL:
                self.logger.log(
                    logging.DEBUG,
                    f"Database Config is Local",
                )
                self.db_client: VectorDatabase = LocalDatabase(
                    appconfig
                ).get_db_client()
            case Hosted.AZURE:
                self.logger.log(
                    logging.DEBUG,
                    f"Database Config is Azure",
                )
                self.db_client: VectorDatabase = AzureDatabase(
                    appconfig
                ).get_db_client()

    def add_documents(self, documents: List[Document]) -> List[str]:
        """Add documents to the database
        ### Args:
        - `documents`: (List[Document]): List of documents to add to the database"""

        self.logger.log(
            logging.INFO,
            f"Adding documents length: {len(documents)}",
        )
        self.logger.log(
            logging.DEBUG,
            f"Adding documents: {documents}",
        )
        return self.db_client.add_documents(documents)

    async def aadd_documents(self, documents: List[Document]) -> List[str]:
        """Add documents to the database
        ### Args:
        - `documents`: (List[Document]): List of documents to add to the database"""

        self.logger.log(
            logging.INFO,
            f"Adding documents length: {len(documents)}",
        )
        self.logger.log(
            logging.DEBUG,
            f"Adding documents: {documents}",
        )
        return await self.db_client.aadd_documents(documents)

    async def aupdate_documents(
        self, ids: List[str], documents: List[Document]
    ) -> None:
        """Update Document to the Database
        ### Args:
        - `documents`: List[Document]
        """

        self.logger.log(
            logging.INFO,
            f"Adding documents length: {len(documents)}",
        )
        self.logger.log(
            logging.DEBUG,
            f"Adding documents: {documents}",
        )

        defect_ids = [doc.metadata["defect_id"] for doc in documents]

        self.logger.log(
            logging.INFO,
            f"Updating documents with ids: {len(defect_ids)}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Updating documents with ids: {defect_ids}",
        )

        await self.db_client.aupdate_documents(ids, documents)

    def similarity_search_documents(
        self, query: str, limit: int, filters: Optional[Dict[str, str]]
    ) -> List[Tuple[Document, float]]:
        """Search documents in the database
        ### Args:
        - `query`: (str): Query to search documents
        - `limit`: (int): Limit of documents to return
        - `filters`: (Optional[Dict[str, str]]): Filters to apply to the search
        ### Returns:
        - `List[Tuple[Document, float]]`: List of documents with their similarity score
        """

        self.logger.log(
            logging.INFO,
            f"Searching documents, query len: {len(query)}, limit: {limit}, filters len: {len(filters or [])}",
        )
        self.logger.log(
            logging.DEBUG,
            f"Searching documents with query: {query}, limit: {limit}, filters: {filters}",
        )
        return self.db_client.similarity_search_with_score(query, limit, filters)

    async def asimilarity_search_documents(
        self, query: str, limit: int, filters: Optional[Dict[str, str]]
    ) -> List[Tuple[Document, float]]:
        """Search documents in the database
        ### Args:
        - `query`: (str): Query to search documents
        - `limit`: (int): Limit of documents to return
        - `filters`: (Optional[Dict[str, str]]): Filters to apply to the search
        ### Returns:
        - `List[Tuple[Document, float]]`: List of documents with their similarity score
        """

        self.logger.log(
            logging.INFO,
            f"Searching documents, query len: {len(query)}, limit: {limit}, filters len: {len(filters or [])}",
        )
        self.logger.log(
            logging.DEBUG,
            f"Searching documents with query: {query}, limit: {limit}, filters: {filters}",
        )
        return await self.db_client.asimilarity_search_with_score(query, limit, filters)

    def search_document_with_embeddings(
        self, query: List[float], limit: int
    ) -> List[Document]:
        """Search documents with embeddings
        ### Args:
        - `query`: (List[float]): Query vector
        - `limit`: (int): Limit of documents to return
        ### Returns:
        - `List[Document]`: List of documents with their similarity score
        """

        self.logger.log(
            logging.INFO,
            f"Searching documents with embeddings, query len: {len(query)}, limit: {limit}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Searching documents with embeddings with query: {query}, limit: {limit}",
        )

        return self.db_client.search_document_with_embeddings(query, limit)

    async def asearch_document_with_embeddings(
        self,
        query: List[float],
        limit: int,
    ) -> List[Document]:
        """Search documents with embeddings
        ### Args:
        - `query`: (List[float]): Query vector
        - `limit`: (int): Limit of documents to return
        ### Returns:
        - `List[Document]`: List of documents with their similarity score
        """

        self.logger.log(
            logging.INFO,
            f"Searching documents with embeddings, query len: {len(query)}, limit: {limit}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Searching documents with embeddings with query: {query}, limit: {limit}",
        )

        return await self.db_client.asearch_document_with_embeddings(query, limit)

    def get_document_by_id(self, doc_id: str) -> List[Document]:
        """Get document by id
        ### Args:
        - `doc_id`: (str): Document id
        ### Returns:
        - `Document`: Document with the given id
        """

        self.logger.log(
            logging.INFO,
            f"Getting document by id: {doc_id}",
        )
        return self.db_client.get_document_by_id(doc_id)

    async def aget_document_by_id(self, doc_id: str) -> List[Document]:
        """Get document by id
        ### Args:
        - `doc_id`: (str): Document id
        ### Returns:
        - `Document`: Document with the given id
        """

        self.logger.log(
            logging.INFO,
            f"Getting document by id: {doc_id}",
        )
        return await self.db_client.aget_document_by_id(doc_id)

    async def aget_document_by_field(
        self, field_name: str, field_value: str
    ) -> DBGetResultType:
        """Get document by field_name and field_value
        ### Args:
        - `field_name`: (str): Field name
        - `field_value`: (str): Field value
        ### Returns:
        - `Document`: Document with the given field_name and field_value
        """

        self.logger.log(
            logging.INFO,
            f"Getting document by field_name: {field_name} and field_value: {field_value}",
        )
        return await self.db_client.aget_document_with_filter(field_name, field_value)

    async def aget_document_metadata_by_field(
        self, field_name: str, field_value: str
    ) -> List[dict]:
        """Get document metadata by field_name and field_value
        ### Args:
        - `field_name`: (str): Field name
        - `field_value`: (str): Field value
        ### Returns:
        - `Document`: Document with the given field_name and field_value
        """

        self.logger.log(
            logging.INFO,
            f"Getting document metadata by field_name: {field_name} and field_value: {field_value}",
        )

        return await self.db_client.aget_document_metadatas(field_name, field_value)

    async def adelete_document_by_id(self, ids: List[str]) -> Optional[bool]:
        """Delete Document by id
        ### Args:
        - `doc_id`: (str): Document id
        ### Returns:
        - `Document`: Document with the given id
        """

        self.logger.log(logging.INFO, f"Deleting document by ids len: {len(ids)}")

        self.logger.log(
            logging.DEBUG,
            f"Deleting document by ids: {ids}",
        )

        return await self.db_client.adelete_by_id(ids=ids)

    async def adelete_document_by_field(
        self, field_name: str, field_value: str
    ) -> Optional[bool]:
        """Delete Document by field_name and field_value
        ### Args:
        - `field_name`: (str): Field name
        - `field_value`: (str): Field value
        """

        self.logger.log(
            logging.INFO,
            f"Deleting document by field_name: {field_name} and field_value: {field_value}",
        )

        return await self.db_client.adelete_by_field_value(field_name, field_value)

    def get_client(self) -> VectorDatabase:
        """Get the database client
        ### Returns:
        - `VectorDatabase`: Database client"""

        self.logger.log(
            logging.INFO,
            "Getting database client",
        )
        return self.db_client

    async def aget_client(self) -> VectorDatabase:
        """Get the database client
        ### Returns:
        - `VectorDatabase`: Database client"""

        self.logger.log(
            logging.INFO,
            "Getting database client",
        )
        return self.db_client

    def as_retriever(self, limit: int) -> VectorStoreRetriever:
        """Get the database Retriever
        ### Args:
        - `limit`: (int): Limit of documents to return
        ### Returns:
        - `VectorStoreRetriever`: Database Retriever
        """

        return self.db_client.get_retriever(limit)
