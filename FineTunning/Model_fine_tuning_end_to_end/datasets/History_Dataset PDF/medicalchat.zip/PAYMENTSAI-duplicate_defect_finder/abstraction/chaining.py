"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-25
Description: App LLM Chaining abstraction.
"""

from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.chains.retrieval import create_retrieval_chain
from langchain_core.language_models import BaseChatModel
from abstraction.chat_completion import (
    ChatCompletionLangGraph,
    ChatCompletionToolCall,
    ChatCompletionWithRetriver,
    ToolCallHandlerArgs,
)
from interfaces.chat_completion import ChatCompletionInterface
from langchain_core.messages import SystemMessage, ToolMessage
from typing import Awaitable, Callable, Optional, Any, List
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.messages.base import BaseMessage
from langgraph.checkpoint.memory import MemorySaver
from langgraph.prebuilt import create_react_agent
from utils.app_config import AppConfig
from datetime import datetime
from uuid import uuid4
import logging


class LLMAgentChain:

    def __init__(
        self,
        messages: List[BaseMessage],
        llm: Optional[BaseChatModel],
        tools: List,
        function_call_handler: Optional[
            Callable[[ToolCallHandlerArgs], Awaitable[ToolMessage]]
        ],
        session_id: str = uuid4().hex,
        thread_id: str = uuid4().hex,
        appconfig=AppConfig().load_config(),
    ):
        """App LLM Chaining abstraction."""
        self.appconfig = appconfig
        self.messages = messages
        self.llm: Optional[BaseChatModel] = llm
        self.tools: List = tools
        self.memory = MemorySaver()

        self.session_id = session_id
        self.thread_id = thread_id

        self.stream: bool = False

        self.function_call_handler = function_call_handler

        self.logger = logging.getLogger(self.__class__.__name__)

    def with_stream(self, stream: bool = False) -> "LLMAgentChain":
        """Set the stream flag.
        ### Args:
        `stream`: bool The stream flag.
        """
        self.stream = stream

        return self

    def build(self) -> Optional[ChatCompletionInterface]:
        """Build the LLM chain

        ### Returns
        - ChatCompletion object
        """

        if not self.llm:
            self.logger.error("LLMChain: LLM is required to build the chain.")
            return None

        if self.tools:
            self.logger.log(
                logging.INFO,
                f"LLMChain: Adding tools to the chain: {self.tools}",
            )

            if self.stream and self.function_call_handler:

                llm_with_tools = self.llm.bind_tools(self.tools)

                return (
                    ChatCompletionToolCall(
                        functional_call_handler=self.function_call_handler,
                        messages=self.messages,
                        appconfig=self.appconfig,
                    )
                    .with_session_id(self.session_id)
                    .with_thread_id(self.thread_id)
                    .with_llm_chain(llm_with_tools)
                )
            else:
                self.agent_executor = create_react_agent(
                    self.llm, self.tools, checkpointer=self.memory
                )

                return (
                    ChatCompletionLangGraph(
                        messages=self.messages, appconfig=self.appconfig
                    )
                    .with_session_id(self.session_id)
                    .with_thread_id(self.thread_id)
                    .with_llm_chain(self.agent_executor)
                )

        return None


class LLMChain:

    def __init__(
        self,
        session_id: str = uuid4().hex,
        thread_id: str = uuid4().hex,
        appconfig=AppConfig().load_config(),
        function_call_handler: Optional[
            Callable[[ToolCallHandlerArgs], Awaitable[ToolMessage]]
        ] = None,
    ):
        """App LLM Chaining abstraction."""
        self.appconfig = appconfig
        self.messages: List[BaseMessage] = [
            SystemMessage(
                content=f"""You're a AI Assistant. Helps user find information Related to Jira Defects., 
                    Use the Tools to answer the question or if it's unrelated politely refuse to answer.
                    Don't make up information. Today is {datetime.now()}.
                    """,
            ),
        ]
        self.retriever: Optional[Any] = None
        self.llm: Optional[BaseChatModel] = None
        self.session_id: str = session_id
        self.thread_id: str = thread_id
        self.tools: List = []
        self.function_call_handler = function_call_handler
        self.stream_output = False

        self.logger = logging.getLogger(self.__class__.__name__)

    def with_system_message(self, message: str) -> "LLMChain":
        """Set the system message.
        ### Args:
        `message`: str The system message.
        """

        self.messages = [SystemMessage(content=message)]

        return self

    def with_document_retriever(self, retriever: Any) -> "LLMChain":
        """Add a retriever to the chain.
        ### Args:
        `retriever`: The retriever to add.
        """
        self.retriever = retriever
        return self

    def with_llm(self, llm: Any) -> "LLMChain":
        """Add a LLM to the chain.
        ### Args:
        `llm`: The LLM to add.
        """
        self.llm = llm
        return self

    def with_tools(self, tools: List) -> "LLMChain":
        """Add Tools to the chain.
        ### Args:
        `tools`: List of tools to add.
        """

        self.tools = tools

        return self

    def with_function_call_handler(
        self,
        function_call_handler: Callable[[ToolCallHandlerArgs], Awaitable[ToolMessage]],
    ) -> "LLMChain":
        """Add a function call handler to the chain.
        ### Args:
        `function_call_handler`: The function call handler to add.
        """

        self.function_call_handler = function_call_handler

        return self

    def with_stream_output(self, stream_output: bool = False) -> "LLMChain":
        """Set the stream output flag.
        ### Args:
        `stream_output`: bool The stream output flag.
        """

        self.stream_output = stream_output

        return self

    def build(self) -> Optional[ChatCompletionInterface]:
        """Build the LLM chain."""

        if not self.llm:
            self.logger.error("LLMChain: LLM is required to build the chain.")
            return None

        if self.tools:
            self.logger.log(
                logging.INFO,
                f"LLMChain: Adding tools to the chain: {self.tools}",
            )
            return (
                LLMAgentChain(
                    self.messages,
                    self.llm,
                    self.tools,
                    self.function_call_handler,
                    self.session_id,
                    self.thread_id,
                    self.appconfig,
                )
                .with_stream(self.stream_output)
                .build()
            )

        if self.retriever:
            document_chain = create_stuff_documents_chain(
                llm=self.llm,
                prompt=ChatPromptTemplate.from_messages(
                    [
                        (
                            "system",
                            f"""{self.messages[0].content}\n\n{{context}}""",
                        )
                    ]
                ),
            )
            self.retrieval_chain = create_retrieval_chain(
                self.retriever, document_chain
            )

            return (
                ChatCompletionWithRetriver(
                    self.messages,
                    self.appconfig,
                )
                .with_session_id(self.session_id)
                .with_thread_id(self.thread_id)
                .with_llm_chain(self.retrieval_chain)
            )

        return None
