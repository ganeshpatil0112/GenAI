"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-07
Description: App Level Embedding implementation abstraction.
"""

from typing import List, Optional
from langchain_core.embeddings import Embeddings
from local.embedding import LocalEmbedding
from azure.embedding import AzureEmbeddings
from utils.app_config import AppConfig, Hosted
import logging


class AppEmbedding(Embeddings):
    """Abstraction for embedding models"""

    def __init__(self, appconfig=AppConfig().load_config()):
        """Initializes the AppEmbedding class with appconfig
        ### Args:
        - `appconfig`: (AppConfig, optional): AppConfig instance. Defaults to AppConfig().load_config().
        """

        self.logger = logging.getLogger(self.__class__.__name__)

        self.appconfig = appconfig

        self.logger.log(
            logging.INFO,
            f"Embedding model: {self.appconfig.get_embedding_model_hosted()}",
        )

        match self.appconfig.get_embedding_model_hosted():
            case Hosted.AZURE:
                self.logger.log(logging.DEBUG, f"Embedding model Hosted {Hosted.AZURE}")
                self.embedding_functions = AzureEmbeddings(appconfig=self.appconfig)
            case Hosted.LOCAL:
                self.logger.log(logging.DEBUG, f"Embedding model Hosted {Hosted.LOCAL}")
                self.embedding_functions = LocalEmbedding(appconfig=self.appconfig)

    def embed_documents(self, texts: List[str]) -> Optional[List[List[float]]]:
        """Embeds the documents
        ### Args:
        - `texts`: (List[str]): List of documents to embed
        ### Returns:
        - `Optional[List[List[float]]]`: List of embedded documents"""

        self.logger.log(logging.INFO, f"Embedding documents len: {len(texts)}")
        self.logger.log(logging.DEBUG, f"Embedding documents: {texts}")

        return self.embedding_functions.embed_documents(texts)

    def embed_query(self, text: str) -> List[float]:
        """Embeds the query
        ### Args:
        - `text`: (str): Query to embed
        ### Returns:
        - `List[float]`: Embedded query"""

        self.logger.log(logging.INFO, f"Embedding query len: {len(text)}")
        self.logger.log(logging.DEBUG, f"Embedding query: {text}")

        return self.embedding_functions.embed_query(text)

    async def aembed_documents(self, texts: List[str]) -> Optional[List[List[float]]]:
        """Embeds the documents
        ### Args:
        - `texts`: (List[str]): List of documents to embed
        ### Returns:
        - `Optional[List[List[float]]]`: List of embedded documents
        """

        self.logger.log(logging.INFO, f"Embedding documents len: {len(texts)}")
        self.logger.log(logging.DEBUG, f"Embedding documents: {texts}")

        return await self.embedding_functions.aembed_documents(texts)

    async def aembed_query(self, text: str) -> Optional[List[float]]:
        """Embeds the query
        ### Args:
        - `text`: (str): Query to embed
        ### Returns:
        - `List[float]`: Embedded query
        """

        self.logger.log(logging.INFO, f"Embedding query len: {len(text)}")
        self.logger.log(logging.DEBUG, float, f"Embedding query: {text}")

        return await self.embedding_functions.aembed_query(text)
