"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-07
Description: App Level Inferencing implementation abstraction.
"""

from langchain_core.language_models.chat_models import BaseChatModel
from azure.inferencing import AzureInferencing
from local.inferencing import LocalInferencing
from utils.app_config import AppConfig, Hosted
import logging


class AppInferencing:
    """AppInferencing class to get the Language Model from the Inferencing Model"""

    def __init__(self, appconfig=AppConfig().load_config()):
        """Initializes the AppInferencing class
        ### Args:
        - `appconfig`: (AppConfig, optional): AppConfig instance. Defaults to AppConfig().load_config().
        """

        self.logger = logging.getLogger(self.__class__.__name__)

        self.appconfig = appconfig

        self.logger.log(
            logging.INFO,
            f"Inferencing Model Hosted: {self.appconfig.get_inferencing_model_hosted()}",
        )

        match self.appconfig.get_inferencing_model_hosted():

            case Hosted.AZURE:
                self.logger.log(logging.DEBUG, "Inferencing Model Hosted on Azure")
                self.inferencing_functions = AzureInferencing(appconfig=self.appconfig)
            case Hosted.LOCAL:
                self.logger.log(logging.DEBUG, "Inferencing Model Hosted Locally")
                self.inferencing_functions = LocalInferencing(appconfig=self.appconfig)

    def get_llm(self) -> BaseChatModel:
        """Gets the Language Model from the Inferencing Model
        ### Returns:
        - `BaseChatModel`: Language Model from the Inferencing Model"""

        self.logger.log(logging.INFO, "Getting Language Model from Inferencing Model")
        return self.inferencing_functions.get_llm()
