"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-07
Description: App Level Chat Completion for user.
"""

import json
from pyexpat.errors import messages
from langchain_core.messages import (
    HumanMessage,
    trim_messages,
    AIMessageChunk,
    ToolMessage,
    AIMessage,
    BaseMessage,
)
from typing import Awaitable, Optional, List, Any, Callable, TypedDict
from interfaces.chat_completion import ChatCompletionInterface
from langchain_core.runnables import Runnable, RunnableConfig
from abstraction.inferencing import AppInferencing
from langchain_core.messages.tool import tool_call
from langgraph.graph.graph import CompiledGraph
from abstraction.database import AppDatabase
from utils.app_config import AppConfig
from collections import defaultdict
from fastapi import WebSocket
import logging


MAX_TOKEN_LIMIT = 50000


class ToolCallHandlerArgs(TypedDict):
    tool_id: str
    tool_name: str
    tool_args: str


class ChatCompletionLangGraph(ChatCompletionInterface):
    """Chat Completion for User, Token Streaming not supported."""

    def __init__(
        self,
        messages: List = [],
        appconfig=AppConfig().load_config(),
        trimmer: Any = None,
    ):
        """Initialize Chat Completion
        ### Args:
        - llm: Runnable llm chain
        - session_id: str Session ID for user
        - websocket: WebSocket to give response
        - appconfig: AppConfig default load appconfig
        """

        self.app_inferencing = AppInferencing(appconfig)
        self.app_database = AppDatabase(appconfig)
        self.logger = logging.getLogger(self.__class__.__name__)

        self.llm_chain: Optional[CompiledGraph] = None
        functional_call_handler: Callable[[ToolCallHandlerArgs], Awaitable[ToolMessage]]

        super().__init__(
            messages,
            False,
            trimmer
            or trim_messages(
                max_tokens=MAX_TOKEN_LIMIT,
                strategy="last",
                token_counter=self.app_inferencing.get_llm(),
                include_system=True,
                allow_partial=False,
                start_on="human",
            ),
            appconfig=appconfig,
        )

    def with_session_id(self, session_id: str) -> "ChatCompletionLangGraph":
        """Set Session ID for user
        ### Args:
        - session_id: str Session ID for user
        ### Returns:
        - ChatCompletion: ChatCompletion object
        """

        self.logger.log(
            logging.INFO,
            f"Setting Session ID for user: {session_id}",
        )

        self.session_id = session_id

        return self

    def with_thread_id(self, thread_id: str) -> "ChatCompletionLangGraph":
        """Set Thread ID for user
        ### Args:
        - thread_id: str Thread ID for user
        ### Returns:
        - ChatCompletion: ChatCompletion object
        """

        self.logger.log(
            logging.INFO,
            f"Setting Thread ID for user: {thread_id}",
        )

        self.thread_id = thread_id

        return self

    def with_llm_chain(
        self, llm_chain: Optional[CompiledGraph]
    ) -> "ChatCompletionLangGraph":
        """Set LLM Chain for user
        ### Args:
        - llm_chain: Runnable LLM Chain for user
        ### Returns:
        - ChatCompletion: ChatCompletion object
        """

        self.logger.log(
            logging.INFO,
            f"Setting LLM Chain for user",
        )

        self.llm_chain = llm_chain

        return self

    async def with_functional_call_handler(
        self,
        functional_call_handler: Callable[
            [ToolCallHandlerArgs], Awaitable[ToolMessage]
        ],
    ) -> "ChatCompletionLangGraph":
        """Set Functional Call Handler for user
        ### Args:
        - functional_call_handler: Callable Function to handle tool call
        ### Returns:
        - ChatCompletion: ChatCompletion object
        """

        self.logger.log(
            logging.INFO,
            f"Setting Functional Call Handler for user",
        )

        self.functional_call_handler = functional_call_handler

        return self

    async def aresponse(self, user_query: str) -> str | None:
        """Get the response for User"""

        self.logger.log(
            logging.DEBUG,
            f"Received user query: {self.messages} with session id: {self.session_id}",
        )

        if not self.llm_chain:
            self.logger.log(
                logging.ERROR,
                f"LLM Chain is not set for user",
            )

            return None

        self.messages.append(HumanMessage(content=user_query))
        trimmed_messages = self.trimmer.invoke(self.messages)

        if self.llm_chain:
            response = await self.llm_chain.ainvoke(
                {"messages": trimmed_messages},
                config=RunnableConfig(
                    configurable={
                        "session_id": self.session_id,
                        "thread_id": self.thread_id,
                    }
                ),
            )

            self.logger.log(
                logging.DEBUG,
                f"Response for user query: {self.messages} is: {response}",
            )

            if "messages" in response:
                self.messages = response["messages"]
                return response["messages"][-1].content

        return None

    async def _handle_tool_call(self, tool_args: ToolCallHandlerArgs) -> ToolMessage:
        """Handle Tool Call for User
        ### Args:
        - function_name: str Function Name
        - function_args: str Function Args
        ### Returns:
        - ToolMessage: Tool Message
        """

        self.logger.log(
            logging.DEBUG,
            f"Received Tool Call with args: {tool_args}",
        )

        return await self.functional_call_handler(tool_args)

    async def aresponse_with_history(
        self, user_queries: List[BaseMessage]
    ) -> str | None:
        """Response to user query with history"""

        self.logger.log(
            logging.DEBUG,
            f"Received user query: {user_queries} with session id: {self.session_id}",
        )

        if not self.llm_chain:
            self.logger.log(
                logging.ERROR,
                f"LLM Chain is not set for user",
            )

            return None

        trimmed_messages = self.trimmer.invoke(user_queries)

        if self.llm_chain:
            response = await self.llm_chain.ainvoke(
                {"messages": trimmed_messages},
                config=RunnableConfig(
                    configurable={
                        "session_id": self.session_id,
                        "thread_id": self.thread_id,
                    }
                ),
            )

            self.logger.log(
                logging.DEBUG,
                f"Response for user query: {user_queries} is: {response}",
            )

            if "messages" in response:
                self.messages = response["messages"]
                return response["messages"][-1].content

            if "tools" in response:
                tool_message = response["tools"]
                tool_name = tool_message["name"]
                tool_args = tool_message["args"]
                tool_id = tool_message["id"]

                self.logger.log(logging.DEBUG, f"Call Tool: {tool_id}")

                tool_message = await self._handle_tool_call(
                    ToolCallHandlerArgs(
                        tool_id=tool_id, tool_name=tool_name, tool_args=tool_args
                    )
                )
                self.messages.append(tool_message)

            print(response)

        return None

    async def astream_response(self, websocket: WebSocket, user_query: str) -> None:
        """Stream the response to User"""

        self.logger.log(
            logging.DEBUG,
            f"Received user query: {user_query}",
        )

        if not self.llm_chain:
            self.logger.log(
                logging.ERROR,
                "LLM Chain is not set for user",
            )
            await websocket.send_text("LLM Chain is not set for user")
            return

        self.messages.append(HumanMessage(content=user_query))
        trimmed_messages = self.trimmer.invoke(self.messages)

        if self.llm_chain:
            try:
                async for resp in self.llm_chain.astream(
                    {"messages": trimmed_messages},
                    config=RunnableConfig(
                        configurable={
                            "session_id": self.session_id,
                            "thread_id": self.thread_id,
                        }
                    ),
                    stream_mode="updates",
                ):
                    self.logger.log(logging.DEBUG, f"Received response chunk: {resp}")

                    if "agent" in resp:
                        if "messages" in resp["agent"]:
                            if resp["agent"]["messages"][-1].content:
                                trimmed_messages.extend(resp["agent"]["messages"])
                                await websocket.send_text(
                                    resp["agent"]["messages"][-1].content
                                )
                                self.logger.log(
                                    logging.DEBUG,
                                    f"Sent agent message: {resp['agent']['messages'][0].content}",
                                )

                    if "tools" in resp:
                        if "messages" in resp["tools"]:
                            if resp["tools"]["messages"][-1].content:
                                self.logger.log(
                                    logging.DEBUG,
                                    f"Sent tools message: {resp['tools']['messages'][0].content}",
                                )

            except Exception as e:
                self.logger.error(f"Error in streaming response: {e}")
                await websocket.send_text("Error in streaming response")


class ChatCompletionToolCall(ChatCompletionInterface):
    """Chat Completion for User, Token Streaming supported."""

    def __init__(
        self,
        functional_call_handler: Callable[
            [ToolCallHandlerArgs], Awaitable[ToolMessage]
        ],
        messages: List = [],
        appconfig=AppConfig().load_config(),
        trimmer: Any = None,
    ):
        """Initialize Chat Completion
        ### Args:
        - llm: Runnable llm chain
        - session_id: str Session ID for user
        - websocket: WebSocket to give response
        - appconfig: AppConfig default load appconfig
        """

        self.app_inferencing = AppInferencing(appconfig)
        self.app_database = AppDatabase(appconfig)
        self.logger = logging.getLogger(self.__class__.__name__)
        self.llm_with_tool: Optional[Runnable] = None
        self.function_call_handler = functional_call_handler

        super().__init__(
            messages,
            False,
            trimmer
            or trim_messages(
                max_tokens=MAX_TOKEN_LIMIT,
                strategy="last",
                token_counter=self.app_inferencing.get_llm(),
                include_system=True,
                allow_partial=False,
                start_on="human",
            ),
            appconfig=appconfig,
        )

    def with_llm_chain(
        self, llm_with_tool: Optional[Runnable]
    ) -> ChatCompletionInterface:
        """Set LLM Chain for user
        ### Args:
        - llm_chain: Runnable LLM Chain for user
        ### Returns:
        # ChatCompletion: ChatCompletion object
        """

        self.llm_with_tool = llm_with_tool

        return self

    async def _handle_tool_call(self, tool_args: ToolCallHandlerArgs) -> ToolMessage:
        """Handle Tool Call for User
        ### Args:
        - function_name: str Function Name
        - function_args: str Function Args
        ### Returns:
        - ToolMessage: Tool Message
        """

        self.logger.log(
            logging.DEBUG,
            f"Received Tool Call with args: {tool_args}",
        )

        return await self.function_call_handler(tool_args)

    async def aresponse(self, user_query: str) -> Optional[str]:
        """Get the response for User
        ### Args:
        - user_query: str User Query
        ### Returns:
        - str: Response for User
        """

        self.logger.log(
            logging.DEBUG,
            f"Received user query: {self.messages} with session id: {self.session_id}",
        )

        if not self.llm_with_tool:
            self.logger.log(
                logging.ERROR,
                f"LLM Chain is not set for user",
            )
            return None

        self.messages.append(HumanMessage(content=user_query))
        trimmed_messages = self.trimmer.invoke(self.messages)

        async for resp in self.llm_with_tool.astream(
            trimmed_messages,
            config=RunnableConfig(
                configurable={
                    "session_id": self.session_id,
                    "thread_id": self.thread_id,
                }
            ),
        ):
            if "tools" in resp:
                if "messages" in resp["tools"]:
                    if resp["tools"]["messages"][-1].content:
                        self.logger.log(
                            logging.DEBUG,
                            f"Sent tools message: {resp['tools']['messages'][0].content}",
                        )
                        return resp["tools"]["messages"][-1].content

        return None

    async def aresponse_with_history(
        self, user_queries: List[BaseMessage]
    ) -> str | None:
        """Response to user query with history"""

        self.logger.log(
            logging.DEBUG,
            f"Received user query: {user_queries} with session id: {self.session_id}",
        )

        if not self.llm_chain:
            self.logger.log(
                logging.ERROR,
                f"LLM Chain is not set for user",
            )

            return None

        trimmed_messages = self.trimmer.invoke(user_queries)

        if self.llm_chain:
            response = await self.llm_chain.ainvoke(
                {"messages": trimmed_messages},
                config=RunnableConfig(
                    configurable={
                        "session_id": self.session_id,
                        "thread_id": self.thread_id,
                    }
                ),
            )

            self.logger.log(
                logging.DEBUG,
                f"Response for user query: {user_queries} is: {response}",
            )

            if "messages" in response:
                self.messages = response["messages"]
                return response["messages"][-1].content

            if "tools" in response:
                tool_message = response["tools"]
                tool_name = tool_message["name"]
                tool_args = tool_message["args"]
                tool_id = tool_message["id"]

                self.logger.log(logging.DEBUG, f"Call Tool: {tool_id}")

                tool_message = await self._handle_tool_call(
                    ToolCallHandlerArgs(
                        tool_id=tool_id, tool_name=tool_name, tool_args=tool_args
                    )
                )

            print(response)

        return None

    async def astream_response(
        self, websocket: WebSocket, user_query: str, recurse: bool = False
    ) -> None:
        """Stream the response to User
        ### Args:
        - websocket: WebSocket to give response
        - user_query: str User Query
        - recurse: bool Recurse flag
        """

        # Don't Modify this code unless you know what you are doing
        # It seems messy but it's not, It handle most the cases

        self.logger.log(
            logging.DEBUG,
            f"Received user query: {user_query}",
        )

        if not self.llm_with_tool:
            self.logger.log(
                logging.ERROR,
                "LLM Chain is not set for user",
            )
            await websocket.send_text("LLM Chain is not set for user")
            return

        if not recurse:
            self.messages.append(HumanMessage(content=user_query))

        trimmed_messages = self.trimmer.invoke(self.messages)

        tool_call_ids: List[str] = []
        tool_call_args: dict[str, ToolCallHandlerArgs] = {}

        ai_message = ""

        async for chunk in self.llm_with_tool.astream(
            trimmed_messages,
            config=RunnableConfig(
                configurable={
                    "session_id": self.session_id,
                    "thread_id": self.thread_id,
                }
            ),
        ):
            if isinstance(chunk, AIMessageChunk):
                if chunk.additional_kwargs:
                    if "tool_calls" in chunk.additional_kwargs:
                        toolcall_args = chunk.additional_kwargs["tool_calls"]

                        for toolcall_arg in toolcall_args:
                            if toolcall_arg["id"]:
                                tool_call_ids.append(toolcall_arg["id"])
                                tool_call_args[tool_call_ids[-1]] = ToolCallHandlerArgs(
                                    tool_id=toolcall_arg["id"],
                                    tool_name=toolcall_arg["function"]["name"],
                                    tool_args="",
                                )
                            else:
                                tool_call_args[tool_call_ids[-1]][
                                    "tool_args"
                                ] += toolcall_arg["function"]["arguments"]
                if chunk.response_metadata:
                    response_metadata = chunk.response_metadata

                    if "finish_reason" in response_metadata:
                        if response_metadata["finish_reason"] == "tool_calls":
                            for index, tool_id in enumerate(tool_call_ids):
                                self.logger.log(logging.DEBUG, f"Call Tool: {tool_id}")
                                self.logger.log(
                                    logging.DEBUG,
                                    f"With Args: ",
                                    tool_call_args[tool_id],
                                )

                                tool_message = await self._handle_tool_call(
                                    tool_call_args[tool_id]
                                )

                                self.messages.append(
                                    AIMessage(
                                        content="",
                                        additional_kwargs={
                                            "tool_calls": [
                                                {
                                                    "index": index,
                                                    "id": tool_id,
                                                    "function": {
                                                        "arguments": str(
                                                            json.loads(
                                                                tool_call_args[tool_id][
                                                                    "tool_args"
                                                                ]
                                                            )
                                                        ),
                                                        "name": tool_call_args[tool_id][
                                                            "tool_name"
                                                        ],
                                                    },
                                                    "type": "function",
                                                }
                                            ]
                                        },
                                    )
                                )
                                self.messages.append(tool_message)

                            await self.astream_response(websocket, user_query, True)
                        if response_metadata["finish_reason"] == "stop":
                            logging.log(
                                logging.DEBUG,
                                f"Finish Reason: {response_metadata['finish_reason']}",
                            )
                            break
                        if response_metadata["finish_reason"] == "error":
                            logging.log(
                                logging.DEBUG,
                                f"Finish Reason: {response_metadata['finish_reason']}",
                            )
                            break
                        if response_metadata["finish_reason"] == "length":
                            logging.log(
                                logging.DEBUG,
                                f"Finish Reason: {response_metadata['finish_reason']}",
                            )
                            break

                if not (chunk.additional_kwargs and chunk.response_metadata):
                    if isinstance(chunk.content, str) and chunk.content:
                        await websocket.send_text(chunk.content)
                        ai_message += chunk.content

        if ai_message:
            self.messages.append(AIMessage(content=ai_message))


class ChatCompletionWithRetriver(ChatCompletionInterface):

    def __init__(
        self,
        messages: List = [],
        appconfig=AppConfig().load_config(),
        trimmer: Any = None,
    ):
        """Initialize Chat Completion
        ### Args:
        - llm: Runnable llm chain
        - session_id: str Session ID for user
        - websocket: WebSocket to give response
        - appconfig: AppConfig default load appconfig
        """

        self.app_inferencing = AppInferencing(appconfig)
        self.app_database = AppDatabase(appconfig)
        self.logger = logging.getLogger(self.__class__.__name__)

        self.llm_chain: Optional[Runnable] = None

        super().__init__(
            messages,
            False,
            trimmer
            or trim_messages(
                max_tokens=MAX_TOKEN_LIMIT,
                strategy="last",
                token_counter=self.app_inferencing.get_llm(),
                include_system=True,
                allow_partial=False,
                start_on="human",
            ),
            appconfig=appconfig,
        )

    def with_llm_chain(self, llm_chain: Optional[Runnable]) -> ChatCompletionInterface:
        """Set LLM Chain for user
        ### Args:
        - llm_chain: Runnable LLM Chain for user
        ### Returns:
        # ChatCompletion: ChatCompletion object
        """

        return super().with_llm_chain(llm_chain)

    async def aresponse(self, user_query: str) -> Optional[str]:
        """Get the response for User
        ### Args:
        - user_query: str User Query
        ### Returns:
        - str: Response for User
        """

        self.logger.log(
            logging.DEBUG,
            f"Received user query: {self.messages} with session id: {self.session_id}",
        )

        if not self.llm_chain:
            self.logger.log(
                logging.ERROR,
                f"LLM Chain is not set for user",
            )
            return None

        self.messages.append(HumanMessage(content=user_query))
        trimmed_messages = self.trimmer.invoke(self.messages)

        if self.llm_chain:
            response = await self.llm_chain.ainvoke(
                {"input": user_query, "chat_history": trimmed_messages},
                config=RunnableConfig(
                    configurable={
                        "session_id": self.session_id,
                        "thread_id": self.thread_id,
                    }
                ),
            )

            self.logger.log(
                logging.DEBUG,
                f"Response for user query: {self.messages} is: {response}",
            )

            if "answer" in response:
                self.messages.append(AIMessage(content=response["answer"]))
                return response["answer"]

        return None

    async def aresponse_with_history(
        self, user_queries: List[BaseMessage]
    ) -> str | None:
        """Response to user query with history"""

        self.logger.log(
            logging.DEBUG,
            f"Received user query: {user_queries} with session id: {self.session_id}",
        )

        if not self.llm_chain:
            self.logger.log(
                logging.ERROR,
                f"LLM Chain is not set for user",
            )

            return None

        trimmed_messages = self.trimmer.invoke(user_queries)

        if self.llm_chain:
            response = await self.llm_chain.ainvoke(
                {"messages": trimmed_messages},
                config=RunnableConfig(
                    configurable={
                        "session_id": self.session_id,
                        "thread_id": self.thread_id,
                    }
                ),
            )

            self.logger.log(
                logging.DEBUG,
                f"Response for user query: {user_queries} is: {response}",
            )

            if "messages" in response:
                self.messages = response["messages"]
                return response["messages"][-1].content

            print(response)

        return None

    async def astream_response(self, websocket: WebSocket, user_query: str) -> None:

        logging.log(
            logging.DEBUG,
            f"Received user query: {user_query}",
        )

        if not self.llm_chain:
            logging.log(
                logging.ERROR,
                "LLM Chain is not set for user",
            )
            await websocket.send_text("LLM Chain is not set for user")
            return

        self.messages.append(HumanMessage(content=user_query))
        trimmed_messages = self.trimmer.invoke(self.messages)

        async for resp in self.llm_chain.astream(
            {"input": trimmed_messages, "chat_history": trimmed_messages},
            config=RunnableConfig(
                configurable={
                    "session_id": self.session_id,
                    "thread_id": self.thread_id,
                }
            ),
            stream_mode="updates",
        ):

            await websocket.send_text(resp)

            logging.log(
                logging.DEBUG,
                f"Sent agent message: {resp['agent']['messages'][0].content}",
            )
