from utils.app_config import AppConfig, Hosted, InfModelType
from langchain_core.runnables import RunnableConfig
from abstraction.inferencing import AppInferencing
from abstraction.database import AppDatabase
from abstraction.chaining import LLMChain
import unittest


class TestChaining(unittest.IsolatedAsyncioTestCase):

    def test_chaining_require_param(self):
        """Test Chaining"""

        self.appconfig = AppConfig.load_config("./.config/test_config.toml")

        self.chaining = LLMChain(appconfig=self.appconfig).build()

        self.assertIsNone(self.chaining)

    async def test_chaining_with_params(self):
        """Test Chaining"""

        self.appconfig = AppConfig.load_config("./.config/app_testing_config.toml")

        # The Appconfig to use Azure

        self.appconfig._inferencing_model_hosted = Hosted.AZURE
        self.appconfig._embedding_model_hosted = Hosted.LOCAL
        self.appconfig._azure_ai_config.azure_ai_inf_model_type = InfModelType.LLM

        self.inferencing = AppInferencing(appconfig=self.appconfig)
        self.database = AppDatabase(appconfig=self.appconfig)

        self.chaining = (
            LLMChain(appconfig=self.appconfig)
            .with_llm(self.inferencing.get_llm())
            .with_document_retriever(self.database.as_retriever(2))
            .build()
        )

        self.assertIsNotNone(self.chaining)

        assert self.chaining is not None

        resp = await self.chaining.aresponse("This is a test message.")  # type: ignore

        print(resp)

        self.assertTrue(resp)

    async def test_chaining_with_params_history(self):
        """Test Chaining"""

        self.appconfig = AppConfig.load_config("./.config/app_testing_config.toml")

        # The Appconfig to use Azure

        self.appconfig._inferencing_model_hosted = Hosted.AZURE
        self.appconfig._embedding_model_hosted = Hosted.LOCAL
        self.appconfig._azure_ai_config.azure_ai_inf_model_type = InfModelType.LLM

        self.inferencing = AppInferencing(appconfig=self.appconfig)
        self.database = AppDatabase(appconfig=self.appconfig)

        self.llm_chat_storage_config = RunnableConfig(
            {"configurable": {"thread_id": "test_thread_id"}}
        )

        test_thread_id = "test_thread_id"
        test_session_id = "test_session_id"

        self.chaining = (
            LLMChain(
                session_id=test_session_id,
                thread_id=test_thread_id,
                appconfig=self.appconfig,
            )
            .with_llm(self.inferencing.get_llm())
            .with_document_retriever(self.database.as_retriever(2))
            .build()
        )

        self.assertIsNotNone(self.chaining)

        assert self.chaining is not None

        resp = self.chaining.aresponse("This is a test message.")  # type: ignore

        print(resp)

        self.assertTrue(resp)
