import uuid
import unittest
from typing import Any
from api.models import UserQuery
from utils.app_config import AppConfig
from abstraction.chaining import LLMChain
from abstraction.database import AppDatabase
from abstraction.inferencing import AppInferencing
from langchain.agents import tool
from abstraction.chat_completion import (
    ChatCompletionLangGraph,
    ChatCompletionToolCall,
    ChatCompletionWithRetriver,
)


class TestChatCompletion(unittest.IsolatedAsyncioTestCase):
    """Test Chat Completion works"""

    def setUp(self):
        """Setup Test Chat Completion"""

        self.appconfig = AppConfig.load_config("./.config/app_testing_config.toml")

        self.app_inferencing = AppInferencing(self.appconfig)

        self.database = AppDatabase(self.appconfig)

        self.session_id = self.thread_id = uuid.uuid4().hex

        self.test_user_query = UserQuery(
            query="Testing Query",
            knowledge_base="Testing Knowledge Base",
            session_id="Testing Session ID",
            thread_id="Testing Thread ID",
        )

        @tool
        def test_tool1() -> bool:
            """Test Tool 1"""
            return True

        self.test_tool1 = test_tool1

    async def test_chat_completion(self) -> None:
        """Test Chat Completion"""

        self.chat_completion = (
            LLMChain(self.session_id, self.thread_id, self.appconfig)
            .with_llm(self.app_inferencing.get_llm())
            .with_document_retriever(self.database.as_retriever(5))
            .build()
        )

        assert self.chat_completion is not None

        self.assertTrue(isinstance(self.chat_completion, ChatCompletionWithRetriver))
        self.assertFalse(isinstance(self.chat_completion, ChatCompletionLangGraph))
        self.assertFalse(isinstance(self.chat_completion, ChatCompletionToolCall))

    async def test_chat_completion_with_tool(self):
        """Test Chat Completion with Tool"""
        self.chat_completion = (
            LLMChain(self.session_id, self.thread_id, self.appconfig)
            .with_llm(self.app_inferencing.get_llm())
            .with_tools([self.test_tool1])
            .build()
        )

        assert self.chat_completion is not None

        self.assertFalse(isinstance(self.chat_completion, ChatCompletionWithRetriver))
        self.assertTrue(isinstance(self.chat_completion, ChatCompletionLangGraph))
        self.assertFalse(isinstance(self.chat_completion, ChatCompletionToolCall))

    async def test_chat_completion_with_tool_streaming(self):
        """Test Chat Completion with Tool and Streaming"""

        async def test_function_call_handler(_: Any) -> Any:
            """Test Function call handle, Not an actual Implemenation"""
            return True

        self.chat_completion = (
            LLMChain(self.session_id, self.thread_id, self.appconfig)
            .with_llm(self.app_inferencing.get_llm())
            .with_tools([self.test_tool1])
            .with_function_call_handler(test_function_call_handler)
            .with_stream_output(True)
            .build()
        )

        assert self.chat_completion is not None

        self.assertFalse(isinstance(self.chat_completion, ChatCompletionWithRetriver))
        self.assertFalse(isinstance(self.chat_completion, ChatCompletionLangGraph))
        self.assertTrue(isinstance(self.chat_completion, ChatCompletionToolCall))
