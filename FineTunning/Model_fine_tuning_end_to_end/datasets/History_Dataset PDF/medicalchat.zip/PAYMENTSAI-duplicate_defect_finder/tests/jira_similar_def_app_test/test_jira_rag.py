from jira_similar_def_app.jira_tools import (
    fetch_specific_field_from_defect,
    fetch_defect_from_jira,
    fetch_similar_defects,
)
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.chains.retrieval import create_retrieval_chain
from langchain_core.prompts import ChatPromptTemplate
from jira_similar_def_app.jira_db import JiraDatabase
from langgraph.checkpoint.memory import MemorySaver
from langchain_core.runnables import RunnableConfig
from abstraction.inferencing import AppInferencing
from langgraph.prebuilt import create_react_agent
from langchain_core.messages import HumanMessage
from abstraction.chaining import LLMChain
from utils.app_config import AppConfig
import unittest
import uuid
import os


class TestJiraRAG(unittest.IsolatedAsyncioTestCase):

    def setUp(self) -> None:
        """Setup for Test Jira RAG"""

        self.appconfig = AppConfig.load_config(
            os.path.abspath("./.config/app_config.toml")
        )

        self.app_inf = AppInferencing(self.appconfig)
        self.jira_db = JiraDatabase(self.appconfig)

        self.session_id = self.thread_id = uuid.uuid4().hex

        self.query = "List defects where Buttons not available"

    async def test_jira_rag(self) -> None:
        """Test Jira RAG"""

        document_chain = create_stuff_documents_chain(
            llm=self.app_inf.get_llm(),
            prompt=ChatPromptTemplate.from_messages(
                [
                    "system",
                    f"""You're a helpful AI Assistant. \
                    Answer the question using the context below. \
                    {{context}}\n\n \
                    {{input}}
                    """,
                ]
            ),
        )

        retriver_chain = create_retrieval_chain(
            self.jira_db.as_retriever(), document_chain
        )

        llm_response = await retriver_chain.ainvoke({"input": self.query})

        self.assertTrue(llm_response)

        self.assertTrue("answer" in llm_response)
        self.assertTrue("context" in llm_response)
        self.assertTrue("input" in llm_response)

        print(llm_response)

    async def test_jira_rag_llm_chain(self) -> None:
        """Test Jira RAG Using LLMChain"""

        llm_chain = (
            LLMChain(self.session_id, self.thread_id, self.appconfig)
            .with_llm(self.app_inf.get_llm())
            .with_document_retriever(self.jira_db.as_retriever())
            .build()
        )

        assert llm_chain is not None

        llm_response = await llm_chain.aresponse(self.query)

        self.assertTrue(llm_response)

        print(llm_response)


class TestJiraSimilarRAGWithTools(unittest.IsolatedAsyncioTestCase):

    def setUp(self) -> None:
        """Setup for Test Jira Similar RAG With Tools"""

        self.appconfig = AppConfig.load_config(
            os.path.abspath("./.config/app_config.toml")
        )
        self.app_inf = AppInferencing(self.appconfig)
        self.session_id = self.thread_id = uuid.uuid4().hex

        self.llm_chain = (
            LLMChain(self.session_id, self.thread_id, self.appconfig)
            .with_llm(self.app_inf.get_llm())
            .with_tools(
                [
                    fetch_specific_field_from_defect,
                    fetch_defect_from_jira,
                    fetch_similar_defects,
                ]
            )
            .build()
        )

    async def test_jira_similar_rag_with_tools2(self):
        """Test Jira Similar RAG With Tools using ChainLagin bind_tools"""

        query = "What is the status of defect GPP-152627"

        from typing import List
        from collections import defaultdict

        llm = self.app_inf.get_llm()

        tools = [
            fetch_specific_field_from_defect,
            fetch_defect_from_jira,
            fetch_similar_defects,
        ]

        llm_with_tool = llm.bind_tools(tools)

        tools_to_call = []
        tool_call_args: dict[str, str] = defaultdict(str)

        from langchain_core.messages import AIMessageChunk

        async for chunk in llm_with_tool.astream([HumanMessage(content=query)]):

            if chunk.additional_kwargs:
                if "tool_calls" in chunk.additional_kwargs:
                    toolcall_args = chunk.additional_kwargs["tool_calls"]

                    for toolcall_arg in toolcall_args:
                        if toolcall_arg["id"]:
                            tools_to_call.append(toolcall_arg["function"]["name"])
                        else:
                            tool_call_args[tools_to_call[-1]] += toolcall_arg[
                                "function"
                            ]["arguments"]

        for tool in tools_to_call:
            self.assertTrue(tool)
            print(f"Call Tool: {tool}")
            print(f"With Args: ", tool_call_args[tool])

    async def test_jira_similar_rag_with_tools(self):

        query = "What is the status of defect GPP-152627"

        llm = self.app_inf.get_llm()

        memory = MemorySaver()

        agent_exector = create_react_agent(
            llm,
            [
                fetch_specific_field_from_defect,
                fetch_defect_from_jira,
                fetch_similar_defects,
            ],
            checkpointer=memory,
        )

        config: RunnableConfig = {"configurable": {"thread_id": "abc123"}}

        async for chunk in agent_exector.astream(
            {"messages": [HumanMessage(content=query)]},
            config,
        ):
            if "agent" in chunk:
                if "messages" in chunk["agent"]:
                    for message in chunk["agent"]["messages"]:
                        print(message.content, end="")

            print("")

    async def test_jira_similar_rag_with_tool_chain(self):
        """Test Jira Similar Defect RAG with Tool Chain"""

        appconfig = AppConfig.load_config("./.config/app_config.toml")

        jira_db = JiraDatabase(appconfig)

        query = "List defects where UI button is not working."

        result = await jira_db.afind_similar_defect(query, 5, None)

        print(result)

        assert self.llm_chain is not None

        resp = await self.llm_chain.aresponse(query)

        print(resp)

    async def test_jira_similar_rag_with_tool_chain_and_history(self):
        """Test Jira Similar Defect RAG with Tool Chain"""

        jira_db = JiraDatabase(self.appconfig)

        query = "List defects where UI button is not working."

        result = await jira_db.afind_similar_defect(query, 5, None)

        print(result)

        assert self.llm_chain is not None

        resp = await self.llm_chain.aresponse(query)

        self.assertTrue(resp)

        print(f"First Response: {resp}")

        query = "What is the status of first defect?"

        resp = await self.llm_chain.aresponse(query)

        print(f"Subsequence Response: {resp}")
