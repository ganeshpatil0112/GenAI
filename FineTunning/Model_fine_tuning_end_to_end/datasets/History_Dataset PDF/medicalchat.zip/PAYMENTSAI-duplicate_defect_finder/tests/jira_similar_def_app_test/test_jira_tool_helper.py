from jira_similar_def_app.github_helper import (
    fetch_pull_request_details,
    search_for_pull_request_by_defect_id,
    fetch_pull_request_code_changes,
)
from jira_similar_def_app.jira_app_constants import (
    GITHUB_REPO_NAME,
    GITHUB_REPO_OWNER,
)
from jira_similar_def_app.jira_api_helper import (
    upload_jira_bulk_issues,
    upload_jira_bulk_data,
    fetch_jira_bulk_data,
)
from jira_similar_def_app.jira_tool_helper import (
    get_issue_from_jira,
    get_jira_field_value,
)
from jira_similar_def_app.api_model import JiraAPIBulkIssues
from jira_similar_def_app.jira_db import JiraDatabase
from jira_similar_def_app.models import JiraFields
from utils.app_config import AppConfig
import unittest


TEST_JQL_QUERY = (
    "project = GPD AND issuetype = Defect AND status = Closed ORDER BY created DESC"
)

TEST_GPP = "GPD-188555"

GITHUB_TEST_GPD = "GPD-206113"

GITHUB_TEST_PR_NUMBER = "6"


class TestJiraBulkIssues(unittest.IsolatedAsyncioTestCase):

    async def test_fetch_jira_bulk_issues(self):
        """Test Fetch Jira Bulk Issues"""

        jira_bulk_issues = [
            defect
            async for defect in fetch_jira_bulk_data(
                TEST_JQL_QUERY,
                False,
            )
        ]

        self.assertTrue(jira_bulk_issues)

    async def test_upload_jira_bulk_issues(self):
        """Test Upload Jira Bulk Issues"""

        self.appconfig = AppConfig.load_config("./.config/app_testing_config.toml")

        jira_bulk_issues = []

        async for defect in fetch_jira_bulk_data(
            TEST_JQL_QUERY,
            False,
        ):
            jira_bulk_issues.extend(defect)

        self.assertTrue(jira_bulk_issues)

        defect_id1 = jira_bulk_issues[0].defect_id
        defect_id2 = jira_bulk_issues[1].defect_id

        self.assertTrue(defect_id1)
        self.assertTrue(defect_id2)

        # Only upload first 2 defects
        result = await upload_jira_bulk_issues(jira_bulk_issues[:2], self.appconfig)

        self.assertTrue(result)

        jira_db = JiraDatabase(self.appconfig)

        jira_data = await jira_db.get_defect_by_field_value("defect_id", defect_id1)
        jira_data2 = await jira_db.get_defect_by_field_value("defect_id", defect_id2)

        self.assertTrue(jira_data)
        self.assertTrue(jira_data2)

        assert jira_data["metadatas"] is not None

        assert jira_data2["metadatas"] is not None

        self.assertTrue(
            defect_id1 in [data["defect_id"] for data in jira_data["metadatas"]]
        )

        self.assertTrue(
            defect_id2 in [data["defect_id"] for data in jira_data2["metadatas"]]
        )

        await jira_db.delete_jira_data_by_field_value("defect_id", defect_id1)
        await jira_db.delete_jira_data_by_field_value("defect_id", defect_id2)

    async def test_upload_jira_bulk_data(self):
        """Test Upload Jira Bulk Data"""

        sample_defect_id1 = "GPD-10001"
        sample_defect_id2 = "GPD-10002"

        jira_sample_bulk_data = JiraAPIBulkIssues(
            expand="schema,names",
            startAt=0,
            maxResults=50,
            total=50,
            issues=[
                {
                    "expand": "operations,versionedRepresentations,editmeta,changelog,renderedFields",
                    "id": f"{sample_defect_id1}",
                    "self": f"https://jira.com/rest/api/2/issue/{sample_defect_id1}",
                    "key": f"{sample_defect_id1}",
                    "fields": {
                        "summary": "Test Summary",
                        "status": {
                            "name": "Closed",
                        },
                        "issuetype": "Defect",
                        "created": "2021-01-01T00:00:00.000+0000",
                        "updated": "2021-01-01T00:00:00.000+0000",
                        "project": "GPD",
                    },
                },
                {
                    "expand": "operations,versionedRepresentations,editmeta,changelog,renderedFields",
                    "id": f"{sample_defect_id2}",
                    "self": f"https://jira.com/rest/api/2/issue/{sample_defect_id2}",
                    "key": f"{sample_defect_id2}",
                    "fields": {
                        "summary": "Test Summary",
                        "status": {
                            "name": "Open",
                        },
                        "issuetype": "Defect",
                        "created": "2021-01-01T00:00:00.000+0000",
                        "updated": "2021-01-01T00:00:00.000+0000",
                        "project": "GPD",
                    },
                },
            ],
        )

        result = await upload_jira_bulk_data(jira_sample_bulk_data)

        self.assertTrue(result)

        jira_db = JiraDatabase(AppConfig().load_config())

        jira_data = await jira_db.get_defect_by_field_value(
            "defect_id", sample_defect_id1
        )

        self.assertTrue(jira_data)

        assert jira_data["metadatas"] is not None

        self.assertTrue(
            sample_defect_id1 in [data["defect_id"] for data in jira_data["metadatas"]]
        )

        self.assertFalse(
            sample_defect_id2 in [data["defect_id"] for data in jira_data["metadatas"]]
        )

        await jira_db.delete_jira_data_by_field_value("defect_id", sample_defect_id1)
        await jira_db.delete_jira_data_by_field_value("defect_id", sample_defect_id2)

    async def test_jira_fetch_specific_field(self):
        """Jira Fetch Specific Fields from Jira"""

        jira_data = await get_issue_from_jira(TEST_GPP)

        assert jira_data is not None

        jira_field_status = await get_jira_field_value(
            TEST_GPP, JiraFields.STATUS.value
        )
        jira_field_priority = await get_jira_field_value(
            TEST_GPP, JiraFields.PRIORITY.value
        )

        self.assertTrue(jira_field_status)
        self.assertTrue(jira_field_priority)

        self.assertTrue(jira_field_status == jira_data.status)
        self.assertTrue(jira_field_priority == jira_data.priority)

    async def test_github_search_pull_request(self):
        """Test Github Search Pull Request"""

        pull_requests = await search_for_pull_request_by_defect_id(
            GITHUB_REPO_OWNER, GITHUB_REPO_NAME, GITHUB_TEST_GPD
        )

        assert pull_requests is not None

        self.assertTrue(pull_requests)

        self.assertEqual(pull_requests.total_count, 1)

        self.assertTrue(pull_requests.items)

        self.assertTrue(pull_requests.items[0].title.__contains__(GITHUB_TEST_GPD))

    async def test_github_file_requests_changes(self):
        """Test Github File Requests Changes"""

        pull_requests = await fetch_pull_request_code_changes(
            GITHUB_REPO_OWNER, GITHUB_REPO_NAME, "6"
        )

        assert pull_requests is not None

        first_pr = pull_requests[0]

        self.assertTrue(first_pr)
        self.assertTrue(first_pr.filename)
        self.assertTrue(first_pr.additions)
        self.assertTrue(first_pr.deletions)
        self.assertTrue(first_pr.changes)
        self.assertTrue(first_pr.status)
        self.assertTrue(first_pr.patch)

    async def test_github_pull_request(self):
        """Test Github Pull Request"""

        pull_requests = await fetch_pull_request_details(
            GITHUB_REPO_OWNER, GITHUB_REPO_NAME, GITHUB_TEST_PR_NUMBER
        )

        assert pull_requests is not None

        self.assertTrue(pull_requests)

        self.assertEqual(pull_requests.number, int(GITHUB_TEST_PR_NUMBER))
