from jira_similar_def_app.models import (
    Components,
    DefectClassfication,
    DefectOrigin,
    JiraModel,
    LinkedIssue,
    RootCause,
    Severity,
    UserComment,
    Status,
)
from jira_similar_def_app.jira_db import JiraDatabase
from utils.app_config import AppConfig
import tracemalloc
import unittest


class TestJiraDatabase(unittest.IsolatedAsyncioTestCase):
    """Test Jira Database"""

    def setUp(self) -> None:
        """Setup Jira Database Test"""

        self.appconfig = AppConfig.load_config("./.config/app_testing_config.toml")

        self.jira_db = JiraDatabase(self.appconfig)

        self.jira_model = JiraModel()

        self.jira_model.defect_id = "TEST-DEFECT-ID"
        self.jira_model.summary = "Test Summary"
        self.jira_model.description = "Test Description"
        self.jira_model.status = Status.CLOSED
        self.jira_model.priority = "Test Priority"
        self.jira_model.resolution = "Test Resolution"
        self.jira_model.created_date = JiraModel.get_date_from_datetime(
            "2024-12-20T13:40:49.515+0000"
        )
        self.jira_model.updated_date = JiraModel.get_date_from_datetime(
            "2024-12-20T13:40:49.515+0000"
        )
        self.jira_model.closed_date = JiraModel.get_date_from_datetime(
            "2024-12-20T13:40:49.515+0000"
        )
        self.jira_model.components = f"{Components.AI}, {Components.CORE}"
        self.jira_model.affected_versions = ["Test AF 1", "Test AF 2"]
        self.jira_model.fix_versions = "Test FV 1, Test FV 2"
        self.jira_model.linked_issues = LinkedIssue(
            inwards=["TEST-1", "TEST-2"], outwards=["TEST-3", "TEST-4"]
        )
        self.jira_model.environment = "TEST-ENV"
        self.jira_model.description = "TEST-DESC"
        self.jira_model.labels = ", ".join(["TEST-LABEL-1", "TEST-LABEL-2"])
        self.jira_model.sprint = "TEST-SPRINT"
        self.jira_model.project_type = "TEST-PROJECT-TYPE"
        self.jira_model.project_key = "TEST-PROJECT-KEY"
        self.jira_model.suspected_nfr_date = JiraModel.get_date_from_datetime(
            "2024-12-20T13:40:49.515+0000"
        )
        self.jira_model.defect_origin = DefectOrigin.DEVELOPER.to_string()
        self.jira_model.confirmed_date = JiraModel.get_date_from_datetime(
            "2024-12-20T13:40:49.515+0000"
        )
        self.jira_model.reopen_date = JiraModel.get_date_from_datetime(
            "2024-12-20T13:40:49.515+0000"
        )
        self.jira_model.root_cause = RootCause.BUILD
        self.jira_model.defect_classification = DefectClassfication.NONE
        self.jira_model.resolution_details = "TEST-RESOLUTION-DETAILS"
        self.jira_model.scenario = "TEST-SCENARIO"
        self.jira_model.acceptance = "TEST-ACCEPTANCE"
        self.jira_model.root_cause_analysis = "TEST-ROOT-CAUSE-ANALYSIS"
        self.jira_model.root_cause_analysis_details = "TEST-ROOT-CAUSE-ANALYSIS-DETAILS"
        self.jira_model.severity = Severity.MEDIUM
        self.jira_model.closed_date = JiraModel.get_date_from_datetime(
            "2024-12-20T13:40:49.515+0000"
        )
        self.jira_model.replication_steps = "TEST-REPLICATION-STEPS"
        self.jira_model.comments = [
            UserComment(
                user_comment="TEST-USER-COMMENT-1",
                author="TEST-USER-NAME-1",
            ),
            UserComment(
                user_comment="TEST-USER-COMMENT-2",
                author="TEST-USER-NAME-2",
            ),
        ]

        return super().setUp()

    async def test_insert_into_jira_db(self):
        """Test insert into Jira database"""

        await self.jira_db.add_jira_data([self.jira_model.as_document()])

        jira_tickets = await self.jira_db.get_defect_by_field_value(
            "defect_id", self.jira_model.defect_id
        )

        self.assertTrue(jira_tickets["metadatas"])

        assert jira_tickets["metadatas"] is not None

        self.assertEqual(
            jira_tickets["metadatas"][0].get("defect_id"), self.jira_model.defect_id
        )

        assert jira_tickets["ids"] is not None

        if type(jira_tickets["ids"]) == list:
            await self.jira_db.delete_jira_data_by_ids(jira_tickets["ids"])
        if type(jira_tickets["ids"]) == str:
            await self.jira_db.delete_jira_data_by_ids([jira_tickets["ids"]])

    async def test_invalid_delete_jira_data_by_ids(self):
        """Test invalid delete Jira data by IDs"""

        self.assertFalse(await self.jira_db.delete_jira_data_by_ids(["INVALID-ID"]))

    async def test_db_response_into_jira_model(self):
        """Test Jira Database Response into Jira Model"""

        await self.jira_db.add_jira_data([self.jira_model.as_document()])

        jira_tickets = await self.jira_db.get_defect_by_field_value(
            "defect_id", self.jira_model.defect_id
        )

        jira_models = JiraModel.from_jira_db_response(jira_tickets)

        self.assertTrue(jira_models)

        first_result = jira_models[0]

        self.assertEqual(first_result.defect_id, self.jira_model.defect_id)
        self.assertEqual(first_result.summary, self.jira_model.summary)
        self.assertEqual(first_result.description, self.jira_model.description)
        self.assertEqual(first_result.status, self.jira_model.status)
        self.assertEqual(first_result.priority, self.jira_model.priority)
        self.assertEqual(first_result.resolution, self.jira_model.resolution)
        self.assertEqual(first_result.created_date, self.jira_model.created_date)
        self.assertEqual(first_result.updated_date, self.jira_model.updated_date)
        self.assertEqual(first_result.closed_date, self.jira_model.closed_date)
        self.assertEqual(first_result.components, self.jira_model.components)
        self.assertEqual(
            first_result.affected_versions, self.jira_model.affected_versions
        )
        self.assertEqual(first_result.fix_versions, self.jira_model.fix_versions)
        self.assertEqual(first_result.linked_issues, self.jira_model.linked_issues)
        self.assertEqual(first_result.environment, self.jira_model.environment)
        self.assertEqual(first_result.description, self.jira_model.description)
        self.assertEqual(first_result.labels, self.jira_model.labels)
        self.assertEqual(first_result.sprint, self.jira_model.sprint)
        self.assertEqual(first_result.project_type, self.jira_model.project_type)
        self.assertEqual(first_result.project_key, self.jira_model.project_key)
        self.assertEqual(
            first_result.suspected_nfr_date, self.jira_model.suspected_nfr_date
        )
        self.assertEqual(first_result.defect_origin, self.jira_model.defect_origin)
        self.assertEqual(first_result.confirmed_date, self.jira_model.confirmed_date)

        assert jira_tickets["ids"] is not None

        if type(jira_tickets["ids"]) == list:
            await self.jira_db.delete_jira_data_by_ids(jira_tickets["ids"])
        if type(jira_tickets["ids"]) == str:
            await self.jira_db.delete_jira_data_by_ids([jira_tickets["ids"]])

    async def test_jira_db_similarity_search(self):
        """Test Jira Database Similarity Search"""

        await self.jira_db.add_jira_data([self.jira_model.as_document()])

        previous_defect_id = self.jira_model.defect_id

        jira_model2 = self.jira_model
        jira_model2.defect_id = "TEST-DEFECT-ID-2"
        jira_model2.summary = "Test Summary 2"
        jira_model2.description = "Test Description 2"

        search_results = await self.jira_db.afind_similar_defect(
            "Test Description", 10, None
        )

        self.assertTrue(search_results)

        for search_result in search_results:
            self.assertTrue(search_result)

            self.assertTrue(search_result[0].page_content)
            self.assertTrue(search_result[1])

            self.assertTrue(
                search_result[0].metadata.get("defect_id")
                in [res[0].metadata.get("defect_id") for res in search_results]
            )

            tracemalloc.start()

            # Delete the inserted data
            await self.jira_db.delete_jira_data_by_field_value(
                "defect_id",
                search_result[0].metadata.get("defect_id") or "",
            )

            tracemalloc.stop()

    async def test_jira_filter_by_date(self):
        """Test Jira Filter by Date"""

        app_config = AppConfig.load_config("./.config/app_config.toml")

        jira_db = JiraDatabase(app_config)

        db_client = jira_db.db.db_client

        res = await db_client.db_client.get(  # type: ignore
            where_document={"metadata_field": {"gte": "01-07-2024"}}  # type: ignore
        )  # type: ignore

        print(res)
