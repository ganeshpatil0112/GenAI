import json
import unittest
from jira_similar_def_app import jira_tool_helper

TEST_DEFECT_ID = "GPD-196567"


class TestJiraAPI(unittest.IsolatedAsyncioTestCase):
    """Test Jira API works"""

    async def test_get_jira_issue(self):
        """Test Jira Issue is fetched from Jira API"""

        defect_ids = [TEST_DEFECT_ID, "GPD-196567", "GPD-167385"]

        for defect_id in defect_ids:
            with self.subTest(defect_id=defect_id):
                str_response = await jira_tool_helper._get_issue_from_jira(defect_id)

                assert str_response is not None

                fetched_defect_id = str_response["key"]

                self.assertEqual(fetched_defect_id, defect_id)

                self.assertIsNotNone(str_response)

    async def test_get_jira_issue_invalid(self):
        """Test Jira Issue is not fetched from Jira API"""

        str_response = await jira_tool_helper._get_issue_from_jira(
            "TEST_INVALID_DEFECT_ID"
        )

        assert str_response is not None

        self.assertEqual(str_response["errorMessages"], ["Issue Does Not Exist"])

        self.assertTrue(
            json.dumps(str_response).find("errorMessages") != -1,
        )

    async def test_get_jira_jiramodel_ref(self):
        """Test Jira Issue is fetched from Jira API and converted to Jira Model"""

        jira_model = await jira_tool_helper.get_issue_from_jira(TEST_DEFECT_ID)

        self.assertIsNotNone(jira_model)

        assert jira_model is not None

        self.assertEqual(jira_model.defect_id, TEST_DEFECT_ID)

        jira_context = jira_model.as_reference()

        self.assertIsNotNone(jira_context)

        self.assertEqual(str(jira_context["source"]["defect_id"]), TEST_DEFECT_ID)
        self.assertEqual(
            str(jira_context["source"]["url"]),
            f"https://jira.finastra.com/browse/{TEST_DEFECT_ID}",
        )

    async def test_jira_response_into_jira_model(self):
        """Test Jira Issue is converted to Jira Model"""

        test_defect_ids = [TEST_DEFECT_ID, "GPD-196567", "GPD-167385"]

        for defect_id in test_defect_ids:
            with self.subTest(defect_id=defect_id):
                jira_model = await jira_tool_helper.get_issue_from_jira(defect_id)

                self.assertIsNotNone(jira_model)

                assert jira_model is not None

                self.assertEqual(jira_model.defect_id, defect_id)
