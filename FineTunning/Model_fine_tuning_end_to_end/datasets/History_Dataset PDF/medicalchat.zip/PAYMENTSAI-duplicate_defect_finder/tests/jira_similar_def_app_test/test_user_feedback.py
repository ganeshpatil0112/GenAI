import json
import asyncio
import unittest
from jira_similar_def_app.models import UserFeedBack, ChatHistory
from jira_similar_def_app.user_feedback import (
    insert_user_feedback,
    update_user_feedback,
    get_feedback_by_id,
    get_all_feedback,
    get_feedback_by_field,
    postgres_connect,
)


class TestUserFeedback(unittest.IsolatedAsyncioTestCase):
    """Test User Feedback"""

    def setUp(self):
        """Set Up"""

        self.test_mail = "test_email"

        self.chat_history = [
            ChatHistory(
                type="ai",
                content="test_content_1",
            ),
            ChatHistory(
                type="human",
                content="test_content_2",
            ),
        ]

        self.feedback = UserFeedBack(
            id=0,
            email=self.test_mail,
            response="test_response",
            feedback="test_feedback",
            impression=False,
            chat_history=self.chat_history,
        )

    async def test_insert_user_feedback(self):
        """Test Insert User Feedback"""

        res = await insert_user_feedback(self.feedback)

        self.assertTrue(res)

    async def test_update_user_feedback(self):
        """Test Update User Feedback"""

        await insert_user_feedback(self.feedback)

        existing_feedback = await get_feedback_by_id(1)

        assert existing_feedback is not None

        existing_feedback.feedback = "test_feedback_updated"  # type: ignore
        existing_feedback.chat_history = existing_feedback.chat_history

        res = await update_user_feedback(existing_feedback)

        self.assertTrue(res)

    async def test_get_all_user_feedback(self):
        """Test Get All User Feedback"""

        response = await get_all_feedback()

        self.assertTrue(response)

    async def cleanUp(self) -> None:
        """Clean Up"""
        pg_connection = await postgres_connect()

        cursor = pg_connection.cursor()

        await cursor.execute(
            "DELETE FROM user_feedback WHERE user_email = %s", (self.test_mail,)
        )

        await pg_connection.commit()

    async def tearDown(self) -> None:

        asyncio.run(self.cleanUp())

        return super().tearDown()
