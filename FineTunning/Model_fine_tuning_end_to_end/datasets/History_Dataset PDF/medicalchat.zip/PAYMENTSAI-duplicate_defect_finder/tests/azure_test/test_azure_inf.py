from abstraction.inferencing import AppInferencing
from utils.app_config import AppConfig, Hosted
import unittest


class TestAzureInferencing(unittest.TestCase):
    """Test Azure Inferencing class"""

    def test_azure_llm_inf_generated(self):
        """Test Azure LLM Inferencing is generated"""

        self.test_app_config = AppConfig.load_config(
            "./.config/app_testing_config.toml"
        )

        self.test_app_config._inferencing_model_hosted = Hosted.AZURE

        self.azure_llm_config = (
            self.test_app_config.get_azure_ai_config().get_azure_ai_config_llm_inf()
        )

        self.assertIsNotNone(self.azure_llm_config)
        azure_inf = AppInferencing(appconfig=self.test_app_config)

        self.assertIsNotNone(azure_inf)

        llm = azure_inf.get_llm()

        llm.invoke("This is test message the LLM Connection is working")
