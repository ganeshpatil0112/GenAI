import unittest

from utils.app_config import AppConfig
from azure.database import AzureDatabase


class TestAzureChromaDB(unittest.IsolatedAsyncioTestCase):
    """Test Azure ChromaDB"""

    @unittest.skip("Not Yet Configured")
    def test_get_chroma_db(self):

        self.test_app_config = AppConfig.load_config(
            "./.config/app_testing_config.toml"
        )

        azure_db = AzureDatabase(self.test_app_config)
        db_client = azure_db.get_db_client()

        self.assertIsNotNone(db_client)
        self.assertEqual(db_client.__class__.__name__, "ChromaDB")
