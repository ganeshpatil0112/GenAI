from abstraction.embedding import AzureEmbeddings
from utils.app_config import AppConfig

import unittest


class TestAzureEmbedding(unittest.IsolatedAsyncioTestCase):

    def test_azure_embedding(self):
        """Test Azure Embedding"""

        self.appconfig = AppConfig.load_config("./.config/app_testing_config.toml")

        self.embedding = AzureEmbeddings(appconfig=self.appconfig)

        self.assertIsNotNone(self.embedding)

        assert self.embedding is not None

        resp = self.embedding.embed_documents(["This is a test message."])

        self.assertTrue(resp)
