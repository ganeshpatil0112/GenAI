import unittest
from utils.app_config import AppConfig, DatabaseProvider, LogLevel, Hosted


class TestAppConfig(unittest.TestCase):
    def test_app_config(self):
        """Test if the configs are getting saved to loaded from the file"""

        appconfig = AppConfig()

        test_config_path = "./.config/test_config.toml"

        appconfig.save_config(test_config_path)

        appconfig.load_config(test_config_path)

    def test_app_config_with_parameters(self):
        """
        Test if the configs are getting saved to loaded from the file with
        specified values.
        """

        test_config_path = "./.config/test_config.toml"

        appconfig = AppConfig()

        # App Settings
        appconfig._app_settings._log_level = LogLevel.DEBUG
        appconfig._app_settings._log_path = "test.log"

        appconfig._inferencing_model_hosted = Hosted.LOCAL
        appconfig._embedding_model_hosted = Hosted.LOCAL

        # Local Embedding Config

        appconfig._local_embedding_config.model_provider = "test_local_prov"
        appconfig._local_embedding_config.model = "test_local_model"
        appconfig._local_embedding_config.dimension = 1024

        # Local Inferencing Config

        appconfig._local_inferencing_config.model_provider = "test_local_prov"
        appconfig._local_inferencing_config.model = "test_local_model"
        appconfig._local_inferencing_config.max_tokens = 100
        appconfig._local_inferencing_config.temperature = 0.2
        appconfig._local_inferencing_config.top_k = 50
        appconfig._local_inferencing_config.repeat_penalty = 1.5
        appconfig._local_inferencing_config.seed = 12345
        appconfig._local_inferencing_config.start_sequence = "<|START|>"
        appconfig._local_inferencing_config.stop_sequence = "<|END|>"

        # Azure Config

        # Azure Embeddings Config
        appconfig._azure_ai_config._azure_ai_config_embedding.api_version = "testv"
        appconfig._azure_ai_config._azure_ai_config_embedding.resource_name = "test_res"
        appconfig._azure_ai_config._azure_ai_config_embedding.model_provider = (
            "test_prov"
        )
        appconfig._azure_ai_config._azure_ai_config_embedding.deployment_id = (
            "test_dep_id"
        )
        appconfig._azure_ai_config._azure_ai_config_embedding.embedding_model = (
            "test_embm"
        )
        appconfig._azure_ai_config._azure_ai_config_embedding.dimension = 1024

        # Azure LLM Config

        appconfig._azure_ai_config._azure_ai_config_inf_llm.api_version = "testv"
        appconfig._azure_ai_config._azure_ai_config_inf_llm.model_provider = "testp"
        appconfig._azure_ai_config._azure_ai_config_inf_llm.resource_name = "test_res"
        appconfig._azure_ai_config._azure_ai_config_inf_llm.deployment_id = (
            "test_dep_id"
        )
        appconfig._azure_ai_config._azure_ai_config_inf_llm.inference_model = (
            "test_infm"
        )
        appconfig._azure_ai_config._azure_ai_config_inf_llm.max_tokens = 100
        appconfig._azure_ai_config._azure_ai_config_inf_llm.temperature = 0.2
        appconfig._azure_ai_config._azure_ai_config_inf_llm.top_k = 50
        appconfig._azure_ai_config._azure_ai_config_inf_llm.repeat_penalty = 1.5
        appconfig._azure_ai_config._azure_ai_config_inf_llm.seed = 12345

        # Azure SLM Config

        appconfig._azure_ai_config._azure_ai_config_inf_slm.model_provider = (
            "huggingface"
        )
        appconfig._azure_ai_config._azure_ai_config_inf_slm.resource_name = "test_res"
        appconfig._azure_ai_config._azure_ai_config_inf_slm.completion_url = "com_url"
        appconfig._azure_ai_config._azure_ai_config_inf_slm.max_tokens = 4096
        appconfig._azure_ai_config._azure_ai_config_inf_slm.temperature = 0.6
        appconfig._azure_ai_config._azure_ai_config_inf_slm.top_k = 10
        appconfig._azure_ai_config._azure_ai_config_inf_slm.repeat_penalty = 0.3
        appconfig._azure_ai_config._azure_ai_config_inf_slm.seed = 12354

        # Database Config

        appconfig._database_config.database_provider = DatabaseProvider.CHROMA
        appconfig._database_config.postgresdb_config.database_host = "test_host"
        appconfig._database_config.postgresdb_config.collection_name = "test_col"
        appconfig._database_config.postgresdb_config.database_port = 5432
        appconfig._database_config.postgresdb_config.database_name = "test_db"
        appconfig._database_config.postgresdb_config.database_password = "test_pass"
        appconfig._database_config.postgresdb_config.database_user = "test_user"

        appconfig._database_config.chroma_config.collection_name = "test_coll"
        appconfig._database_config.chroma_config.persist_directory = "test_dir"
        appconfig._database_config.chroma_config.host_url = "test_host_url"
        appconfig._database_config.chroma_config.host_port = 12345

        appconfig.save_config(test_config_path)

        appconfig = AppConfig().load_config(test_config_path)

        self.assertEqual(appconfig._inferencing_model_hosted, Hosted.LOCAL)
        self.assertEqual(appconfig._embedding_model_hosted, Hosted.LOCAL)

        self.assertEqual(
            appconfig._local_embedding_config.model_provider, "test_local_prov"
        )
        self.assertEqual(appconfig._local_embedding_config.model, "test_local_model")
        self.assertEqual(appconfig._local_embedding_config.dimension, 1024)

        self.assertEqual(
            appconfig._local_inferencing_config.model_provider, "test_local_prov"
        )
        self.assertEqual(appconfig._local_inferencing_config.model, "test_local_model")
        self.assertEqual(appconfig._local_inferencing_config.max_tokens, 100)
        self.assertEqual(appconfig._local_inferencing_config.temperature, 0.2)
        self.assertEqual(appconfig._local_inferencing_config.top_k, 50)
        self.assertEqual(appconfig._local_inferencing_config.repeat_penalty, 1.5)
        self.assertEqual(appconfig._local_inferencing_config.seed, 12345)
        self.assertEqual(
            appconfig._local_inferencing_config.start_sequence, "<|START|>"
        )
        self.assertEqual(appconfig._local_inferencing_config.stop_sequence, "<|END|>")

        self.assertEqual(appconfig._app_settings._log_level, LogLevel.DEBUG)
        self.assertEqual(appconfig._app_settings._log_path, "test.log")

        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_embedding.api_version, "testv"
        )
        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_embedding.resource_name,
            "test_res",
        )
        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_embedding.model_provider,
            "test_prov",
        )
        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_embedding.deployment_id,
            "test_dep_id",
        )
        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_embedding.embedding_model,
            "test_embm",
        )
        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_embedding.dimension, 1024
        )

        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_inf_llm.api_version, "testv"
        )
        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_inf_llm.model_provider, "testp"
        )
        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_inf_llm.resource_name,
            "test_res",
        )
        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_inf_llm.deployment_id,
            "test_dep_id",
        )
        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_inf_llm.inference_model,
            "test_infm",
        )
        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_inf_llm.max_tokens, 100
        )
        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_inf_llm.temperature, 0.2
        )
        self.assertEqual(appconfig._azure_ai_config._azure_ai_config_inf_llm.top_k, 50)
        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_inf_llm.repeat_penalty, 1.5
        )
        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_inf_llm.seed, 12345
        )

        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_inf_slm.model_provider,
            "huggingface",
        )
        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_inf_slm.resource_name,
            "test_res",
        )
        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_inf_slm.completion_url,
            "com_url",
        )
        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_inf_slm.max_tokens, 4096
        )
        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_inf_slm.temperature, 0.6
        )
        self.assertEqual(appconfig._azure_ai_config._azure_ai_config_inf_slm.top_k, 10)
        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_inf_slm.repeat_penalty, 0.3
        )
        self.assertEqual(
            appconfig._azure_ai_config._azure_ai_config_inf_slm.seed, 12354
        )

        self.assertEqual(
            appconfig._database_config.database_provider, DatabaseProvider.CHROMA
        )
        self.assertEqual(
            appconfig._database_config.postgresdb_config.database_host, "test_host"
        )
        self.assertEqual(
            appconfig._database_config.postgresdb_config.collection_name, "test_col"
        )
        self.assertEqual(
            appconfig._database_config.postgresdb_config.database_port, 5432
        )
        self.assertEqual(
            appconfig._database_config.postgresdb_config.database_name, "test_db"
        )
        self.assertEqual(
            appconfig._database_config.postgresdb_config.database_password, "test_pass"
        )
        self.assertEqual(
            appconfig._database_config.postgresdb_config.database_user, "test_user"
        )

        self.assertEqual(
            appconfig._database_config.chroma_config.collection_name, "test_coll"
        )

        self.assertEqual(
            appconfig._database_config.chroma_config.persist_directory, "test_dir"
        )

        self.assertEqual(
            appconfig._database_config.chroma_config.host_url, "test_host_url"
        )

        self.assertEqual(appconfig._database_config.chroma_config.host_port, 12345)
