from utils.text_cleaning import TextCleaner
import unittest


class TestTextCleaning(unittest.TestCase):
    """Test Text Cleaning"""

    def setUp(self) -> None:

        self.test_text1 = """
        <!DOCTYPE html>
        <html>
        <head>
            <link rel="stylesheet" href="styles.css" />
        </head>
        <body>
            <h1 class="title">Hello World! </h1>
        </body>
        </html>
        """

        self.test_text2 = "Plain Text"

        return super().setUp()

    def test_html2md(self) -> None:
        """Test HTML 2 Markdown"""

        text_cleaner = (
            TextCleaner(self.test_text1)
            .html2markdown()
            .remove_non_utf8_chars()
            .remove_html_code()
            .clean_markdown()
            .get_text()
        )

        self.assertTrue(text_cleaner)

        self.assertEqual(text_cleaner, "# Hello World!")

    def test_text2md(self) -> None:
        """Test Convert plain text to markdown"""

        text_cleaner = (
            TextCleaner(self.test_text2)
            .html2markdown()
            .remove_non_utf8_chars()
            .remove_html_code()
            .clean_markdown()
            .get_text()
        )

        self.assertTrue(text_cleaner)

        self.assertEqual(text_cleaner, self.test_text2)
