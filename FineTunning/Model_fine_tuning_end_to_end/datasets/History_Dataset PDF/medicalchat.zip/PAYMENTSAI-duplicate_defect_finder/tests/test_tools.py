import json
import unittest
from tools.tool_creator import (
    OpenAITools,
    Functions,
    Parameters,
    Properties,
    Property,
)


class TestToolToJson(unittest.TestCase):
    """Test Tool to JSON"""

    def test_tool_created(self):
        tool = (
            OpenAITools()
            .with_type("function")
            .with_function(
                Functions()
                .with_name("test")
                .with_description("test")
                .with_parameters(
                    Parameters()
                    .with_param_type("object")
                    .with_properties(
                        Properties().add_property(
                            Property("name", "test", "property description")
                        )
                    )
                )
            )
            .build()
        )

        expected = """{
            "type": "function",
            "function": {
                "name": "test",
                "description": "test",
                "parameters": {
                "type": "object",
                "properties": {
                    "name": {
                    "type": "test",
                    "description": "property description"
                    }
                },
                "required": [
                    "name"
                ]
                }
            }
            }"""

        self.assertEqual(
            json.dumps(tool, indent=2), json.dumps(json.loads(expected), indent=2)
        )

    def test_tool_created_not_required(self):
        tool = (
            OpenAITools()
            .with_type("function")
            .with_function(
                Functions()
                .with_name("test")
                .with_description("test")
                .with_parameters(
                    Parameters()
                    .with_param_type("object")
                    .with_properties(
                        Properties().add_property(
                            Property(
                                "name", "test", "property description", required=False
                            )
                        )
                    )
                )
            )
            .build()
        )

        expected = """{
            "type": "function",
            "function": {
                "name": "test",
                "description": "test",
                "parameters": {
                "type": "object",
                "properties": {
                    "name": {
                    "type": "test",
                    "description": "property description"
                    }
                }
                }
            }
            }"""

        self.assertEqual(
            json.dumps(tool, indent=2), json.dumps(json.loads(expected), indent=2)
        )


if __name__ == "__main__":
    unittest.main()
