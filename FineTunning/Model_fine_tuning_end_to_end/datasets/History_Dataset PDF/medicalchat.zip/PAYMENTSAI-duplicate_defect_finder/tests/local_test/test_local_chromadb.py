import unittest
from local.chroma_db import ChromaDB
from abstraction.database import AppDatabase
from langchain_core.documents import Document
from abstraction.embedding import AppEmbedding
from langchain_core.embeddings import FakeEmbeddings
from utils.app_config import AppConfig, Hosted, DatabaseProvider


class ChromaDBTest(unittest.IsolatedAsyncioTestCase):
    """Test ChromaDB works"""

    async def test_insert_embedded_document(self) -> None:

        self.test_app_config = AppConfig.load_config(
            "./.config/app_testing_config.toml"
        )

        self.test_chroma_store = ChromaDB(appconfig=self.test_app_config)

        self.test_app_config.get_database_config().database_hosted = Hosted.LOCAL

        self.db_client = self.test_chroma_store.get_client()

        self.assertTrue(self.db_client)

    async def test_insert_into_chroma_db(self) -> None:
        """Test inserting a document into chromadb"""

        self.test_app_config = AppConfig.load_config(
            "./.config/app_testing_config.toml"
        )

        self.test_app_config.get_database_config().database_hosted = Hosted.LOCAL
        self.test_app_config.get_database_config().database_provider = (
            DatabaseProvider.CHROMA
        )

        # Create a ChromaDB instance

        self.test_chroma_store = AppDatabase(appconfig=self.test_app_config)

        self.assertTrue(self.test_chroma_store)

        # Insert a document
        test_document = Document(
            "test_document", metadata={"source": "https://example.com"}
        )

        added_ids = await self.test_chroma_store.aadd_documents([test_document])

        # Check if the document was inserted
        search_results = await self.test_chroma_store.asimilarity_search_documents(
            "test_document", 1, None
        )

        self.assertTrue(search_results)

        # Delete the test document

        await self.test_chroma_store.adelete_document_by_id(added_ids)

        self.test_chroma_store.aget_client().close()

    async def test_insert_and_retrieve_document_chroma_db(self) -> None:
        """Test inserting a document into chromadb and retrieving it"""

        self.test_app_config = AppConfig.load_config(
            "./.config/app_testing_config.toml"
        )

        self.test_app_config.get_database_config().database_hosted = Hosted.LOCAL
        self.test_app_config.get_database_config().database_provider = (
            DatabaseProvider.CHROMA
        )

        # Create a ChromaDB instance
        self.test_chroma_store = AppDatabase(appconfig=self.test_app_config)

        test_documents = [
            Document(
                "test_document",
                metadata={"content_id": "content_1", "source": "https://example.com"},
                embeddings=FakeEmbeddings(size=1024),
            ),
            Document(
                "test_document2",
                metadata={"content_id": "content_2", "source": "https://example.com"},
                embeddings=FakeEmbeddings(size=1024),
            ),
        ]

        await self.test_chroma_store.aadd_documents(test_documents)

        # Get the document with content_id = content_1

        result = await self.test_chroma_store.aget_document_by_field(
            "content_id",
            "content_1",
        )

        self.assertTrue(len(result), "Document Retrieved")

        # Get the document metadata with content_id = content_1

        result2 = await self.test_chroma_store.aget_document_metadata_by_field(
            "content_id", "content_1"
        )

        self.assertTrue(len(result2), "Document Metadata Retrieved")

        self.assertEqual(
            result2[0]["content_id"], "content_1", "Document Metadata Matched"
        )

        # Get the document id so that it can be deleted

        await self.test_chroma_store.adelete_document_by_field(
            "content_id", "content_1"
        )

        await self.test_chroma_store.adelete_document_by_field(
            "content_id", "content_2"
        )

    async def test_similarity_search_chroma_db(self):
        """Test if similarity search works with embeddings"""

        self.test_app_config = AppConfig.load_config(
            "./.config/app_testing_config.toml"
        )

        self.test_app_config.get_database_config().database_hosted = Hosted.LOCAL
        self.test_app_config.get_database_config().database_provider = (
            DatabaseProvider.CHROMA
        )

        # Create a ChromaDB instance
        self.test_chroma_store = AppDatabase(appconfig=self.test_app_config)

        app_embedding = AppEmbedding(appconfig=self.test_app_config)

        page_content = "This is the test document"

        test_documents = [
            Document(
                page_content=page_content,
                metadata={"content_id": "content_1", "source": "https://example.com"},
            ),
        ]

        await self.test_chroma_store.aadd_documents(test_documents)

        generated_embedding = await app_embedding.aembed_query(
            "This is the test document"
        )

        # Search for the document
        search_results = await self.test_chroma_store.asearch_document_with_embeddings(
            query=generated_embedding or [], limit=1
        )

        self.assertTrue(search_results, "Search Results Found")

        self.assertEqual(
            search_results[0].page_content,
            "This is the test document",
            "Document Retrieved",
        )
