import unittest
from utils.app_config import AppConfig, Hosted
from abstraction.embedding import AppEmbedding


class TestEmbeddingGenerated(unittest.TestCase):
    """Test Local Embedding Generated"""

    def test_embedding_generated_ollama(self):

        test_app_config = AppConfig.load_config("./.config/app_testing_config.toml")

        self.assertEqual(test_app_config._embedding_model_hosted, Hosted.LOCAL)
        self.assertEqual(
            test_app_config.get_local_embedding_config().model_provider, "ollama"
        )

        app_embedding = AppEmbedding(test_app_config)

        generated_embedding = app_embedding.embed_documents(
            ["hello world", "goodbye world"]
        )

        self.assertTrue(generated_embedding is not None)
