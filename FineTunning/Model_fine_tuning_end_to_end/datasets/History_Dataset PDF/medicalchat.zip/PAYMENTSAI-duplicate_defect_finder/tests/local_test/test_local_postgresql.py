import unittest
from sys import platform
from utils.app_config import AppConfig, DatabaseProvider, Hosted
from abstraction.database import AppDatabase
from langchain_core.documents import Document


class TestLocalPostgreSQLDB(unittest.IsolatedAsyncioTestCase):
    """Test PostgreSQL database"""

    @unittest.skipIf(
        platform.startswith("win"), "Postgresql Async testing not supported on Windows"
    )
    async def test_pg_insert(self):

        test_app_config = AppConfig.load_config("./.config/app_testing_config.toml")

        test_app_config.get_database_config().database_hosted = Hosted.LOCAL
        test_app_config.get_database_config().database_provider = (
            DatabaseProvider.POSTGRESQL
        )

        self.assertEqual(
            test_app_config.get_database_config().database_hosted, Hosted.LOCAL
        )

        self.assertEqual(
            test_app_config.get_database_config().database_provider,
            DatabaseProvider.POSTGRESQL,
        )

        db = AppDatabase(test_app_config)

        test_documents = [
            Document(
                page_content="This is a test document",
                metadata={"source": "https://example.com"},
            )
        ]

        await db.aadd_documents(test_documents)

        search_results = await db.asimilarity_search_documents(
            "This is a test document", 10, None
        )

        self.assertEqual(len(search_results), 1)

        print(search_results)

        self.assertEqual(search_results[0][0].page_content, "This is a test document")

        self.assertEqual(search_results[0][0].metadata["source"], "https://example.com")

        db.aget_client().close()
