from abstraction.inferencing import LocalInferencing
from utils.app_config import AppConfig, Hosted
import unittest


class TestLocalInferencing(unittest.TestCase):

    def test_local_inferencing_generated(self):
        """Test Local Inferencing Generated"""

        self.test_app_config = AppConfig.load_config(
            "./.config/app_testing_config.toml"
        )

        self.test_app_config._inferencing_model_hosted = Hosted.LOCAL
        self.assertEqual(
            self.test_app_config.get_inferencing_model_hosted(), Hosted.LOCAL
        )

        self.test_local_inferencing = LocalInferencing(appconfig=self.test_app_config)
        resp = self.test_local_inferencing.get_llm().invoke("Hi")

        self.assertIsNotNone(resp)
