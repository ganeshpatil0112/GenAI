import time

from prometheus_client import Counter, Histogram
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Message, Request
from starlette.responses import Response


# Count of HTTP requests
REQUEST_COUNT = Counter(
    "http_requests_total", "Total HTTP requests", ["method", "endpoint", "http_status"]
)

# Histogram for request duration
REQUEST_LATENCY = Histogram(
    "http_request_duration_seconds",
    "HTTP request latency in seconds",
    ["method", "endpoint"],
)

# Histogram for response size
RESPONSE_SIZE = Histogram(
    "http_response_size_bytes",
    "Size of HTTP responses in bytes",
    ["method", "endpoint", "http_status"],
)

class MetricsMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        method = request.method
        endpoint = request.url.path

        start_time = time.time()
        response = await call_next(request)
        process_time = time.time() - start_time

        status_code = response.status_code

        # Track request count and latency
        REQUEST_COUNT.labels(method=method, endpoint=endpoint, http_status=status_code).inc()
        REQUEST_LATENCY.labels(method=method, endpoint=endpoint).observe(process_time)

        # Measure response size
        if hasattr(response, "body_iterator"):
            body = b""
            async for chunk in response.body_iterator: # type: ignore
                body += chunk
            RESPONSE_SIZE.labels(method=method, endpoint=endpoint, http_status=status_code).observe(len(body))
            # Re-create the response with the original body
            new_response = Response(
                content=body,
                status_code=response.status_code,
                headers=response.headers,
                media_type=response.media_type
            )
            return new_response
        else:
            # For responses with .body attribute (non-streaming)
            body = getattr(response, "body", b"")
            RESPONSE_SIZE.labels(method=method, endpoint=endpoint, http_status=status_code).observe(len(body))
            return response
