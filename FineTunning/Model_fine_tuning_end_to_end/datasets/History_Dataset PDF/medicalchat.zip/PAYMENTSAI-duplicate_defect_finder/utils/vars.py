"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-07
Description: Contains the environment variables used in the application
"""

import os
import logging
from typing import Optional
from pathlib import Path

INFERENCING_MODEL_PATH: str = "PHI2_QUANTIZED_PATH"
EMBEDDING_MODEL_PATH: str = "GTE_PATH"
NEXTGENAI_DB_URL: str = "NEXTGENAI_DB_URL"
AZURE_OPENAI_KEY: str = "AZURE_OPENAI_KEY"
AZURE_EMBEDDING_KEY: str = "AZURE_EMBEDDING_KEY"
JIRA_USERNAME: str = "USERNAME"
JIRA_API_KEY: str = "JIRA_API_KEY"
GITHUB_API_KEY: str = "GITHUB_API_KEY"
AZURE_OPENAI_KEY2: str = "AZURE_OPENAI_KEY2"
AZURE_SLM_API_KEY: str = "AZURE_SLM_API_KEY"
AZURE_DEVOPS_API_KEY: str = "AZURE_DEVOPS_API_KEY"
APP_CONFIG_SAVE_PATH: str = "APP_CONFIG_SAVE_PATH"
USER_FEEDBACK_PG_URL: str = "USER_FEEDBACK_PG_URL"


def get_app_config_save_path() -> str:
    """Get the path to save the application configuration
    - The path is stored in the environment variable `APP_CONFIG_SAVE_PATH`
    ### Returns
    - `str`: The path to save the application configuration
    """

    logging.log(
        logging.INFO,
        f"Getting application configuration save path from environment variable {APP_CONFIG_SAVE_PATH}",
    )

    path_res: Optional[str] = os.getenv(APP_CONFIG_SAVE_PATH)
    if path_res is None:
        # Check if ./config/app_config.toml exists
        if Path("./.config/app_config.toml").exists():
            logging.log(
                logging.INFO,
                f"Default application configuration save path: ./config/app_config.toml",
            )
            return "./.config/app_config.toml"

        logging.log(
            logging.ERROR,
            f"{APP_CONFIG_SAVE_PATH} not set in environment variables",
        )
        raise EnvironmentError(
            f"{APP_CONFIG_SAVE_PATH} not set in environment variables"
        )
    logging.log(logging.DEBUG, f"Application configuration save path: {path_res}")
    return path_res


def get_inferencing_model_path() -> Path:
    """Get the path to the local inferencing model
    - The path is stored in the environment variable `PHI2_QUANTIZED_PATH`
    ### Returns
    - `Path`: The path to the inferencing model
    """

    logging.log(
        logging.INFO,
        f"Getting inferencing model path from environment variable {INFERENCING_MODEL_PATH}",
    )

    path_res: Optional[str] = os.getenv(INFERENCING_MODEL_PATH)
    if path_res is None:
        logging.log(
            logging.ERROR,
            f"{INFERENCING_MODEL_PATH} not set in environment variables",
        )
        raise EnvironmentError(
            f"{INFERENCING_MODEL_PATH} not set in environment variables"
        )
    logging.log(logging.DEBUG, f"Inferencing model path: {path_res}")
    return Path(path_res)


def get_embedding_model_path() -> Path:
    """Get the path to the local embedding model
    - The path is stored in the environment variable `GTE_PATH`
    ### Returns
    - `Path`: The path to the embedding model
    """

    logging.log(
        logging.INFO,
        f"Getting embedding model path from environment variable {EMBEDDING_MODEL_PATH}",
    )

    path_res: Optional[str] = os.getenv(EMBEDDING_MODEL_PATH)
    if path_res is None:
        logging.log(
            logging.ERROR,
            f"{EMBEDDING_MODEL_PATH} not set in environment variables",
        )
        raise EnvironmentError(
            f"{EMBEDDING_MODEL_PATH} not set in environment variables"
        )

    logging.log(logging.DEBUG, f"Embedding model path: {path_res}")
    return Path(path_res)


def get_pg_url() -> str:
    """Get the PostgreSQL database URL
    - The URL is stored in the environment variable `NEXTGENAI_DB_URL`
    ### Returns
    - `str`: The PostgreSQL database URL
    """

    logging.log(
        logging.INFO,
        f"Getting PostgreSQL URL from environment variable {NEXTGENAI_DB_URL}",
    )

    connection_url: Optional[str] = os.getenv(NEXTGENAI_DB_URL)
    if connection_url is None:
        logging.log(
            logging.ERROR,
            f"{NEXTGENAI_DB_URL} not set in environment variables",
        )
        raise EnvironmentError(f"{NEXTGENAI_DB_URL} not set in environment variables")
    logging.log(logging.DEBUG, f"PostgreSQL URL: {connection_url}")
    return connection_url


def get_azure_openai_api_key() -> str:
    """Get the Azure OpenAI API key
    - The key is stored in the environment variable `AZURE_OPENAI_KEY`
    ### Returns
    - `str`: The Azure OpenAI API key
    """

    logging.log(
        logging.INFO,
        f"Getting Azure OpenAI API key from environment variable {AZURE_OPENAI_KEY}",
    )

    res: Optional[str] = os.getenv(AZURE_OPENAI_KEY)
    if res is None:
        logging.log(
            logging.ERROR,
            f"{AZURE_OPENAI_KEY} not set in environment variables",
        )
        raise EnvironmentError(f"{AZURE_OPENAI_KEY} not set in environment variables")
    logging.log(logging.DEBUG, f"Azure OpenAI API key: {res}")
    return res


def get_azureai_slm_api_key() -> str:
    """Get the Azure SLM API key
    - The key is stored in the environment variable `AZURE_SLM_API_KEY`
    ### Returns
    - `str`: The Azure SLM API key
    """

    logging.log(
        logging.INFO,
        f"Getting Azure SLM API key from environment variable {AZURE_SLM_API_KEY}",
    )

    res: Optional[str] = os.getenv(AZURE_SLM_API_KEY)
    if res is None:
        logging.log(
            logging.ERROR,
            f"{AZURE_SLM_API_KEY} not set in environment variables",
        )
        raise EnvironmentError(f"{AZURE_SLM_API_KEY} not set in environment variables")
    logging.log(logging.DEBUG, f"Azure SLM API key: {res}")
    return res


def get_embedding_api_key_old() -> str:
    """Get the old embedding API key
    - The key is stored in the environment variable `AZURE_OPENAI_KEY2`
    ### Returns
    - `str`: The old embedding API key
    """

    logging.log(
        logging.INFO,
        f"Getting old embedding API key from environment variable {AZURE_OPENAI_KEY2}",
    )

    res: Optional[str] = os.getenv(AZURE_OPENAI_KEY2)
    if res is None:
        logging.log(
            logging.ERROR,
            f"{AZURE_OPENAI_KEY2} not set in environment variables",
        )
        raise EnvironmentError(f"{AZURE_OPENAI_KEY2} not set in environment variables")
    logging.log(logging.DEBUG, f"Old embedding API key: {res}")
    return res


def get_embedding_api_key() -> str:
    """Get the embedding API key
    - The key is stored in the environment variable `AZURE_EMBEDDING_KEY`
    ### Returns
    - `str`: The embedding API key
    """

    logging.log(
        logging.INFO,
        f"Getting embedding API key from environment variable {AZURE_EMBEDDING_KEY}",
    )

    res: Optional[str] = os.getenv(AZURE_EMBEDDING_KEY)
    if res is None:
        logging.log(
            logging.ERROR,
            f"{AZURE_EMBEDDING_KEY} not set in environment variables",
        )
        raise EnvironmentError(
            f"{AZURE_EMBEDDING_KEY} not set in environment variables"
        )
    logging.log(logging.DEBUG, f"Embedding API key: {res}")
    return res


def get_jira_username() -> str:
    """Get the JIRA username
    - The username is stored in the environment variable `USERNAME`
    ### Returns
    - `str`: The JIRA username
    """

    logging.log(
        logging.INFO,
        f"Getting JIRA username from environment variable {JIRA_USERNAME}",
    )

    val: Optional[str] = os.getenv(JIRA_USERNAME)
    if val is None:
        logging.log(
            logging.ERROR,
            f"{JIRA_USERNAME} not found in environment variables",
        )
        raise EnvironmentError(f"{JIRA_USERNAME} not found")
    logging.log(logging.DEBUG, f"JIRA username: {val}")
    return val


def get_jira_api_key() -> str:
    """Get the JIRA API key
    - The key is stored in the environment variable `JIRA_API_KEY`
    ### Returns
    - `str`: The JIRA API key
    """

    logging.log(
        logging.INFO,
        f"Getting JIRA API key from environment variable {JIRA_API_KEY}",
    )

    val: Optional[str] = os.getenv(JIRA_API_KEY)
    if val is None:
        logging.log(
            logging.ERROR,
            f"{JIRA_API_KEY} not found in environment variables",
        )
        raise EnvironmentError(f"{JIRA_API_KEY} not found")
    logging.log(logging.DEBUG, f"JIRA API key: {val}")
    return val


def get_github_api_key() -> str:
    """Get the GitHub API key
    - The key is stored in the environment variable `GITHUB_API_KEY`
    ### Returns
    - `str`: The GitHub API key
    """

    logging.log(
        logging.INFO,
        f"Getting GitHub API key from environment variable {GITHUB_API_KEY}",
    )

    val: Optional[str] = os.getenv(GITHUB_API_KEY)
    if val is None:
        logging.log(
            logging.ERROR,
            f"{GITHUB_API_KEY} not found in environment variables",
        )
        raise EnvironmentError(f"{GITHUB_API_KEY} not found")
    logging.log(logging.DEBUG, f"GitHub API key: {val}")
    return val


def get_azure_devops_api_key() -> str:
    """Get the Azure DevOps API key
    - The key is stored in the environment variable `AZURE_DEVOPS_API_KEY`
    ### Returns
    - `str`: The Azure DevOps API key
    """

    logging.log(
        logging.INFO,
        f"Getting Azure DevOps API key from environment variable {AZURE_DEVOPS_API_KEY}",
    )

    val: Optional[str] = os.getenv(AZURE_DEVOPS_API_KEY)
    if val is None:
        logging.log(
            logging.ERROR,
            f"{AZURE_DEVOPS_API_KEY} not found in environment variables",
        )
        raise EnvironmentError(f"{AZURE_DEVOPS_API_KEY} not found")
    logging.log(logging.DEBUG, f"Azure DevOps API key: {val}")
    return val


def get_user_feedback_pg_url() -> str:

    logging.log(
        logging.INFO,
        f"Getting User Feedback PostgreSQL URL from environment variable {USER_FEEDBACK_PG_URL}",
    )

    connection_url: Optional[str] = os.getenv(USER_FEEDBACK_PG_URL)
    if connection_url is None:
        logging.log(
            logging.ERROR,
            f"{USER_FEEDBACK_PG_URL} not set in environment variables",
        )
        raise EnvironmentError(
            f"{USER_FEEDBACK_PG_URL} not set in environment variables"
        )
    logging.log(logging.DEBUG, f"User Feedback PostgreSQL URL: {connection_url}")
    return connection_url
