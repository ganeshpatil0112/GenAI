"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-12-04
Description: Application Wide Constants
"""

EMPTY_LINE = ""
SINGLE_SPACE = " "
NEW_LINE = "\n"

# utils.app_cleaning.py
HTML_CODE_REPLACE_REGEX = r"&[a-zA-Z]+;"
HTML_CODE_REPLACE_MULTI_NEWLINE_REGEX = r"\n+\s*"

# abstraction/chat_completion.py
DEFAULT_TOKEN_LIMIT = 4096
