"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-01
Description: Global Application Configuration
"""

from typing import Optional
from pathlib import Path
from .vars import get_app_config_save_path
from urllib.parse import quote_plus as urlquote
from enum import Enum
import tomllib
import logging
import tomli_w
import os


class LogLevel(Enum):
    """Define Log Level"""

    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"

    def __str__(self) -> str:
        """Return string representation of LogLevel"""

        return super().__str__()

    def get_log_level(self) -> int:
        """Return log level as integer"""

        match self:
            case LogLevel.DEBUG:
                return logging.DEBUG
            case LogLevel.INFO:
                return logging.INFO
            case LogLevel.WARNING:
                return logging.WARNING
            case LogLevel.ERROR:
                return logging.ERROR
            case LogLevel.CRITICAL:
                return logging.CRITICAL

    @staticmethod
    def from_str(log_level: str) -> "LogLevel":
        """Return LogLevel from string
        ### Parameters
        - `log_level`: str - Log Level
        ### Returns
        - `LogLevel`: Log Level Enum
        """

        match log_level:
            case "LogLevel.DEBUG":
                return LogLevel.DEBUG
            case "LogLevel.INFO":
                return LogLevel.INFO
            case "LogLevel.WARNING":
                return LogLevel.WARNING
            case "LogLevel.ERROR":
                return LogLevel.ERROR
            case "LogLevel.CRITICAL":
                return LogLevel.CRITICAL
            case _:
                return LogLevel.INFO


class Hosted(Enum):
    """Define Hosted Model"""

    AZURE = "azure"
    LOCAL = "local"

    def __str__(self) -> str:
        """Return string representation of Hosted"""

        return super().__str__()

    def __dict__(self) -> dict:
        """Return dictionary representation of Hosted"""

        return {"model_hosted": super().__str__()}

    @staticmethod
    def from_str(model_provider: str) -> "Hosted":
        """Return Hosted from string
        ### Parameters
        - `model_provider`: str - Model Provider
        ### Returns
        - `Hosted`: Hosted Enum
        """

        match model_provider:
            case "Hosted.AZURE":
                return Hosted.AZURE
            case "Hosted.LOCAL":
                return Hosted.LOCAL
            case _:
                return Hosted.LOCAL


class DatabaseProvider(Enum):
    """Define Database Provider"""

    POSTGRESQL = "postgresql"
    CHROMA = "chroma"

    def __str__(self) -> str:
        """Return string representation of DatabaseProvider"""

        return super().__str__()

    def __dict__(self) -> dict:
        """Return dictionary representation of DatabaseProvider"""

        return {"database_provider": super().__str__()}

    @staticmethod
    def from_str(database_provider: str) -> "DatabaseProvider":
        """Return DatabaseProvider from string
        ### Parameters
        - `database_provider`: str - Database Provider
        ### Returns
        - `DatabaseProvider`: Database Provider Enum
        """

        match database_provider:
            case "DatabaseProvider.POSTGRESQL":
                return DatabaseProvider.POSTGRESQL
            case "DatabaseProvider.CHROMA":
                return DatabaseProvider.CHROMA
            case _:
                return DatabaseProvider.POSTGRESQL


class InfModelType(Enum):
    """Inferencing Model Type"""

    SLM = "SLM"
    LLM = "LLM"

    def __str__(self) -> str:
        """Return string representation of InfModelType"""

        return super().__str__()

    def __dict__(self) -> dict:
        """Return dictionary representation of InfModelType"""

        return {"model_type": super().__str__()}

    @staticmethod
    def from_str(model_type: str) -> "InfModelType":
        """Return InfModelType from string
        ### Parameters
        - `model_type`: str - Model Type
        ### Returns
        - `InfModelType`: Inferencing Model Type Enum
        """

        match model_type:
            case "InfModelType.SLM":
                return InfModelType.SLM
            case "InfModelType.LLM":
                return InfModelType.LLM
            case _:
                return InfModelType.SLM


class AzureEmbeddingConfig:
    """Azure Embedding Configuration"""

    def __init__(self) -> None:
        """Initialize Azure Embedding Configuration"""

        self.model_provider = "azure"
        self.resource_name: str = "resource_name"
        self.api_version: str = "api_version"
        self.deployment_id: str = "deployment_id"
        self.embedding_model: str = "embedding_model"
        self.dimension: Optional[int] = None


class AzureInfSLMConfig:
    """Azure Inferencing SLM Configuration"""

    def __init__(self) -> None:
        """Initialize Azure Inferencing SLM Configuration"""

        self.model_provider = "microsoft"
        self.resource_name: str = "resource_name"
        self.completion_url: str = "models.ai.azure.com/v1/chat/completions"
        self.temperature: float = 0
        self.max_tokens: int = 2048
        self.top_k: int = 10
        self.repeat_penalty: float = 1.0
        self.seed: int = 12345

    def get_completion_url(self) -> str:
        """Return completion url
        ### Returns
        - `str`: Completion URL
        """

        return urlquote(f"https://{self.resource_name}/{self.completion_url}".strip())


class AzureInfLLMConfig:
    """Azure Inferencing LLM Configuration"""

    def __init__(self) -> None:
        """Initialize Azure Inferencing LLM Configuration"""

        self.model_provider = "azure"
        self.resource_name: str = "resource_name"
        self.api_version: str = "api_version"
        self.deployment_id: str = "deployment_id"
        self.inference_model: str = "inference_model"
        self.temperature: float = 0
        self.max_tokens: int = 2048
        self.top_k: int = 10
        self.repeat_penalty: float = 1.0
        self.seed: int = 12345


class AzureAIConfig:
    """Azure AI Configuration"""

    def __init__(self) -> None:
        """Initialize Azure AI Configuration"""

        self._azure_ai_config_embedding = AzureEmbeddingConfig()
        self.azure_ai_inf_model_type = InfModelType.LLM
        self._azure_ai_config_inf_slm = AzureInfSLMConfig()
        self._azure_ai_config_inf_llm = AzureInfLLMConfig()

    def get_azure_ai_config_embedding(self) -> AzureEmbeddingConfig:
        """Return Azure Embedding Configuration
        ### Returns
        - `AzureEmbeddingConfig`: Azure Embedding Configuration
        """

        return self._azure_ai_config_embedding

    def get_azure_ai_config_slm_inf(self) -> AzureInfSLMConfig:
        """Return Azure SLM Inferencing Configuration
        ### Returns
        - `AzureInfSLMConfig`: Azure SLM Inferencing Configuration
        """

        return self._azure_ai_config_inf_slm

    def get_azure_ai_config_llm_inf(self) -> AzureInfLLMConfig:
        """Return Azure LLM Inferencing Configuration
        ### Returns
        - `AzureInfLLMConfig`: Azure LLM Inferencing Configuration
        """

        return self._azure_ai_config_inf_llm


class AppSettings:
    """Application Settings"""

    def __init__(self) -> None:
        """Initialize Application Settings"""

        self._app_name = "FinChat AI"
        self._log_path = ".logs"
        self._log_level: LogLevel = LogLevel.ERROR

    def _get_log_path(self) -> Optional[Path]:
        """Return log path
        ### Returns
        - `Optional[Path]`: Log Path
        """

        if os.path.exists(self._log_path):
            return Path(self._log_path)

        return None

    def get_log_file_path(self) -> Optional[Path]:
        """Return log file path
        ### Returns
        - `Optional[Path]`: Log File Path
        """

        if self._get_log_path() is not None:
            return self._get_log_path().joinpath("main.log")  # type: ignore

        return None

    def get_log_level(self):
        """Return log level
        ### Returns
        - `int`: Log Level
        """

        return self._log_level.get_log_level()


class LocalEmbeddingConfig:
    """Local Embedding Configuration"""

    def __init__(self) -> None:
        """Initialize Local Embedding Configuration"""

        self.model_provider = "ollama"
        self.model: str = "mxbai-embed-large"
        self.dimension: Optional[int] = None


class LocalInferencingConfig:
    """Local Inferencing Configuration"""

    def __init__(self) -> None:
        """Initialize Local Inferencing Configuration"""

        self.model_provider = "ollama"
        self.model: str = "dolphin-phi"
        self.temperature: float = 0
        self.max_tokens: int = 2048
        self.top_k: int = 10
        self.repeat_penalty: float = 1.0
        self.seed: int = 12345
        self.start_sequence: str = "<|im_start|>"
        self.stop_sequence: str = "<|im_end|>"


class ChromaDBConfig:
    """Chroma Database Configuration"""

    def __init__(self) -> None:
        """Initialize Chroma Database Configuration"""

        self.collection_name: str = "jira"
        self.persist_directory: str = ".db"
        self.host_url: str = "localhost"
        self.host_port: int = 8000


class PostgresqlDBConfig:
    """PostgreSQL Database Configuration"""

    def __init__(self) -> None:
        """Initialize PostgreSQL Database Configuration"""

        self.database_name = "database_name"
        self.database_user = "database_user"
        self.database_password = "database_password"
        self.database_host = "database_host"
        self.collection_name = "documents"
        self.database_port = 123


class DatabaseConfig:
    """Database Configuration"""

    def __init__(self) -> None:
        """Initialize Database Configuration"""

        self.database_hosted = Hosted.LOCAL
        self.database_provider = DatabaseProvider.POSTGRESQL
        self.postgresdb_config = PostgresqlDBConfig()
        self.chroma_config = ChromaDBConfig()

    def set_chroma_collection_name(self, collection_name: str) -> None:
        self.chroma_config.collection_name = collection_name

    def set_chroma_persist_directory(self, persist_directory: str) -> None:
        self.chroma_config.persist_directory = persist_directory

    def set_postgresql_collection_name(self, collection_name: str) -> None:
        self.postgresdb_config.collection_name = collection_name

    def set_postgresql_database_name(self, database_name: str) -> None:
        self.postgresdb_config.database_name = database_name


class AppConfig:
    """Global Application Configuration"""

    def __init__(self) -> None:
        """Initialize Application Configuration"""

        self._app_settings = AppSettings()
        self._embedding_model_hosted = Hosted.AZURE
        self._inferencing_model_hosted = Hosted.AZURE
        self._local_embedding_config = LocalEmbeddingConfig()
        self._local_inferencing_config = LocalInferencingConfig()
        self._database_config = DatabaseConfig()
        self._azure_ai_config = AzureAIConfig()

    def get_app_settings(self) -> AppSettings:
        """Return Application Settings
        ### Returns
        - `AppSettings`: Application Settings
        """

        return self._app_settings

    def get_azure_ai_config(self) -> AzureAIConfig:
        """Return Azure AI Configuration
        ### Returns
        - `AzureAIConfig`: Azure AI Configuration
        """

        return self._azure_ai_config

    def get_embedding_model_hosted(self) -> Hosted:
        """Return Embedding Model Hosted
        ### Returns
        - `Hosted`: Embedding Model Hosted (Azure or Local)
        """

        return self._embedding_model_hosted

    def get_inferencing_model_hosted(self) -> Hosted:
        """Return Inferencing Model Hosted
        ### Returns
        - `Hosted`: Inferencing Model Hosted (Azure or Local)
        """

        return self._inferencing_model_hosted

    def get_local_embedding_config(self) -> LocalEmbeddingConfig:
        """Return Local Embedding Model Configuration
        ### Returns
        - `LocalEmbeddingConfig`: Local Embedding Configuration
        """

        return self._local_embedding_config

    def get_local_inferencing_config(self) -> LocalInferencingConfig:
        """Return Local Inferencing Model Configuration
        ### Returns
        - `LocalInferencingConfig`: Local Inferencing Configuration
        """

        return self._local_inferencing_config

    def get_database_config(self) -> DatabaseConfig:
        """Return Database Configuration
        ### Returns
        - `DatabaseConfig`: Database Configuration
        """

        return self._database_config

    def save_config(self, config_path=get_app_config_save_path()):
        """Save Configuration to File
        ### Parameters
        - `config_path`: str - Configuration Path (Default: APP_CONFIG_SAVE_PATH)
        """

        config_dict = {
            "app_settings": {
                "app_name": self.get_app_settings()._app_name,
                "log_path": self.get_app_settings()._log_path,
                "log_level": str(self.get_app_settings()._log_level),
            },
            "embedding_model_hosted": str(self._embedding_model_hosted),
            "inferencing_model_hosted": str(self._inferencing_model_hosted),
            "local_embedding_config": {
                "model_provider": self._local_embedding_config.model_provider,
                "model": self._local_embedding_config.model,
                "dimension": self._local_embedding_config.dimension
                or -1,  # Set to -1 if None
            },
            "local_inferencing_config": {
                "model_provider": self.get_local_inferencing_config().model_provider,
                "model": self.get_local_inferencing_config().model,
                "temperature": self.get_local_inferencing_config().temperature,
                "max_tokens": self.get_local_inferencing_config().max_tokens,
                "top_p": self.get_local_inferencing_config().top_k,
                "repeat_penalty": self.get_local_inferencing_config().repeat_penalty,
                "seed": self.get_local_inferencing_config().seed,
                "start_sequence": self.get_local_inferencing_config().start_sequence,
                "stop_sequence": self.get_local_inferencing_config().stop_sequence,
            },
            "database_config": {
                "database_provider": str(self.get_database_config().database_provider),
                "postgresql": {
                    "database_name": self.get_database_config().postgresdb_config.database_name,
                    "database_user": self.get_database_config().postgresdb_config.database_user,
                    "database_password": self.get_database_config().postgresdb_config.database_password,
                    "database_host": self.get_database_config().postgresdb_config.database_host,
                    "collection_name": self.get_database_config().postgresdb_config.collection_name,
                    "database_port": self.get_database_config().postgresdb_config.database_port,
                },
                "chroma": {
                    "collection_name": self.get_database_config().chroma_config.collection_name,
                    "persist_directory": self.get_database_config().chroma_config.persist_directory,
                    "host_url": self.get_database_config().chroma_config.host_url,
                    "host_port": self.get_database_config().chroma_config.host_port,
                },
            },
            "azure_config": {
                "embedding": {
                    "model_provider": self.get_azure_ai_config()
                    .get_azure_ai_config_embedding()
                    .model_provider,
                    "resource_name": self.get_azure_ai_config()
                    .get_azure_ai_config_embedding()
                    .resource_name,
                    "api_version": self.get_azure_ai_config()
                    .get_azure_ai_config_embedding()
                    .api_version,
                    "deployment_id": self.get_azure_ai_config()
                    .get_azure_ai_config_embedding()
                    .deployment_id,
                    "embedding_model": self.get_azure_ai_config()
                    .get_azure_ai_config_embedding()
                    .embedding_model,
                    "dimension": self.get_azure_ai_config()
                    .get_azure_ai_config_embedding()
                    .dimension
                    or -1,  # Set to -1 if None
                },
                "inf_model_type": str(
                    self.get_azure_ai_config().azure_ai_inf_model_type
                ),
                "inf_slm": {
                    "model_provider": self.get_azure_ai_config()
                    .get_azure_ai_config_slm_inf()
                    .model_provider,
                    "resource_name": self.get_azure_ai_config()
                    .get_azure_ai_config_slm_inf()
                    .resource_name,
                    "completion_url": self.get_azure_ai_config()
                    .get_azure_ai_config_slm_inf()
                    .completion_url,
                    "temperature": self.get_azure_ai_config()
                    .get_azure_ai_config_slm_inf()
                    .temperature,
                    "max_tokens": self.get_azure_ai_config()
                    .get_azure_ai_config_slm_inf()
                    .max_tokens,
                    "top_k": self.get_azure_ai_config()
                    .get_azure_ai_config_slm_inf()
                    .top_k,
                    "repeat_penalty": self.get_azure_ai_config()
                    .get_azure_ai_config_slm_inf()
                    .repeat_penalty,
                    "seed": self.get_azure_ai_config()
                    .get_azure_ai_config_slm_inf()
                    .seed,
                },
                "inf_llm": {
                    "model_provider": self.get_azure_ai_config()
                    .get_azure_ai_config_llm_inf()
                    .model_provider,
                    "resource_name": self.get_azure_ai_config()
                    .get_azure_ai_config_llm_inf()
                    .resource_name,
                    "api_version": self.get_azure_ai_config()
                    .get_azure_ai_config_llm_inf()
                    .api_version,
                    "deployment_id": self.get_azure_ai_config()
                    .get_azure_ai_config_llm_inf()
                    .deployment_id,
                    "inference_model": self.get_azure_ai_config()
                    .get_azure_ai_config_llm_inf()
                    .inference_model,
                    "temperature": self.get_azure_ai_config()
                    .get_azure_ai_config_llm_inf()
                    .temperature,
                    "max_tokens": self.get_azure_ai_config()
                    .get_azure_ai_config_llm_inf()
                    .max_tokens,
                    "top_k": self.get_azure_ai_config()
                    .get_azure_ai_config_llm_inf()
                    .top_k,
                    "repeat_penalty": self.get_azure_ai_config()
                    .get_azure_ai_config_llm_inf()
                    .repeat_penalty,
                    "seed": self.get_azure_ai_config()
                    .get_azure_ai_config_llm_inf()
                    .seed,
                },
            },
        }

        with open(config_path, "wb") as f:
            tomli_w.dump(config_dict, f)

    @staticmethod
    def load_config(config_path=get_app_config_save_path()) -> "AppConfig":
        """Load Configuration from File
        ### Parameters
        - `config_path`: str - Configuration Path (Default: APP_CONFIG_SAVE_PATH)
        ### Returns
        - `AppConfig`: Application Configuration
        """

        with open(config_path, "rb") as f:
            config_dict = tomllib.load(f)

        app_config = AppConfig()
        app_settings = app_config.get_app_settings()
        azure_config = app_config.get_azure_ai_config()
        local_embedding_config = app_config.get_local_embedding_config()
        local_inferencing_config = app_config.get_local_inferencing_config()
        database_config = app_config.get_database_config()

        app_config._embedding_model_hosted = Hosted.from_str(
            config_dict["embedding_model_hosted"]
        )

        app_config._inferencing_model_hosted = Hosted.from_str(
            config_dict["inferencing_model_hosted"]
        )

        local_embedding_config.model_provider = config_dict["local_embedding_config"][
            "model_provider"
        ]

        local_embedding_config.model = config_dict["local_embedding_config"]["model"]

        local_embedding_config.dimension = (
            config_dict["local_embedding_config"]["dimension"]
            if config_dict["local_embedding_config"]["dimension"] != -1
            else None
        )

        local_inferencing_config.model_provider = config_dict[
            "local_inferencing_config"
        ]["model_provider"]

        local_inferencing_config.model = config_dict["local_inferencing_config"][
            "model"
        ]
        local_inferencing_config.temperature = config_dict["local_inferencing_config"][
            "temperature"
        ]

        local_inferencing_config.max_tokens = config_dict["local_inferencing_config"][
            "max_tokens"
        ]

        local_inferencing_config.top_k = config_dict["local_inferencing_config"][
            "top_p"
        ]

        local_inferencing_config.repeat_penalty = config_dict[
            "local_inferencing_config"
        ]["repeat_penalty"]

        local_inferencing_config.seed = config_dict["local_inferencing_config"]["seed"]
        local_inferencing_config.start_sequence = config_dict[
            "local_inferencing_config"
        ]["start_sequence"]

        local_inferencing_config.stop_sequence = config_dict[
            "local_inferencing_config"
        ]["stop_sequence"]

        database_config.database_provider = DatabaseProvider.from_str(
            config_dict["database_config"]["database_provider"]
        )
        database_config.postgresdb_config.database_name = config_dict[
            "database_config"
        ]["postgresql"]["database_name"]
        database_config.postgresdb_config.database_user = config_dict[
            "database_config"
        ]["postgresql"]["database_user"]
        database_config.postgresdb_config.database_password = config_dict[
            "database_config"
        ]["postgresql"]["database_password"]
        database_config.postgresdb_config.database_host = config_dict[
            "database_config"
        ]["postgresql"]["database_host"]
        database_config.postgresdb_config.collection_name = config_dict[
            "database_config"
        ]["postgresql"]["collection_name"]
        database_config.postgresdb_config.database_port = config_dict[
            "database_config"
        ]["postgresql"]["database_port"]
        database_config.chroma_config.collection_name = config_dict["database_config"][
            "chroma"
        ]["collection_name"]
        database_config.chroma_config.persist_directory = config_dict[
            "database_config"
        ]["chroma"]["persist_directory"]
        database_config.chroma_config.host_url = config_dict["database_config"][
            "chroma"
        ]["host_url"]
        database_config.chroma_config.host_port = config_dict["database_config"][
            "chroma"
        ]["host_port"]

        app_settings._app_name = config_dict["app_settings"]["app_name"]
        app_settings._log_path = config_dict["app_settings"]["log_path"]
        app_settings._log_level = LogLevel.from_str(
            config_dict["app_settings"]["log_level"]
        )
        azure_config.azure_ai_inf_model_type = InfModelType.from_str(
            config_dict["azure_config"]["inf_model_type"]
        )
        embedding_config = azure_config.get_azure_ai_config_embedding()
        embedding_config.model_provider = config_dict["azure_config"]["embedding"][
            "model_provider"
        ]
        embedding_config.resource_name = config_dict["azure_config"]["embedding"][
            "resource_name"
        ]
        embedding_config.api_version = config_dict["azure_config"]["embedding"][
            "api_version"
        ]
        embedding_config.deployment_id = config_dict["azure_config"]["embedding"][
            "deployment_id"
        ]
        embedding_config.embedding_model = config_dict["azure_config"]["embedding"][
            "embedding_model"
        ]

        # If dimension is -1, set it to None
        embedding_config.dimension = (
            config_dict["azure_config"]["embedding"]["dimension"]
            if config_dict["azure_config"]["embedding"]["dimension"] != -1
            else None
        )

        inf_slm_config = azure_config.get_azure_ai_config_slm_inf()
        inf_slm_config.model_provider = config_dict["azure_config"]["inf_slm"][
            "model_provider"
        ]
        inf_slm_config.resource_name = config_dict["azure_config"]["inf_slm"][
            "resource_name"
        ]
        inf_slm_config.completion_url = config_dict["azure_config"]["inf_slm"][
            "completion_url"
        ]
        inf_slm_config.temperature = config_dict["azure_config"]["inf_slm"][
            "temperature"
        ]
        inf_slm_config.max_tokens = config_dict["azure_config"]["inf_slm"]["max_tokens"]
        inf_slm_config.top_k = config_dict["azure_config"]["inf_slm"]["top_k"]
        inf_slm_config.repeat_penalty = config_dict["azure_config"]["inf_slm"][
            "repeat_penalty"
        ]
        inf_slm_config.seed = config_dict["azure_config"]["inf_slm"]["seed"]

        inf_llm_config = azure_config.get_azure_ai_config_llm_inf()
        inf_llm_config.model_provider = config_dict["azure_config"]["inf_llm"][
            "model_provider"
        ]
        inf_llm_config.resource_name = config_dict["azure_config"]["inf_llm"][
            "resource_name"
        ]
        inf_llm_config.api_version = config_dict["azure_config"]["inf_llm"][
            "api_version"
        ]
        inf_llm_config.deployment_id = config_dict["azure_config"]["inf_llm"][
            "deployment_id"
        ]
        inf_llm_config.inference_model = config_dict["azure_config"]["inf_llm"][
            "inference_model"
        ]
        inf_llm_config.temperature = config_dict["azure_config"]["inf_llm"][
            "temperature"
        ]
        inf_llm_config.max_tokens = config_dict["azure_config"]["inf_llm"]["max_tokens"]
        inf_llm_config.top_k = config_dict["azure_config"]["inf_llm"]["top_k"]
        inf_llm_config.repeat_penalty = config_dict["azure_config"]["inf_llm"][
            "repeat_penalty"
        ]
        inf_llm_config.seed = config_dict["azure_config"]["inf_llm"]["seed"]

        return app_config
