"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-12-03
Description: Text Cleaning for HTML and Markdown
"""

from langchain_community.document_transformers import MarkdownifyTransformer
from mdcleaner.cleaner import unidecode, perform_replacements
from langchain_core.documents import Document
from utils.app_constants import (
    HTML_CODE_REPLACE_REGEX,
    HTML_CODE_REPLACE_MULTI_NEWLINE_REGEX,
    SINGLE_SPACE,
    NEW_LINE,
)
from bs4 import BeautifulSoup
import html
import re


class TextCleaner:
    """Text Cleaner with HTML2MD Support, UTF-8 Cleaning, Markdown Cleaning"""

    def __init__(self, text: str):
        self.text = text
        self.mdt = MarkdownifyTransformer()

    def remove_non_utf8_chars(self) -> "TextCleaner":
        """Removes Non UTF-8 Character by ignoring them"""

        self.text = self.text.encode("utf-8", "ignore").decode("utf-8")
        return self

    def remove_html_code(self) -> "TextCleaner":
        """Cleans HTML code UTF Characters like &nbsp; ..."""

        # Replace HTML Unicode characters
        self.text = html.unescape(self.text)

        # Replace special HTML entities like &nbsp;
        self.text = re.sub(HTML_CODE_REPLACE_REGEX, SINGLE_SPACE, self.text)

        # Replace 2+ newlines with a single new line
        self.text = re.sub(HTML_CODE_REPLACE_MULTI_NEWLINE_REGEX, NEW_LINE, self.text)

        return self

    def clean_markdown(self) -> "TextCleaner":
        """Cleans Markdown using mdcleaner"""

        self.text = unidecode(self.text)

        self.text = perform_replacements(self.text)
        return self

    def html2markdown(self) -> "TextCleaner":
        """Converts HTML to Markdown if it's HTML text"""

        converted_docs = self.mdt.transform_documents(
            [Document(page_content=self.text)]
        )

        self.text = "".join([doc.page_content for doc in converted_docs])

        return self

    def html2text(self) -> "TextCleaner":
        """HTML to Plain Text"""

        soup = BeautifulSoup(self.text, "html.parser")
        self.text = soup.get_text()
        return self

    def get_text(self):
        """Returns the text"""
        return self.text
