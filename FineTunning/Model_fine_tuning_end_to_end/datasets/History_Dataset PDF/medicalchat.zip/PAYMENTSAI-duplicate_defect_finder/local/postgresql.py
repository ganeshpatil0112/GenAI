"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-14
Description: PostgreSQL Database Implementation
"""

from typing import List, Tuple, Optional, Dict
from langchain_core.documents import Document
from langchain_postgres import PGVector
from abstraction.embedding import AppEmbedding
from interfaces.database_inter import VectorDatabase
from utils.app_config import AppConfig
import asyncio
import logging


class PostgreSQLDB(VectorDatabase):
    """Local PostgreSQL Database Implementation"""

    def __init__(self, appconfig=AppConfig().load_config()) -> None:
        """Initialize Local PostgreSQLDB
        ### Args:
        - `appconfig`: (AppConfig, optional): AppConfig instance. Defaults to AppConfig().load_config().
        """

        self.logger = logging.getLogger(self.__class__.__name__)

        self.embedding_function = AppEmbedding(appconfig)
        self.appconfig = appconfig
        self.collection_name = (
            appconfig.get_database_config().postgresdb_config.collection_name
        )

        self.logger.log(
            logging.INFO,
            f"Initializing Local PostgreSQLDB",
        )

        self.logger.log(
            logging.DEBUG,
            f"PostgreSQLDB Config: {self.appconfig.get_database_config().postgresdb_config.__dict__}",
        )

        super().__init__(
            db_client=PGVector(
                embeddings=self.embedding_function,
                collection_name=self.collection_name,
                connection=self._get_connection_string(),
                async_mode=True,
                use_jsonb=True,
            )
        )

    async def aadd_documents(self, documents: List[Document]) -> None:
        """Add documents to Local PostgreSQLDB
        ### Args:
        - `documents`: (List[Document]): List of Documents to be added to Local PostgreSQLDB
        """

        self.logger.log(
            logging.INFO,
            f"Adding Documents to Local PostgreSQLDB, documents len: {len(documents)}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Adding Documents to Local PostgreSQLDB, documents: {documents}",
        )

        await super().aadd_documents(documents)

    async def asimilarity_search_with_score(
        self, query: str, limit: int, filters: Optional[Dict[str, str]]
    ) -> List[Tuple[Document, float]]:
        """Search documents in Local PostgreSQLDB
        ### Args:
        - `query`: (str): Query to search in Local PostgreSQLDB
        - `limit`: (int): Limit of search results
        - `filters`: (Optional[Dict[str, str]]): Filters to apply on search results
        ### Returns:
        - `List[Tuple[Document, float]]`: List of search results
        """

        self.logger.log(
            logging.INFO,
            f"Searching Documents in Local PostgreSQLDB, query_len: {len(query)}, \
            limit: {limit}, filters len: {len(filters or [])}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Searching Documents in Local PostgreSQLDB, query: {query}, limit: {limit}, filters: {filters}",
        )

        return await super().asimilarity_search_with_score(query, limit, filters)

    async def aget_document_ids(self, field_name: str, field_value: str) -> List[str]:
        """Get Document IDs with filters from Local ChromaDB
        ### Args:
        - `field_name`: (str): Field Name to search in Local ChromaDB
        - `field_value`: (str): Field Value to search in Local ChromaDB
        ### Returns:
        - `document_id`: List[str] Document Ids if found else None
        """

        self.logger.log(
            logging.INFO,
            f"Searching documents in Local ChromaDB with filters",
        )

        self.logger.log(
            logging.DEBUG,
            f"Get Document with Field_Name: {field_name}, Field_Value: {field_value}",
        )

        results = await self.aget_document_with_filter(field_name, field_value)

        self.logger.log(
            logging.INFO,
            f"Documents found in Local ChromaDB with filters: {len(results)}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Documents found in Local ChromaDB with filters: {results}",
        )

        return results.get("ids") if results else []  # type: ignore

    async def aget_document_metadatas(
        self, field_name: str, field_value: str
    ) -> List[dict]:
        """Get Document Metadata with filters from Local ChromaDB
        ### Args:
        - `field_name`: (str): Field Name to search in Local ChromaDB
        - `field_value`: (str): Field Value to search in Local ChromaDB
        ### Returns:
        - `str | None`: Document Metadata if found else None
        """

        self.logger.log(
            logging.INFO,
            f"Searching documents in Local ChromaDB with filters",
        )

        self.logger.log(
            logging.DEBUG,
            f"Get Document with Field_Name: {field_name}, Field_Value: {field_value}",
        )

        resp = await self.aget_document_with_filter(field_name, field_value)

        if not resp:
            return []

        return resp.get("metadatas")  # type: ignore

    async def adelete_by_field_value(
        self, field_name: str, field_value: str
    ) -> Optional[bool]:
        """Delete Document with filters from Local ChromaDB
        ### Args:
        - `field_name`: (str): Field Name to search in Local ChromaDB
        - `field_value`: (str): Field Value to search in Local ChromaDB
        """

        self.logger.log(
            logging.INFO,
            f"Deleting documents in Local ChromaDB with field_name: {field_name}, field_value: {field_value}",
        )

        ids_to_delete = await self.aget_document_ids(field_name, field_value)

        self.logger.log(
            logging.INFO,
            f"Documents found in Local ChromaDB with filters: {len(ids_to_delete)}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Documents found in Local ChromaDB with filters: {ids_to_delete}",
        )

        return not ids_to_delete or await self.adelete_by_id(ids_to_delete) is not None

    async def aget_field_values(self, field_name: str) -> list[str]:
        """Get Field Values from Local PostgreSQLDB
        ### Args:
        - `field_name`: (str): Field Name to get values from Local PostgreSQLDB
        ### Returns:
        - `list[str]`: List of Field Values
        """

        import asyncpg as pg

        collection_name: str = "langchain_pg_embedding"

        postgresql_config = self.appconfig.get_database_config().postgresdb_config

        con_str = f"postgresql://{postgresql_config.database_user}:{postgresql_config.database_password}@{postgresql_config.database_host}:{postgresql_config.database_port}/{postgresql_config.database_name}"

        conn = await pg.connect(con_str)
        field_values = await conn.fetch(
            f"select distinct(cmetadata->'{field_name}') from {collection_name}"
        )

        if field_values:
            deduped = set()
            for sign in field_values:
                for each in sign:
                    for glyph in each.replace("\\", "").replace('"', "").split(", "):
                        deduped.add(glyph)

            await conn.close()
            return list(deduped)

        await conn.close()
        return []

    def _get_connection_string(self) -> str:
        """Get Connection String for PostgreSQL
        ### Returns:
        - `str`: Connection String
        """

        self.logger.log(
            logging.INFO,
            f"Getting Connection String for PostgreSQL",
        )

        self.logger.log(
            logging.DEBUG,
            f"PostgreSQLDB Config: {self.appconfig.get_database_config().postgresdb_config.__dict__}",
        )

        postgresql_config = self.appconfig.get_database_config().postgresdb_config

        conn_string = f"postgresql+psycopg://{postgresql_config.database_user}:{postgresql_config.database_password}@{postgresql_config.database_host}:{postgresql_config.database_port}/{postgresql_config.database_name}".strip()

        self.logger.log(
            logging.DEBUG,
            f"Connection String: {conn_string}",
        )

        return conn_string
