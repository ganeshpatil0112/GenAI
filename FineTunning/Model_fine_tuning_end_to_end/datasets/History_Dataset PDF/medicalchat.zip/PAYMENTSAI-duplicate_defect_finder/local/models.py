"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-12-13
Description: Local Database Data Models
"""

from typing import List, Optional, TypedDict, Union, Dict


class DBGetResultType(TypedDict):
    ids: Union[List[str], str]
    embeddings: Optional[List[List[float]]]
    metadatas: Optional[List[Dict[str, str]]]
    documents: Optional[List[str]]
    scores: Optional[List[float]]


class SimilarSearchResult(DBGetResultType):
    ids: Union[List[str], str]
    embeddings: Optional[List[List[float]]]
    metadatas: Optional[List[Dict[str, str]]]
    documents: Optional[List[str]]
    scores: Optional[List[float]]
