"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-14
Description: Local Chroma Vector Database Implementation
"""

import logging
import asyncio
from langchain_chroma import Chroma
from chromadb.config import Settings
from utils.app_config import AppConfig
from langchain_core.documents import Document
from typing import List, Dict, Optional, Tuple
from abstraction.embedding import AppEmbedding
from local.models import SimilarSearchResult
from interfaces.database_inter import VectorDatabase
from langchain_core.vectorstores import VectorStore, VectorStoreRetriever


class ChromaDB(VectorDatabase):
    """Local Chroma Database Implementation"""

    def __init__(self, appconfig=AppConfig().load_config()):
        """Initialize Local ChromaDB
        ### Args:
        - `appconfig`: (AppConfig, optional): AppConfig instance. Defaults to AppConfig().load_config().
        """

        self.logger = logging.getLogger(self.__class__.__name__)

        self.embedding_function = AppEmbedding(appconfig=appconfig)
        self.appconfig = appconfig

        self.chroma_config = self.appconfig.get_database_config().chroma_config

        self.logger.log(
            logging.INFO,
            f"Initializing Local ChromaDB",
        )

        self.logger.log(
            logging.DEBUG,
            f"ChromaDB Config: {self.chroma_config.__dict__}",
        )

        self.chroma_settings = Settings(
            is_persistent=True,
            persist_directory=self.chroma_config.persist_directory,
            anonymized_telemetry=False,
        )

        self.db_client = Chroma(
            client_settings=self.chroma_settings,
            collection_name=self.chroma_config.collection_name,
            embedding_function=self.embedding_function,
            create_collection_if_not_exists=True,
        )

    def add_documents(self, documents: List[Document]) -> List[str]:
        """Add documents to Local ChromaDB
        ### Args:
        - `documents`: (List[Document]): List of Documents to be added to Local ChromaDB
        """

        self.logger.log(
            logging.INFO,
            f"Adding {len(documents)} documents to Local ChromaDB",
        )

        self.logger.log(
            logging.DEBUG,
            f"Documents: {documents} to be added to Local ChromaDB",
        )

        return super().add_documents(documents)

    async def aadd_documents(self, documents: List[Document]) -> List[str]:
        """Add documents to Local ChromaDB
        ### Args:
        - `documents`: (List[Document]): List of Documents to be added to Local ChromaDB
        """

        self.logger.log(
            logging.INFO,
            f"Adding {len(documents)} documents to Local ChromaDB",
        )

        self.logger.log(
            logging.DEBUG,
            f"Documents: {documents} to be added to Local ChromaDB",
        )

        return await super().aadd_documents(documents)

    def similarity_search_documents(
        self, query: str, limit: int, filters: Optional[Dict[str, str]]
    ) -> List[Tuple[Document, float]]:
        """Search documents in Local ChromaDB
        ### Args:
        - `query`: (str): Query to search in Local ChromaDB
        - `limit`: (int): Number of documents to return
        - `filters`: (Optional[Dict[str, str]]): Filters to apply on search
        ### Returns:
        - `List[Document]`: List of Documents
        """

        self.logger.log(
            logging.INFO,
            f"Searching documents in Local ChromaDB, query_len: {len(query)}, limit: {limit}, filters: {filters}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Searching documents in Local ChromaDB, query: {query}, Limit: {limit}, Filters: {filters}",
        )

        return super().similarity_search_with_score(query, limit, filters)

    async def asimilarity_search_document(
        self, query: str, limit: int, filters: Optional[Dict[str, str]]
    ) -> List[Tuple[Document, float]]:
        """Search documents in Local ChromaDB
        ### Args:
        - `query`: (str): Query to search in Local ChromaDB
        - `limit`: (int): Number of documents to return
        - `filters`: (Optional[Dict[str, str]]): Filters to apply on search
        ### Returns:
        - `List[Tuple[Document, float]]`: List of Tuple of Document and Score
        """

        self.logger.log(
            logging.INFO,
            f"Searching documents in Local ChromaDB, query_len: {len(query)}, limit: {limit}, filters: {filters}",
        )
        self.logger.log(
            logging.DEBUG,
            f"Searching documents in Local ChromaDB, query: {query}, Limit: {limit}, Filters: {filters}",
        )

        return await super().asimilarity_search_with_score(query, limit, filters)

    async def aget_document_with_filter(
        self, field_name: str, field_value: str
    ) -> SimilarSearchResult:
        """Get Document with filters from Local ChromaDB
        ### Args:
        - `field_name`: (str): Field Name to search in Local ChromaDB
        - `field_value`: (str): Field Value to search in Local ChromaDB
        ### Returns:
        - `str | None`: Document Metadata if found else None
        """

        self.logger.log(
            logging.INFO,
            f"Searching documents in Local ChromaDB with filters",
        )

        self.logger.log(
            logging.DEBUG,
            f"Get Document with Field_Name: {field_name}, Field_Value: {field_value}",
        )

        results = self.db_client.get(where={field_name: field_value})

        self.logger.log(
            logging.INFO,
            f"Documents found in Local ChromaDB with filters: {len(results)}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Documents found in Local ChromaDB with filters: {results}",
        )

        return results  # type: ignore

    async def aget_document_ids(self, field_name: str, field_value: str) -> List[str]:
        """Get Document IDs with filters from Local ChromaDB
        ### Args:
        - `field_name`: (str): Field Name to search in Local ChromaDB
        - `field_value`: (str): Field Value to search in Local ChromaDB
        ### Returns:
        - `document_id`: List[str] Document Ids if found else None
        """

        self.logger.log(
            logging.INFO,
            f"Searching documents in Local ChromaDB with filters",
        )

        self.logger.log(
            logging.DEBUG,
            f"Get Document with Field_Name: {field_name}, Field_Value: {field_value}",
        )

        results = await self.aget_document_with_filter(field_name, field_value)

        self.logger.log(
            logging.INFO,
            f"Documents found in Local ChromaDB with filters: {len(results)}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Documents found in Local ChromaDB with filters: {results}",
        )

        return results.get("ids") if results else []  # type: ignore

    async def aget_document_metadatas(
        self, field_name: str, field_value: str
    ) -> List[dict]:
        """Get Document Metadata with filters from Local ChromaDB
        ### Args:
        - `field_name`: (str): Field Name to search in Local ChromaDB
        - `field_value`: (str): Field Value to search in Local ChromaDB
        ### Returns:
        - `str | None`: Document Metadata if found else None
        """

        self.logger.log(
            logging.INFO,
            f"Searching documents in Local ChromaDB with filters",
        )

        self.logger.log(
            logging.DEBUG,
            f"Get Document with Field_Name: {field_name}, Field_Value: {field_value}",
        )

        resp = await self.aget_document_with_filter(field_name, field_value)

        if not resp:
            return []

        return resp.get("metadatas")  # type: ignore

    async def aupdate_documents(
        self, ids: List[str], documents: List[Document]
    ) -> None:
        """Update Document with filters from Local ChromaDB
        ### Args:
        - `documents`: (List[Document]): List of Documents to be updated in Local ChromaDB
        """

        self.logger.log(
            logging.INFO,
            f"Updating documents in Local ChromaDB",
        )

        self.logger.log(
            logging.DEBUG,
            f"Documents to be updated in Local ChromaDB: {documents}",
        )

        await asyncio.to_thread(self.db_client.update_documents, ids, documents)

    async def adelete_by_field_value(
        self, field_name: str, field_value: str
    ) -> Optional[bool]:
        """Delete Document with filters from Local ChromaDB
        ### Args:
        - `field_name`: (str): Field Name to search in Local ChromaDB
        - `field_value`: (str): Field Value to search in Local ChromaDB
        """

        self.logger.log(
            logging.INFO,
            f"Deleting documents in Local ChromaDB with field_name: {field_name}, field_value: {field_value}",
        )

        ids_to_delete = await self.aget_document_ids(field_name, field_value)

        self.logger.log(
            logging.INFO,
            f"Documents found in Local ChromaDB with filters: {len(ids_to_delete)}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Documents found in Local ChromaDB with filters: {ids_to_delete}",
        )

        return not ids_to_delete or await self.adelete_by_id(ids_to_delete) is not None

    async def aget_field_values(self, field_name: str) -> list[str]:
        """Fields values from Jira archives.

        Args:
            field_name (str): The Field name for which to look for.
        Returns:
            list[str]: The result values.
        """

        import sqlite3 as sq, os as shadow

        fs_path = shadow.path.join(shadow.curdir, ".db/chroma.sqlite3")
        rift = sq.connect(fs_path)
        pnt = rift.cursor()

        stmt = f"SELECT DISTINCT string_value FROM embedding_metadata WHERE key='{field_name}';"
        pnt.execute(stmt)
        values = pnt.fetchall()

        if values:
            deduped = set()
            for sign in values:
                for each in sign:
                    for glyph in each.replace('"', "").split(", "):
                        deduped.add(glyph)

            rift.close()
            return list(deduped)

        rift.close()
        return []

    def get_retriever(self, limit: int) -> VectorStoreRetriever:
        """Get retriever for Local ChromaDB
        ### Args:
        - `limit`: (int): Number of documents to return
        ### Returns:
        - `VectorStoreRetriever`: VectorStoreRetriever Instance
        """

        self.logger.log(
            logging.INFO,
            f"Getting retriever for Local ChromaDB, limit: {limit}",
        )

        return super().get_retriever(limit)

    def get_client(self) -> VectorStore:
        """Get client for Local ChromaDB
        ### Returns:
        - `VectorStore`: VectorStore Instance
        """

        self.logger.log(
            logging.INFO,
            f"Getting client for Local ChromaDB",
        )

        return self.db_client
