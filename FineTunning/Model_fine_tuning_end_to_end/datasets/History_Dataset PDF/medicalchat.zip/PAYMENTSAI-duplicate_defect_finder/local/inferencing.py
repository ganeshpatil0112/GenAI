"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-14
Description: Local Inferencing Implementation
"""

from langchain_ollama.chat_models import ChatOllama
from utils.app_config import AppConfig
import logging


class LocalInferencing:
    """Abstraction for local inferencing models"""

    def __init__(self, appconfig=AppConfig().load_config()):
        """Initialize Local Inferencing
        ### Args:
        - `appconfig`: (AppConfig, optional): AppConfig instance. Defaults to AppConfig().load_config().
        """

        self.logger = logging.getLogger(self.__class__.__name__)

        self.appconfig = appconfig
        self.local_inferencing_config = self.appconfig.get_local_inferencing_config()

        self.logger.log(
            logging.INFO,
            f"Initializing Local Inferencing",
        )

        self.logger.log(
            logging.DEBUG,
            f"Local Inferencing Config: {self.local_inferencing_config.__dict__}",
        )

        self.inferencing_function = ChatOllama(
            model=self.local_inferencing_config.model,
            temperature=self.local_inferencing_config.temperature,
            num_predict=self.local_inferencing_config.max_tokens,
            top_k=self.local_inferencing_config.top_k,
            seed=self.local_inferencing_config.seed,
        )

    def get_llm(self) -> ChatOllama:
        """Get Local Inferencing Model
        ### Returns:
        - `ChatOllama`: Local Inferencing Model
        """

        self.logger.log(
            logging.INFO,
            f"Getting Local Inferencing Model",
        )

        return self.inferencing_function
