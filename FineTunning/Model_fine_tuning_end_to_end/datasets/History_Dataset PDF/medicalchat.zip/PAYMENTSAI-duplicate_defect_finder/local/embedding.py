"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-14
Description: Local Embedding Implementation
"""

import logging
from langchain_ollama.embeddings import OllamaEmbeddings
from utils.app_config import AppConfig
from typing import List


class LocalEmbedding:
    """Abstraction for local embedding models"""

    def __init__(self, appconfig=AppConfig().load_config()):
        """Initialize Local Embedding
        ### Args:
        - `appconfig`: (AppConfig, optional): AppConfig instance. Defaults to AppConfig().load_config().
        """

        self.logger = logging.getLogger(self.__class__.__name__)

        self.appconfig = appconfig

        self.local_embedding_config = self.appconfig.get_local_embedding_config()

        self.logger.log(
            logging.INFO,
            f"Initializing Local Embedding",
        )

        self.logger.log(
            logging.DEBUG,
            f"Local Embedding Config: {self.local_embedding_config.__dict__}",
        )

        self.embedding_function = OllamaEmbeddings(
            model=self.local_embedding_config.model
        )

    def embed_documents(self, texts: List[str]):
        """Local Embed documents
        ### Args:
        - `texts`: (List[str]): List of texts to be embedded
        ### Returns:
        - `List[List[float]]`: List of embeddings
        """

        self.logger.log(
            logging.INFO,
            f"Local Embedding Documents, texts len: {len(texts)}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Local Embedding Documents, texts: {texts}",
        )

        return self.embedding_function.embed_documents(texts)

    def embed_query(self, text):
        """Local Embed Query
        ### Args:
        - `text`: (str): Query to be embedded
        ### Returns:
        - `List[float]`: Query embedding
        """

        self.logger.log(
            logging.INFO,
            f"Local Embedding Query, query_len: {len(text)}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Local Embedding Query, query: {text}",
        )

        return self.embedding_function.embed_query(text)

    async def aembed_documents(self, texts: List[str]) -> List[List[float]]:
        """Local Embed documents async
        ### Args:
        - `texts`: (List[str]): List of texts to be embedded
        ### Returns:
        - `List[List[float]]`: List of embeddings
        """

        self.logger.log(
            logging.INFO,
            f"Local Embedding Documents, texts len: {len(texts)}",
        )

        self.logger.log(
            logging.DEBUG,
            f"Local Embedding Documents, texts: {texts}",
        )

        return await self.embedding_function.aembed_documents(texts)

    async def aembed_query(self, text) -> List[float]:
        """Local Embed Query async
        ### Args:
        - `text`: (str): Query to be embedded
        ### Returns:
        - `List[float]`: Query embedding
        """

        self.logger.log(
            logging.INFO,
            f"Local Embedding Query, query_len: {len(text)}",
        )

        return await self.embedding_function.aembed_query(text)
