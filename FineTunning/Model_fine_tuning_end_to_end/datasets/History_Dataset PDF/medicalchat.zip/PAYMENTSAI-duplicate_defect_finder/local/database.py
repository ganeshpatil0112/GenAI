"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-14
Description: Local Vector Database Interface
"""

import logging
from interfaces.database_inter import VectorDatabase
from local.chroma_db import ChromaDB
from local.postgresql import PostgreSQLDB
from utils.app_config import AppConfig, DatabaseProvider


class LocalDatabase:
    """Local Database Implementation"""

    def __init__(self, appconfig=AppConfig().load_config()):
        """Local Database Implementation
        ### Args:
        - `appconfig`: (AppConfig, optional): AppConfig instance. Defaults to AppConfig().load_config().
        """

        self.logger = logging.getLogger(self.__class__.__name__)

        self.appconfig = appconfig

        self.database_provider = self.appconfig.get_database_config().database_provider

        self.logger.log(logging.INFO, f"Database Provider: {self.database_provider}")

        match self.database_provider:

            case DatabaseProvider.CHROMA:
                self.logger.log(
                    logging.DEBUG,
                    f"Using ChromaDB as Database Provider",
                )
                self.db_client = ChromaDB(appconfig)

            case DatabaseProvider.POSTGRESQL:
                self.logger.log(
                    logging.DEBUG,
                    f"Using ChromaDB as Database Provider",
                )
                self.db_client = PostgreSQLDB(appconfig)

    def get_db_client(self) -> VectorDatabase:
        """Get Database Client
        ### Returns:
        - `VectorDatabase`: Database Client
        """

        return self.db_client
