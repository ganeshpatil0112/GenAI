"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-12-02
Description: App Level database implementation abstraction.
"""

from abstraction.inferencing import AppInferencing
from fastapi import WebSocket, APIRouter
from api.models import UserQuery
import logging
import json

socket_router = APIRouter()


@socket_router.websocket("/chat")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket Endpoint for Chat Completion"""
    await websocket.accept()
    logging.info("WebSocket connection accepted")

    app_inf = AppInferencing()

    while True:
        str_data = await websocket.receive_text()
        json_data = json.loads(str_data)
        user_query = UserQuery(**json_data)

        logging.log(
            logging.INFO,
            f"Received user query: {user_query.query} with session id: {user_query.session_id}",
        )

        async for resp in app_inf.get_llm().astream(input=user_query.query):
            await websocket.send_text(str(resp.content))
