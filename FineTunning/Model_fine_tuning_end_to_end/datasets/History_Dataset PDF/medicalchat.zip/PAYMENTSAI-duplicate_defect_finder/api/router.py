from jira_similar_def_app.app import jsdf_router
from api.extra_routes import extra_router
from api.websocket import socket_router
from fastapi import APIRouter


# Application Router
main_router = APIRouter()


@main_router.get("/", tags=["Home"])
async def home():
    return {"message": "Hello World"}


# Include Extra Router to Main Router
main_router.include_router(router=extra_router, prefix="/extra")
main_router.include_router(router=socket_router, prefix="/ws")

# Include Jira Similar Defect Router to Main Router
main_router.include_router(router=jsdf_router, prefix="/jsdf")
