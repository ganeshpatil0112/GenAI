"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-12-02
Description: API Request Models.
"""

from pydantic import BaseModel
from typing import List, Any, Literal
from uuid import uuid4


class UserQuery(BaseModel):
    """User Query Base Model, used by Websocket"""

    query: str
    knowledge_base: str
    session_id: str
    thread_id: str


class Message(BaseModel):
    """Messages Base Model"""

    type: Literal["system", "human", "ai"] = "system"
    content: str = ""


class PostRequestUserQuery(BaseModel):
    """Post Request User Query Model"""

    messages: List[Message] = []
    knowledge_base: str = "jira"
    session_id: str = uuid4().hex
    thread_id: str = uuid4().hex
