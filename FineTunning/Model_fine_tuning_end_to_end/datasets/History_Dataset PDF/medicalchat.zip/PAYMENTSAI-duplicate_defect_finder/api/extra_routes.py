from fastapi import APIRouter

extra_router = APIRouter()


@extra_router.get("/help", tags=["Help"])
def help():
    return "<h1>Nothing Here Yet...</h1>"
