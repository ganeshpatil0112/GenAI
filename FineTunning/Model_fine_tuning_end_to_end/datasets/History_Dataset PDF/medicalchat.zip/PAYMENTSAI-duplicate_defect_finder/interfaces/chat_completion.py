"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2025-01-03
Description: App Level Chat Completion for user.
"""

from langgraph.graph.graph import CompiledGraph
from langchain_core.messages import BaseMessage
from langchain_core.runnables import Runnable
from utils.app_config import AppConfig
from typing import List, Any, Optional
from abc import abstractmethod
from fastapi import WebSocket
from uuid import uuid4


class ChatCompletionInterface:
    """Chat Completion for User"""

    def __init__(
        self,
        messages: List[BaseMessage],
        stream_output: bool = False,
        trimmer: Any = None,
        appconfig=AppConfig().load_config(),
    ):
        """Initialize Chat Completion
        ### Args:
        - message: List of messages
        """
        self.messages = messages
        self.stream_output = stream_output
        self.trimmer = trimmer
        self.appconfig = appconfig
        self.llm_chain: Optional[CompiledGraph | Runnable]
        self.session_id = uuid4().hex
        self.thread_id = uuid4().hex

    def with_session_id(self, session_id: str) -> "ChatCompletionInterface":
        """Set Session ID for user
        ### Args:
        - session_id: str Session ID for user
        ### Returns:
        - ChatCompletion: ChatCompletion object
        """

        self.session_id = session_id

        return self

    def with_thread_id(self, thread_id: str) -> "ChatCompletionInterface":
        """Set Thread ID for user
        ### Args:
        - thread_id: str Thread ID for user
        ### Returns:
        - ChatCompletion: ChatCompletion object
        """

        self.thread_id = thread_id

        return self

    def with_llm_chain(
        self, llm_chain: Optional[Runnable]
    ) -> "ChatCompletionInterface":
        """Set LLM Chain for user
        ### Args:
        - llm_chain: Runnable LLM Chain for user
        ### Returns:
        - ChatCompletion: ChatCompletion object
        """

        self.llm_chain = llm_chain

        return self

    async def aresponse_with_history(
        self, user_queries: List[BaseMessage]
    ) -> str | None:
        """Response to user query with history
        ### Args:
        - user_queries: List[BaseMessage] User Queries
        ### Returns:
        - str: Response for user
        """

        raise NotImplementedError("Method should be implemented in Subclass")

    @abstractmethod
    async def aresponse(self, user_query: str) -> str:
        """Get Response for user
        ### Args:
        - user_query: str User Query
        ### Returns:
        - str: Response for user
        """

        raise NotImplementedError("Method Should be implemented in Subclass")

    @abstractmethod
    async def astream_response(self, websocket: WebSocket, user_query: str) -> None:
        """Get Stream Response for user
        ### Args:
        - websocket: WebSocket Websocket
        - user_query: str User Query
        """

        raise NotImplementedError("Method Should be implemented in Subclass")
