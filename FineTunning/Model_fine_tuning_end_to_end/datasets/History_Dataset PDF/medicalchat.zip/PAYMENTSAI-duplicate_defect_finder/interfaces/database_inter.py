"""
Author: Abu Ghalib
Email: abu.ghalib@finastra.com
Date: 2024-11-07
Description: Vector Database Interface
"""

from langchain_core.vectorstores import VectorStoreRetriever
from typing import List, Tuple, Optional, Dict
from langchain_core.documents import Document
from local.models import DBGetResultType
from langchain_postgres import PGVector
from langchain_chroma import Chroma


class VectorDatabase:
    """Vector Database Interface"""

    def __init__(self, db_client: Chroma | PGVector):
        """Initialize Vector Database Interface"""

        self.db_client = db_client

    def add_documents(self, documents: List[Document]) -> List[str]:  # type: ignore
        """Add documents to the database
        ### Args:
        - `documents`: List[Document] List of documents to be added to the database
        """

        return self.db_client.add_documents(documents=documents)

    async def aadd_documents(self, documents: List[Document]) -> List[str]:  # type: ignore
        """Add documents to the database
        ### Args:
        - `documents`: List[Document] List of documents to be added to the database
        """

        return await self.db_client.aadd_documents(documents=documents)

    def similarity_search_with_score(
        self, query: str, limit: int, filters: Optional[Dict[str, str]]
    ) -> List[Tuple[Document, float]]:
        """Search documents in the database
        ### Args:
        - `query`: str Query string to search
        - `limit`: int Number of documents to return
        - `filters`: Optional[Dict[str, str]] Filters to apply on the search
        ### Returns:
        - `List[Tuple[Document, float]]`: List of documents with their similarity scores
        """

        return self.db_client.similarity_search_with_score(
            query=query, k=limit, filter=filters
        )

    async def asimilarity_search_with_score(
        self, query: str, limit: int, filters: Optional[Dict[str, str]]
    ) -> List[Tuple[Document, float]]:
        """Search documents in the database
        ### Args:
        - `query`: str Query string to search
        - `limit`: int Number of documents to return
        - `filters`: Optional[Dict[str, str]] Filters to apply on the search
        ### Returns:
        - `List[Tuple[Document, float]]`: List of documents with their similarity scores
        """

        return await self.db_client.asimilarity_search_with_score(
            query=query, k=limit, filter=filters
        )

    def search_document_with_embeddings(
        self,
        query: List[float],
        limit: int,
    ) -> List[Document]:
        """Search documents with embeddings
        ### Args:
        - `query`: List[float] Query vector
        - `limit`: int Number of documents to return
        ### Returns:
        - `List[Document]`: List of documents with their similarity scores
        """

        return self.db_client.similarity_search_by_vector(query, k=limit)

    async def asearch_document_with_embeddings(
        self,
        query: List[float],
        limit: int,
    ) -> List[Document]:
        """Search documents with embeddings
        ### Args:
        - `query`: List[float] Query vector
        - `limit`: int Number of documents to return
        ### Returns:
        - `List[Document]`: List of documents with their similarity scores
        """

        return await self.db_client.asimilarity_search_by_vector(query, k=limit)

    def get_document_by_id(self, doc_id: str) -> List[Document]:
        """Get document by id
        ### Args:
        - `doc_id`: str Document id
        ### Returns:
        - `Document`: List[Document] with the given id
        """

        return self.db_client.get_by_ids([doc_id])

    async def aget_document_by_id(self, doc_id: str) -> List[Document]:
        """Get document by id
        ### Args:
        - `doc_id`: str Document id
        ### Returns:
        - `Document`: List[Document] with the given id
        """

        return await self.db_client.aget_by_ids([doc_id])

    async def aget_document_with_filter(
        self, field_name: str, field_value: str
    ) -> DBGetResultType:
        """Get Document with filter
        ### Args:
        - `field_name`: str Field Name
        - `field_value`: str Field Value
        ### Returns:
        - `List[Document]`: List of documents with the given filter
        """

        raise NotImplementedError("Subclasses should implement this!")

    def get_document_metadatas(self, field_name: str, field_value: str) -> List[dict]:
        """Get documents with filters
        ### Args:
        - `filter`: Optional[Dict[str, str]] Filters to apply on the search
        ### Returns:
        - `List[Document]`: List of documents with the given filters
        """

        raise NotImplementedError("Subclasses should implement this!")

    async def aget_document_metadatas(
        self, field_name: str, field_value: str
    ) -> List[dict]:
        """Get documents with filters
        ### Args:
        - `field_name`: str Field name
        - `field_value`: str Field value
        ### Returns:
        - `List[Document]`: List of documents with the given filters
        """

        raise NotImplementedError("Subclasses should implement this!")

    async def aget_document_ids(self, field_name: str, field_value: str) -> List[str]:
        """Get documents with filters
        ### Args:
        - `field_name`: str Field name
        - `field_value`: str Field value
        ### Returns:
        - `List[Document]`: List of documents with the given filters
        """

        raise NotImplementedError("Subclasses should implement this!")

    async def aupdate_documents(
        self, ids: List[str], documents: List[Document]
    ) -> None:
        """Update documents in the database
        ### Args:
        - `documents`: List[Document] List of documents to be updated in the database
        """

        raise NotImplementedError("Subclasses should implement this!")

    async def adelete_by_id(self, ids: List[str]) -> Optional[bool]:
        """Delete document by id
        ### Args:
        - `doc_id`: str Document id
        """

        return await self.db_client.adelete(ids=ids)

    async def adelete_by_field_value(self, field_name: str, field_value: str) -> Optional[bool]:
        """Delete documents by custom field
        ### Args:
        - `field_name`: str Field name
        - `field_value`: str Field value
        """

        raise NotImplementedError("Subclasses should implement this!")

    def get_retriever(self, limit: int) -> VectorStoreRetriever:
        """Get a retriever object
        ### Args:
        - `limit`: int Number of documents to return
        ### Returns:
        - `VectorStoreRetriever`: Retriever object
        """

        return self.db_client.as_retriever(
            search_type="mmr", search_kwargs={"k": limit, "fetch_k": 50}
        )
