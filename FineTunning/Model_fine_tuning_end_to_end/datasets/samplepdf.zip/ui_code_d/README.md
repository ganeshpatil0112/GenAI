# AiccelerateUI

Frontend for AIccelerate

This is a modular UI and can be integrated with any chat backend.
Fork the repo and Change the api endpoint in chat.service.ts to point to your environment.

## Steps to Run

1. **Install Node and Angular CLI**
   - Ensure you have Node.js installed on your machine. You can download it from Node.js.
   - Install Angular CLI globally using the following command:
     ```bash
     npm install -g @angular/cli
     ```

2. **Clone the Repository**
   - Navigate to the directory where you want to clone the repository and run:
     ```bash
     git clone <repository-url>
     ```
   - Replace `<repository-url>` with the actual URL of your GitHub repository.

3. **Navigate to the Repository**
   - Change to the repository directory:
     ```bash
     cd AiccelerateUI
     ```

4. **Install Dependencies**
   - Run the following command to install all necessary dependencies:
     ```bash
     npm install
     ```

5. **Run the Application**
   - Once the installation is successful, start the development server:
     ```bash
     ng serve
     ```
   - Open your browser and navigate to `http://10.208.92.74:4200/` to see the application in action.

## Additional Information

- For any issues or contributions, please open an issue or submit a pull request.
- Make sure to follow the coding standards and guidelines mentioned in the repository.
