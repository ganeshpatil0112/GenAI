import {
  Component,
  inject,
  ViewChild,
  ElementRef,
  AfterViewChecked,
  viewChild,
  OnInit,
} from "@angular/core";
import { bootstrapApplication } from "@angular/platform-browser";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { HttpClientModule, provideHttpClient } from "@angular/common/http";
import { RouterOutlet } from "@angular/router";
import { RouterModule, Router } from "@angular/router";
import { ChatMessage } from "../models/chat.model";
import { ChatService } from "../services/chat.service";
import { AuthService } from "../services/auth.service";

@Component({
  selector: "app-chat",
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  template: `
    <div class="chat-container">
      <div class="chat-header">
        <div class="user-info">
          <h1>Duplicate Defect Finder</h1>
          <span class="user-email">{{ userEmail }}</span>
          <button
            class="logout-btn"
            style="
              background: #e0e0e0;
              color: #2c0950;
              border: none;
              padding: 0.5rem 1rem;
              cursor: pointer;
              border-radius: 0.25rem;
            "
            (click)="logout()"
          >
            Logout
          </button>
        </div>
      </div>

      <div class="messages-container" #scrollContainer>
        <div
          *ngFor="let message of messages"
          [class]="
            'message ' +
            (message.type === 'human' ? 'user-message' : 'bot-message')
          "
        >
          <div class="message-content">
            <p [innerHTML]="formatMarkdown(message.content)"></p>
            <div class="message-footer">
              <span class="timestamp">{{
                message.timestamp | date : "shortTime"
              }}</span>
              <div *ngIf="message.type === 'ai'" class="feedback-icons">
                <button
                  [class]="
                    'feedback-btn ' +
                    (message.feedback === 'like' ? 'active' : '')
                  "
                  (click)="openFeedbackDialog(message, 'like')"
                >
                  👍
                </button>
                <button
                  [class]="
                    'feedback-btn ' +
                    (message.feedback === 'dislike' ? 'active' : '')
                  "
                  (click)="openFeedbackDialog(message, 'dislike')"
                >
                  👎
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Loading Indicator -->
        <div *ngIf="isLoading" class="loading-message">
          <div ngClass="loading-spinner"></div>
          <p>Thinking...</p>
        </div>
      </div>

      <div class="input-container">
        <input
          type="text"
          #messageInput
          [(ngModel)]="currentMessage"
          (keyup.enter)="sendMessage()"
          placeholder="Type your message..."
          [disabled]="isLoading"
        />
        <button
          (click)="sendMessage()"
          [disabled]="!currentMessage || isLoading"
        >
          {{ isLoading ? "Sending..." : "Send" }}
        </button>
      </div>

      <!-- Feedback Dialog -->
      <div
        class="feedback-dialog"
        *ngIf="showFeedbackDialog"
        (click)="closeFeedbackDialog($event)"
      >
        <div class="feedback-dialog-content" (click)="$event.stopPropagation()">
          <h2>Provide Feedback</h2>
          <p class="feedback-message">{{ selectedMessage?.content }}</p>
          <!--text box to accept email id -->
          <h4>Email :</h4>
          <input
            type="email"
            [(ngModel)]="feedbackEmail"
            placeholder="Your email (optional)"
          />
          <h4>Feedback :</h4>
          <textarea
            [(ngModel)]="feedbackComment"
            placeholder="Please provide additional feedback (optional)"
            rows="4"
          >
          </textarea>
          <div class="feedback-dialog-buttons">
            <button (click)="closeFeedbackDialog($event)">Cancel</button>
            <button (click)="submitFeedback()" class="submit-btn">
              Submit
            </button>
          </div>
        </div>
      </div>
    </div>
  `,
  styleUrls: ["../styles/chat.css"],
})
export class ChatComponent implements AfterViewChecked, OnInit {
  @ViewChild("scrollContainer") private scrollContainer!: ElementRef;
  @ViewChild("messageInput") private messageInput!: ElementRef;

  messages: ChatMessage[] = [];
  currentMessage = "";
  isLoading = false;
  showFeedbackDialog = false;
  selectedMessage: ChatMessage | null = null;
  selectedFeedbackType: "like" | "dislike" | null = null;
  feedbackComment = "";
  feedbackEmail = "";
  userEmail: string = "";
  private chatService = inject(ChatService);
  private authService = inject(AuthService);
  private router = inject(Router);
  private shouldScroll = false;

  ngOnInit() {
    this.userEmail = this.authService.getUserEmail() || "Guest";
  }

  ngAfterViewChecked() {
    if (this.shouldScroll) {
      this.scrollToBottom();
      this.focusInput();
      this.shouldScroll = false;
    }
  }

  private scrollToBottom() {
    try {
      this.scrollContainer.nativeElement.scrollTop =
        this.scrollContainer.nativeElement.scrollHeight;
    } catch (error) {
      console.error("Error scrolling to bottom:", error);
    }
  }

  private focusInput() {
    try {
      this.messageInput.nativeElement.focus();
    } catch (error) {
      console.error("Error focusing input:", error);
    }
  }

  formatMarkdown(text: string): string {
    //convert markdown links
    text = text.replace(
      /\[(.*?)\]\((.*?)\)/g,
      '<a href="$2" target="_blank">$1</a>'
    );

    //convert bold text
    text = text.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");

    return text;
  }

  async sendMessage() {
    if (!this.currentMessage.trim() || this.isLoading) return;

    const userMessage: ChatMessage = {
      content: this.currentMessage,
      type: "human",
      timestamp: new Date(),
    };

    this.messages.push(userMessage);
    const messageToSend = this.currentMessage;
    this.currentMessage = "";
    this.isLoading = true;
    this.shouldScroll = true;

    try {
      const messageHistory = this.messages.map((msg) => ({
        content: msg.content,
        type: msg.type,
      }));

      const responses = await this.chatService
        .sendMessage(messageToSend, messageHistory)
        .toPromise();

      if (responses) {
        // Add the heading as a separate message
        responses.forEach((response) => {
          this.messages.push({
            content: response,
            type: "ai",
            timestamp: new Date(),
          });
        });
        this.shouldScroll = true;
      }
    } catch (error) {
      console.error("Error sending message:", error);
      this.messages.push({
        content: "Sorry, there was an error processing your request.",
        type: "ai",
        timestamp: new Date(),
      });
      this.shouldScroll = true;
    } finally {
      this.isLoading = false;
    }
  }

  openFeedbackDialog(message: ChatMessage, type: "like" | "dislike") {
    this.selectedMessage = message;
    this.selectedFeedbackType = type;
    this.feedbackComment = "";
    this.feedbackEmail = "";
    this.showFeedbackDialog = true;
  }

  closeFeedbackDialog(event: MouseEvent) {
    this.showFeedbackDialog = false;
    this.selectedMessage = null;
    this.selectedFeedbackType = null;
    this.feedbackComment = "";
    this.feedbackEmail = "";
  }

  async submitFeedback() {
    if (!this.selectedMessage || !this.selectedFeedbackType) return;
    try {
      await this.chatService
        .sendFeedback(
          {
            messageContent: this.selectedMessage.content,
            feedback: this.selectedFeedbackType,
            comment: this.feedbackComment,
            email: this.feedbackEmail,
          },
          this.messages
        )
        .toPromise();

      this.selectedMessage.feedback = this.selectedFeedbackType;
    } catch (error) {
      console.error("Error sending feedback:", error);
    }

    this.closeFeedbackDialog(new MouseEvent("click"));
  }

  logout() {
    this.authService.logout();
    this.router.navigate(["/login"]);
  }
}
