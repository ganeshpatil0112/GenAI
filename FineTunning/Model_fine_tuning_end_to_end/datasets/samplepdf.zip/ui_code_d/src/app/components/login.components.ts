import { Component, OnInit } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { AuthService } from "../services/auth.service";
import { Router } from "@angular/router";

@Component({
  selector: "app-login",
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="login-container">
      <div class="login-box">
        <h2>Login</h2>
        <form *ngIf="!otpSent" (ngSubmit)="sendOtp()" #emailForm="ngForm">
          <div class="form-group">
            <label for="email">Email</label>
            <input
              type="text"
              id="email"
              name="email"
              [(ngModel)]="credentials.email"
              required
              #email="ngModel"
            />
            <div
              *ngIf="email.invalid && (email.dirty || email.touched)"
              class="error-message"
            >
              Email is required
            </div>
          </div>
          <button type="submit" [disabled]="emailForm.invalid || isLoading">
            {{ isLoading ? "Sending..." : "Send OTP" }}
          </button>
          <div *ngIf="error" class="error-message">
            {{ error }}
          </div>
        </form>
        <form *ngIf="otpSent" (ngSubmit)="verifyOtp()" #otpForm="ngForm">
          <div class="form-group">
            <label for="otp">Enter OTP</label>
            <input
              type="text"
              id="otp"
              name="otp"
              [(ngModel)]="credentials.otp"
              required
              #otp="ngModel"
            />
            <div
              *ngIf="otp.invalid && (otp.dirty || otp.touched)"
              class="error-message"
            >
              OTP is required
            </div>
          </div>
          <button type="submit" [disabled]="otpForm.invalid || isLoading">
            {{ isLoading ? "Verifying..." : "Verify OTP" }}
          </button>
          <button
            type="button"
            (click)="otpSent = false"
            [disabled]="isLoading"
            style="
              margin-top: 0.5rem;
              width: 100%;
              background: #e0e0e0;
              color: #2c0950;
            "
          >
            Back
          </button>
          <div *ngIf="error" class="error-message">
            {{ error }}
          </div>
        </form>
        <div
          *ngIf="jwtToken"
          class="success-message"
          style="margin-top: 1rem; color: green;"
        >
          Login successful! JWT Token received.
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      .login-container {
        height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #f8f9fa;
      }

      .login-box {
        background: white;
        padding: 2rem;
        border-radius: 1rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 400px;
      }

      h2 {
        margin: 0 0 1.5rem;
        color: #2c0950;
        text-align: center;
      }

      .form-group {
        margin-bottom: 1rem;
      }

      label {
        display: block;
        margin-bottom: 0.5rem;
        color: #2c0950;
      }

      input {
        width: 100%;
        padding: 0.8rem;
        border: 1px solid #e0e0e0;
        border-radius: 0.5rem;
        font-size: 1rem;
      }

      input:focus {
        outline: none;
        border-color: #8a3ffc;
      }

      button {
        width: 100%;
        padding: 0.8rem;
        background: #8a3ffc;
        color: white;
        border: none;
        border-radius: 0.5rem;
        cursor: pointer;
        font-size: 1rem;
        margin-top: 1rem;
      }

      button:hover:not(:disabled) {
        background: #2c0950;
      }

      button:disabled {
        background: #e0e0e0;
        cursor: not-allowed;
      }

      .error-message {
        color: #dc3545;
        font-size: 0.875rem;
        margin-top: 0.25rem;
      }

      .success-message {
        font-size: 0.875rem;
        margin-top: 0.25rem;
      }
    `,
  ],
})
export class LoginComponent implements OnInit {
  credentials = {
    email: "",
    otp: "",
  };
  isLoading = false;
  error: string | null = null;
  otpSent = false;
  jwtToken: string | null = null;

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit() {
    if (this.authService.getToken()) {
      this.router.navigate(["/"]);
    }
  }

  sendOtp() {
    if (this.isLoading) return;
    if (!this.credentials.email.endsWith('@finastra.com')) {
      this.error = 'Invalid email. Only @finastra.com emails are allowed.';
      return;
    }
    this.isLoading = true;
    this.error = null;
    this.authService.sendOtp(this.credentials.email).subscribe({
      next: () => {
        this.isLoading = false;
        this.otpSent = true;
      },
      error: (err) => {
        this.isLoading = false;
        this.error = "Failed to send OTP. Please check your email.";
        console.error("Send OTP error:", err);
      },
    });
  }

  verifyOtp() {
    if (this.isLoading) return;
    this.isLoading = true;
    this.error = null;
    this.authService
      .verifyOtp(this.credentials.email, this.credentials.otp)
      .subscribe({
        next: (response) => {
          // Wait for the token to be set before navigating
          setTimeout(() => {
            this.isLoading = false;
            this.jwtToken = null;
            this.router.navigateByUrl("/", { replaceUrl: true });
          }, 300);
        },
        error: (err) => {
          this.isLoading = false;
          this.error = "Invalid OTP. Please try again.";
          console.error("Verify OTP error:", err);
        },
      });
  }
}
