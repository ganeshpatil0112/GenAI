import { Routes } from '@angular/router';
import { provideRouter } from '@angular/router';
import { LoginComponent } from './components/login.components';
import { ChatComponent } from './components/chat.component';
import { authGuard } from './auth.guard';
import { loginGuard } from './login.guard';

export const routes: Routes = [
  { path: 'login', component: LoginComponent, canActivate: [loginGuard] },
  { path: '', component: ChatComponent, canActivate: [authGuard] },
  { path: 'logout', loadComponent: () => import('./components/login.components').then(m => m.LoginComponent) }, // Optional: logout route
];

export const appRouterProviders = [
  provideRouter(routes)
];
