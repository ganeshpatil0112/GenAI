import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable, tap } from "rxjs";
import { AuthState, LoginRequest, LoginResponse } from "../models/auth.model";
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: "root",
})
export class AuthService {
  private apiUrl = "http://10.208.94.38:8000/jsdf";
  private authState = new BehaviorSubject<AuthState>({
    isAuthenticated: false,
    access_token: null,
    email: null,
  });

  constructor(private http: HttpClient) {
    const token = localStorage.getItem("token");
    const email = localStorage.getItem("email");

    if (token && email) {
      this.authState.next({
        isAuthenticated: true,
        access_token: token,
        email: JSON.parse(email),
      });
    }
  }

  //   login(credentials: LoginRequest): Observable<LoginResponse> {
  //     return this.http
  //       .post<LoginResponse>(`${this.apiUrl}/login`, credentials)
  //       .pipe(
  //         tap((response) => {
  //           localStorage.setItem("token", response.token);
  //           localStorage.setItem("user", JSON.stringify(credentials.email));
  //           this.authState.next({
  //             isAuthenticated: true,
  //             token: response.token,
  //             email: credentials.email,
  //           });
  //         })
  //       );
  //   }

  sendOtp(email: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/send_otp`, { email }).pipe(
      tap(() => {
        localStorage.setItem("email", JSON.stringify(email));
        this.authState.next({
          isAuthenticated: false,
          access_token: null,
          email,
        });
      })
    );
  }

  verifyOtp(email: string, otp: string): Observable<LoginResponse> {
    return this.http
      .post<LoginResponse>(`${this.apiUrl}/verify_otp`, { email, otp })
      .pipe(
        tap((response) => {
          if (!response.access_token) {
            throw new Error("No token received from backend");
          }
          localStorage.setItem("token", response.access_token);
          this.authState.next({
            isAuthenticated: true,
            access_token: response.access_token,
            email,
          });
        })
      );
  }

  verifyOtpMock(email: string, otp: string): Observable<LoginResponse> {
    // Mock implementation for testing purposes
    return new Observable<LoginResponse>((observer) => {
      setTimeout(() => {
        const mockResponse: LoginResponse = {
          access_token:
            "e30.eyJzdWIiOiAiYWJ1LmdoYWxpYkBmaW5hc3RyYS5jb20iLCAiaWF0IjogMTc1MDY3MDY5NiwgImV4cCI6IDE3NTEyNzU0OTZ9.5Ebs8RFK6nqc8BNsoNhToel7HaiUnh96Y_XphymGAnI",
          token_type: "bearer",
        };
        localStorage.setItem("token", mockResponse.access_token);
        this.authState.next({
          isAuthenticated: true,
          access_token: mockResponse.access_token,
          email,
        });
        observer.next(mockResponse);
        observer.complete();
      }, 1000); // Simulate network delay
    });
  }

  logout(): void {
    localStorage.removeItem("token");
    localStorage.removeItem("email");
    this.authState.next({
      isAuthenticated: false,
      access_token: null,
      email: null,
    });
  }

  getAuthState(): Observable<AuthState> {
    return this.authState.asObservable();
  }

  getToken(): string | null {
    return this.authState.value.access_token;
  }

  getUserEmail(): string | null {
    return this.authState.value.email;
  }
}
