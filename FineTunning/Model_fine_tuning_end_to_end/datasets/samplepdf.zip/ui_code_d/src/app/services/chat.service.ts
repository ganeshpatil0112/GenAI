import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable, map } from "rxjs";
import {
  ChatRequest,
  ChatMessage,
  FeedbackRequest,
} from "../models/chat.model";

@Injectable({
  providedIn: "root",
})
export class ChatService {
  private apiUrl = "http://10.208.94.38:8001/jsdf"; // adjust this to your server port

  constructor(private http: HttpClient) {}

  parseJsonResponse = (response: string): Array<string> => {
    //remove markdown codeblock syntax and clean up the string
    const cleanResponse = response.replace(/```json\n|\n```/g, "");
    //if the response is a string, Parse it to JSON
    try {
      const jsonResponse = JSON.parse(cleanResponse);
      let messages: string[] = [];

      messages.push(jsonResponse.responses.heading || "");

      if (jsonResponse.responses.values) {
        //add the heading if it exists

        return [
          jsonResponse.responses.heading,
          ...jsonResponse.responses.values,
        ];
      } else {
        return ["No Similar Defect Found, Please retry with different query"];
      }
    } catch (error) {
      console.log(error);
      // Retry maybe there is a syntax error probably starting with json and { in new line.
      // Check if string as json and { in new line.
      const regex = /^[\s\S]*?json\s*\n*({[\s\S]*)/;
      const match = cleanResponse.match(regex);

      if (match && match[1]) {
        return this.parseJsonResponse(match[1]);
      }
    }
    //if json parsing fails, treat entire response as markdown
    return [cleanResponse];
  };

  sendMessage(
    message: string,
    messageHistory: { content: string; type: string }[]
  ): Observable<string[]> {
    const request: ChatRequest = {
      messages: [
        ...messageHistory,
        {
          content: message,
          type: "human",
        },
      ],
      knowledge_base: "jira",
      session_id: "abc",
      thread_id: "abc",
    };

    return this.http
      .post<string>(`${this.apiUrl}/chat`, request, {
        headers: {
          Authorization: `Bearer ${this.getTokenFromLocalStorage()}`,
        },
      })
      .pipe(
        map((response) => {
          return this.parseJsonResponse(response);
        })
      );
  }

  sendFeedback(
    feedback: {
      messageContent: string;
      feedback: "like" | "dislike";
      comment: string;
      email: string;
    },
    messages: ChatMessage[]
  ): Observable<any> {
    //convert messages to chat history format
    const chatHistory = messages.map((msg) => ({
      content: msg.content,
      type: msg.type,
    }));

    const feedbackRequest: FeedbackRequest = {
      email: feedback.email, // add user email here
      response: feedback.messageContent,
      feedback: feedback.comment,
      impression: feedback.feedback === "like",
      chat_history: chatHistory,
    };
    return this.http.post(`${this.apiUrl}/add_user_feedback`, feedbackRequest);
  }

  getTokenFromLocalStorage(): string | null {
    if (localStorage.getItem("token")) {
      return localStorage.getItem("token");
    }

    return null;
  }
}
