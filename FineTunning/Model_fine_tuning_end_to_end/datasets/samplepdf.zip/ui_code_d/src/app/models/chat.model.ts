export interface ChatMessage {
  content: string;
  type: 'human' | 'ai';
  timestamp?: Date;
  feedback?: 'like' | 'dislike';
}

export interface ChatRequest {
  messages: {
    content: string;
    type: string;
  }[];
  knowledge_base: string;
  session_id: string;
  thread_id: string;
}

export interface ChatHistory {
  content: string;
  type: string;
}

export interface FeedbackRequest {
  email: string;
  response: String;
  feedback: string;
  impression: boolean;
  chat_history: ChatHistory[];
}
