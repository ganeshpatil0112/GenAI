export interface LoginRequest {
  email: string;
}

export interface LoginResponse {
  access_token: string;
  token_type: string;
}

export interface AuthState {
  isAuthenticated: boolean;
  access_token: string | null;
  email: string | null;
}
