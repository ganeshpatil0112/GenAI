import { Component } from "@angular/core";
import { bootstrapApplication } from "@angular/platform-browser";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { provideHttpClient } from "@angular/common/http";
import { RouterOutlet } from "@angular/router";
import { RouterModule } from "@angular/router";
import { appRouterProviders } from "./app/app.routes";

@Component({
  selector: "app-root",
  standalone: true,
  imports: [CommonModule, FormsModule, RouterOutlet, RouterModule],
  template: `<router-outlet></router-outlet>`,
})
export class App {}

bootstrapApplication(App, {
  providers: [provideHttpClient(), ...appRouterProviders],
});
