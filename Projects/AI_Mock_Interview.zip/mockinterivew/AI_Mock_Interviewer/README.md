https://euron.one/learn/7ba55a9b-6668-4cc9-93f4-8f2b56f4e221?tab=Overview&activeLectureId=64055adb-359e-478e-9f26-16021c9eea36https://euron.one/learn/7ba55a9b-6668-4cc9-93f4-8f2b56f4e221?tab=Overview&activeLectureId=64055adb-359e-478e-9f26-16021c9eea36



https://euron.one/learn/7ba55a9b-6668-4cc9-93f4-8f2b56f4e221?tab=Overview&activeLectureId=c015ec35-8df9-4827-846e-e42c6106b3fe

https://euron.one/learn/7ba55a9b-6668-4cc9-93f4-8f2b56f4e221?tab=Overview&activeLectureId=79d51590-9726-4d2d-be5a-15215816320f



https://euron.one/learn/7ba55a9b-6668-4cc9-93f4-8f2b56f4e221?tab=Overview&activeLectureId=28a78558-8c35-4905-9ab4-482605dfd773



https://euron.one/learn/7ba55a9b-6668-4cc9-93f4-8f2b56f4e221?tab=Overview&activeLectureId=3356d39d-afe7-45e4-90e1-0041182d7fb2  



Mathemetics for dataScience and Analytics
SQL 
C++ 
genai self paced course 
