import argparse
import json
from pathlib import Path
from typing import Any, Dict, List
import asyncio

try:
    from ..core.database import init_pool, close_pool, fetchrow, execute
except ImportError:
    # Allow running as a script file directly (python backend/scripts/import_users_from_json.py)
    from core.database import init_pool, close_pool, fetchrow, execute


def _derive_name_from_email(email: str) -> str:
    local = email.split("@", 1)[0]
    local = local.replace(".", " ").replace("_", " ")
    return " ".join(w.capitalize() for w in local.split())


async def upsert_user(email: str, interests: List[str]) -> int:
    # Check existing user by email
    row = await fetchrow("SELECT id FROM users WHERE email = $1", email)
    name = _derive_name_from_email(email)
    if row:
        user_id = int(row["id"])
        # Update interests
        await execute("UPDATE users SET interests = $1 WHERE id = $2", interests, user_id)
        return user_id
    else:
        # Insert a new user
        await execute(
            "INSERT INTO users (name, email, interests) VALUES ($1, $2, $3)",
            name,
            email,
            interests,
        )
        new_row = await fetchrow("SELECT id FROM users WHERE email = $1", email)
        return int(new_row["id"]) if new_row else 0


async def import_users(json_path: Path) -> int:
    if not json_path.exists():
        raise FileNotFoundError(f"Input file not found: {json_path}")
    with open(json_path, "r", encoding="utf-8") as f:
        data: Dict[str, Any] = json.load(f)

    users: List[Dict[str, Any]] = data.get("users", [])
    count = 0
    for u in users:
        email = u.get("email")
        prefs = u.get("preferences", {})
        interests = prefs.get("interests", [])
        if not email:
            continue
        # normalize to strings
        interests = [str(x) for x in interests]
        _ = await upsert_user(email=email, interests=interests)
        count += 1
    return count


async def async_main(path_arg: str) -> None:
    # Resolve path relative to current working directory
    json_path = Path(path_arg).resolve()
    await init_pool()
    try:
        n = await import_users(json_path)
        print(f"Imported/updated {n} users from {json_path}")
    finally:
        await close_pool()


def main() -> None:
    parser = argparse.ArgumentParser(description="Import users from JSON into the database")
    parser.add_argument("--path", required=True, help="Path to the users JSON file")
    args = parser.parse_args()
    asyncio.run(async_main(args.path))


if __name__ == "__main__":
    main()
